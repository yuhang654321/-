from __future__ import annotations

import re
import time
from html import unescape
from typing import Any

import httpx

BING_URL = "https://www.bing.com/search"
_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/128.0 Safari/537.36",
    "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.7",
}
_CACHE: dict[str, tuple[float, list[dict[str, str]]]] = {}
_CACHE_TTL = 300.0
_TAG_RE = re.compile(r"<[^>]+>")


def _clean(raw: str, limit: int = 260) -> str:
    text = unescape(_TAG_RE.sub(" ", raw))
    text = re.sub(r"\s+", " ", text).strip()
    return text[:limit]


def _decode_bing_url(url: str) -> str:
    """Bing sometimes wraps result links; keep the readable origin when possible."""
    if "bing.com/ck/a" not in url:
        return url
    match = re.search(r"[?&]u=a1([^&]+)", url)
    if not match:
        return url
    import base64

    raw = match.group(1)
    raw += "=" * (-len(raw) % 4)
    try:
        decoded = base64.urlsafe_b64decode(raw).decode("utf-8", "ignore")
        if decoded.startswith(("http://", "https://")):
            return decoded
    except Exception:
        pass
    return url


def _parse_bing(html: str, limit: int) -> list[dict[str, str]]:
    results: list[dict[str, str]] = []
    blocks = re.split(r'<li class="b_algo"', html)[1:]
    for block in blocks:
        link = re.search(r'<h2[^>]*>\s*<a[^>]+href="([^"]+)"[^>]*>(.*?)</a>', block, re.S)
        if not link:
            continue
        title = _clean(link.group(2), 120)
        if not title:
            continue
        snippet = ""
        for pattern in (r'<p[^>]*>(.*?)</p>', r'<div class="b_caption"[^>]*>(.*?)</div>'):
            match = re.search(pattern, block, re.S)
            if match:
                snippet = _clean(match.group(1), 240)
                if snippet:
                    break
        results.append(
            {
                "title": title,
                "url": _decode_bing_url(unescape(link.group(1))),
                "snippet": snippet,
            }
        )
        if len(results) >= limit:
            break
    return results


async def search_web(query: str, limit: int = 4, timeout: float = 4.5) -> list[dict[str, str]]:
    """Small, dependency-free Bing HTML lookup used only for harder questions."""
    query = query.strip()[:120]
    if not query:
        return []
    now = time.monotonic()
    cached = _CACHE.get(query)
    if cached and now - cached[0] < _CACHE_TTL:
        return cached[1]
    try:
        async with httpx.AsyncClient(
            timeout=httpx.Timeout(connect=2.5, read=timeout, write=3.0, pool=2.0),
            follow_redirects=True,
            headers=_HEADERS,
        ) as client:
            response = await client.get(
                BING_URL,
                params={"q": query, "setlang": "zh-Hans", "count": str(max(6, limit + 2))},
            )
            response.raise_for_status()
        results = _parse_bing(response.text, limit)
    except Exception:
        results = []
    _CACHE[query] = (now, results)
    return results


def research_context(results: list[dict[str, str]]) -> str:
    if not results:
        return ""
    lines = []
    for i, item in enumerate(results, 1):
        lines.append(f"[{i}] {item.get('title', '')}\n摘要：{item.get('snippet', '')}\n来源：{item.get('url', '')}")
    return "\n\n".join(lines)


def needs_research(message: str) -> bool:
    text = message.strip()
    if len(text) < 8:
        return False
    game_terms = ("这关", "怎么打", "种什么", "灵感", "睡眠舱", "波次", "阵型", "植物大战")
    if any(term in text for term in game_terms):
        return False
    hints = (
        "最新", "今天", "新闻", "为什么", "是什么", "什么是", "有什么区别", "怎么理解",
        "查一下", "搜一下", "是谁", "多少钱", "天气", "推荐", "解释", "原理", "历史",
        "科学", "电影", "电脑", "配置", "论文", "学习", "翻译", "英文", "对比", "教程",
    )
    if any(hint in text for hint in hints):
        return True
    return len(text) >= 18 and any(p in text for p in ("？", "?", "怎么", "如何", "能不能"))


def _first_web_url(results: list[dict[str, str]]) -> str:
    return results[0].get("url", "") if results else ""


def sources_payload(results: list[dict[str, str]]) -> list[dict[str, str]]:
    return [{"title": r.get("title", ""), "url": r.get("url", "")} for r in results if r.get("url")]


def debug_result(results: list[dict[str, str]]) -> dict[str, Any]:
    return {"count": len(results), "first": _first_web_url(results)}
