"""2.0 enemy redesign: five distinct, cute-but-tired early-8am creatures.

Run from the project root:
    python scripts/gen_zombies_v2.py
    node scripts/rasterize.mjs

The old zombies were all one green face with different props. This version keeps
the same ink-outline language but gives every enemy a different silhouette,
palette, posture and accessory so the lane reads at a glance.
"""
from __future__ import annotations

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from gen_sprites import CREAM, CYAN, INK, MAGENTA, MINT, OUT, PURPLE, YELLOW, svg  # noqa: E402

SKIN = "url(#skin)"
PALE = "#d8e4b4"
DARK = "#332640"


def eyes(cx: float, cy: float, mood: str = "sleepy", spread: float = 42) -> str:
    left, right = cx - spread, cx + spread
    if mood == "wired":
        return f"""
        <ellipse cx="{left}" cy="{cy}" rx="24" ry="20" fill="#fffdf0" stroke="{INK}" stroke-width="5"/>
        <ellipse cx="{right}" cy="{cy}" rx="24" ry="20" fill="#fffdf0" stroke="{INK}" stroke-width="5"/>
        <circle cx="{left + 5}" cy="{cy + 1}" r="8" fill="{INK}"/>
        <circle cx="{right + 5}" cy="{cy + 1}" r="8" fill="{INK}"/>
        <circle cx="{left + 2}" cy="{cy - 4}" r="2.6" fill="#fff"/>
        <circle cx="{right + 2}" cy="{cy - 4}" r="2.6" fill="#fff"/>
        <path d="M{left - 25} {cy - 3} Q{left} {cy - 13} {left + 24} {cy - 4}
                 M{right - 24} {cy - 4} Q{right} {cy - 13} {right + 25} {cy - 3}"
              fill="none" stroke="#8a5a55" stroke-width="3" opacity=".45"/>
        <path d="M{left - 20} {cy + 28} Q{left} {cy + 34} {left + 20} {cy + 28}
                 M{right - 20} {cy + 28} Q{right} {cy + 34} {right + 20} {cy + 28}"
              fill="none" stroke="#6b7a58" stroke-width="4" opacity=".45"/>
        """
    if mood == "stern":
        return f"""
        <path d="M{left - 26} {cy - 12} L{left + 24} {cy - 2}
                 M{right - 24} {cy - 2} L{right + 26} {cy - 12}"
              stroke="{INK}" stroke-width="8" stroke-linecap="round"/>
        <ellipse cx="{left}" cy="{cy + 8}" rx="17" ry="12" fill="#fff7df" stroke="{INK}" stroke-width="4"/>
        <ellipse cx="{right}" cy="{cy + 8}" rx="17" ry="12" fill="#fff7df" stroke="{INK}" stroke-width="4"/>
        <circle cx="{left - 2}" cy="{cy + 8}" r="6.5" fill="{INK}"/>
        <circle cx="{right + 2}" cy="{cy + 8}" r="6.5" fill="{INK}"/>
        """
    # Sleepy: dark rings, half-lidded sclera, tiny pupils.
    return f"""
    <ellipse cx="{left}" cy="{cy + 4}" rx="27" ry="17" fill="#7b6d5a" opacity=".35"/>
    <ellipse cx="{right}" cy="{cy + 4}" rx="27" ry="17" fill="#7b6d5a" opacity=".35"/>
    <ellipse cx="{left}" cy="{cy + 2}" rx="21" ry="14" fill="#fff7df" stroke="{INK}" stroke-width="4"/>
    <ellipse cx="{right}" cy="{cy + 2}" rx="21" ry="14" fill="#fff7df" stroke="{INK}" stroke-width="4"/>
    <circle cx="{left + 4}" cy="{cy + 4}" r="6.4" fill="{INK}"/>
    <circle cx="{right + 4}" cy="{cy + 4}" r="6.4" fill="{INK}"/>
    <circle cx="{left + 2}" cy="{cy}" r="2.2" fill="#fff"/>
    <circle cx="{right + 2}" cy="{cy}" r="2.2" fill="#fff"/>
    <path d="M{left - 23} {cy - 3} Q{left} {cy + 10} {left + 22} {cy - 3}
             M{right - 22} {cy - 3} Q{right} {cy + 10} {right + 23} {cy - 3}"
          fill="none" stroke="{INK}" stroke-width="5" stroke-linecap="round"/>
    <path d="M{left - 18} {cy + 23} Q{left} {cy + 28} {left + 18} {cy + 23}
             M{right - 18} {cy + 23} Q{right} {cy + 28} {right + 18} {cy + 23}"
          fill="none" stroke="#6b5a4a" stroke-width="3" opacity=".55"/>
    """


def head(
    cx: float = 256,
    cy: float = 172,
    hair: str = DARK,
    skin: str = SKIN,
    mood: str = "sleepy",
    grin: bool = False,
    glasses: bool = False,
    bun: bool = False,
    bedhead: bool = False,
) -> str:
    tufts = f"""
    <path d="M{cx - 88} {cy - 68} C{cx - 130} {cy - 118} {cx - 116} {cy - 150} {cx - 96} {cy - 153}
             C{cx - 108} {cy - 124} {cx - 98} {cy - 102} {cx - 78} {cy - 86} Z" fill="{hair}" stroke="{INK}" stroke-width="7"/>
    <path d="M{cx + 44} {cy - 98} C{cx + 60} {cy - 156} {cx + 92} {cy - 164} {cx + 104} {cy - 144}
             C{cx + 78} {cy - 137} {cx + 60} {cy - 118} {cx + 58} {cy - 82} Z" fill="{hair}" stroke="{INK}" stroke-width="7"/>
    """ if bedhead else ""
    bun_svg = f"""
    <circle cx="{cx + 96}" cy="{cy - 74}" r="33" fill="{hair}" stroke="{INK}" stroke-width="8"/>
    <path d="M{cx + 76} {cy - 78} Q{cx + 94} {cy - 94} {cx + 112} {cy - 76}" fill="none" stroke="#5a4768" stroke-width="5"/>
    """ if bun else ""
    mouth = (
        f"""<path d="M{cx - 32} {cy + 57} C{cx - 13} {cy + 82} {cx + 19} {cy + 80} {cx + 35} {cy + 53}
        C{cx + 18} {cy + 65} {cx - 12} {cy + 66} {cx - 32} {cy + 57} Z" fill="#4b243d" stroke="{INK}" stroke-width="5"/>
        <path d="M{cx - 18} {cy + 62} L{cx - 14} {cy + 72} L{cx - 7} {cy + 62} Z" fill="{CREAM}"/>"""
        if grin
        else f"""<path d="M{cx - 23} {cy + 58} Q{cx} {cy + 70} {cx + 24} {cy + 56}" fill="none" stroke="{INK}" stroke-width="5" stroke-linecap="round"/>
        <path d="M{cx + 2} {cy + 63} L{cx + 8} {cy + 72} L{cx + 12} {cy + 62} Z" fill="{CREAM}" stroke="{INK}" stroke-width="2"/>"""
    )
    glass = f"""
    <circle cx="{cx - 42}" cy="{cy + 4}" r="27" fill="none" stroke="#3d334d" stroke-width="5"/>
    <circle cx="{cx + 42}" cy="{cy + 4}" r="27" fill="none" stroke="#3d334d" stroke-width="5"/>
    <path d="M{cx - 15} {cy + 2} H{cx + 14}" stroke="#3d334d" stroke-width="4"/>
    <path d="M{cx - 69} {cy + 1} L{cx - 96} {cy - 14} M{cx + 69} {cy + 1} L{cx + 96} {cy - 14}" stroke="#3d334d" stroke-width="4"/>
    """ if glasses else ""
    return f"""
    <ellipse cx="{cx}" cy="{cy}" rx="105" ry="112" fill="{skin}" stroke="{INK}" stroke-width="11"/>
    <path d="M{cx - 102} {cy - 26} C{cx - 124} {cy - 91} {cx - 82} {cy - 140} {cx - 15} {cy - 143}
             C{cx + 53} {cy - 147} {cx + 112} {cy - 108} {cx + 105} {cy - 28}
             C{cx + 80} {cy - 60} {cx + 47} {cy - 64} {cx + 28} {cy - 34}
             C{cx + 13} {cy - 68} {cx - 38} {cy - 75} {cx - 56} {cy - 35}
             C{cx - 75} {cy - 56} {cx - 92} {cy - 50} {cx - 102} {cy - 26} Z"
          fill="{hair}" stroke="{INK}" stroke-width="8"/>
    <path d="M{cx - 63} {cy - 101} C{cx - 45} {cy - 126} {cx - 1} {cy - 132} {cx + 19} {cy - 111}"
          fill="none" stroke="#5a4768" stroke-width="5" opacity=".7" stroke-linecap="round"/>
    {tufts}
    {bun_svg}
    {eyes(cx, cy + 4, mood)}
    <path d="M{cx - 4} {cy + 35} Q{cx + 4} {cy + 42} {cx + 12} {cy + 35}" fill="none" stroke="#6b5a4a" stroke-width="4" stroke-linecap="round"/>
    {mouth}
    <ellipse cx="{cx - 78}" cy="{cy + 42}" rx="23" ry="10" fill="#ff8ca0" opacity=".5"/>
    <ellipse cx="{cx + 78}" cy="{cy + 42}" rx="23" ry="10" fill="#ff8ca0" opacity=".5"/>
    {glass}
    """


def basic() -> str:
    body = f"""
    <ellipse cx="256" cy="476" rx="126" ry="16" fill="{INK}" opacity=".2"/>
    <path d="M174 293 C174 268 194 252 221 250 L291 250 C321 252 340 270 341 296
             L347 397 C349 424 326 442 296 441 L216 441 C188 442 169 424 171 397 Z"
          fill="#fff1cf" stroke="{INK}" stroke-width="12"/>
    <path d="M209 254 C223 238 239 231 256 233 C275 231 291 240 303 256
             C286 270 270 274 256 274 C240 274 222 268 209 254 Z" fill="#ffe3a0" stroke="{INK}" stroke-width="6"/>
    <path d="M232 275 C243 286 269 286 280 275" fill="none" stroke="{INK}" stroke-width="5"/>
    <path d="M206 330 L196 397 M306 330 L316 397" stroke="{INK}" stroke-width="4" opacity=".35"/>
    <path d="M198 347 C217 337 240 337 256 347 C272 337 295 337 314 347 L310 404 C287 415 225 415 202 404 Z"
          fill="#ffe6b0" stroke="{INK}" stroke-width="5"/>
    <text x="256" y="386" font-family="Arial Black, sans-serif" font-size="18" fill="{PURPLE}" text-anchor="middle">8AM</text>
    <path d="M174 306 C144 318 128 348 139 378 C151 393 169 393 181 382 C165 360 164 333 181 315 Z"
          fill="#fff1cf" stroke="{INK}" stroke-width="10"/>
    <path d="M338 306 C367 318 382 346 372 376 C360 392 342 393 331 381 C347 358 347 329 331 313 Z"
          fill="#fff1cf" stroke="{INK}" stroke-width="10"/>
    <path d="M196 435 L190 466 M316 435 L322 466" stroke="{INK}" stroke-width="13" stroke-linecap="round"/>
    <path d="M170 468 C193 457 220 463 226 477 L158 477 C158 470 162 470 170 468 Z" fill="#ff8fb0" stroke="{INK}" stroke-width="6"/>
    <path d="M342 468 C319 457 292 463 286 477 L354 477 C354 470 350 470 342 468 Z" fill="#ff8fb0" stroke="{INK}" stroke-width="6"/>
    <path d="M336 379 C354 380 365 394 359 410 L337 405 Z" fill="#9fe7ff" stroke="{INK}" stroke-width="5"/>
    <rect x="339" y="390" width="17" height="28" rx="3" fill="#5c9cb2" stroke="{INK}" stroke-width="3" transform="rotate(14 347 404)"/>
    {head(256, 168, hair="#443154", skin=SKIN, mood="sleepy", bedhead=True)}
    <g transform="rotate(-6 256 110)">
      <rect x="169" y="93" width="174" height="39" rx="16" fill="#ff93b4" stroke="{INK}" stroke-width="7"/>
      <path d="M181 104 C211 98 250 98 284 103" fill="none" stroke="#ffd4e2" stroke-width="5" opacity=".8"/>
      <text x="256" y="120" font-family="Arial Black, sans-serif" font-size="17" fill="{INK}" text-anchor="middle">Zzz</text>
      <path d="M170 109 C146 109 130 113 116 120 M342 109 C366 105 382 106 394 113" fill="none" stroke="{INK}" stroke-width="7"/>
    </g>
    <path d="M131 202 C116 192 101 202 103 218 C117 229 134 218 131 202 Z" fill="#f7e6bd" stroke="{INK}" stroke-width="4"/>
    <path d="M374 155 C402 137 423 144 424 164 C407 181 388 176 374 155 Z" fill="#ffe9a8" stroke="{INK}" stroke-width="5"/>
    <text x="399" y="168" font-family="Arial Black, sans-serif" font-size="13" fill="{INK}" text-anchor="middle">早八</text>
    """
    return svg(body)


def fast() -> str:
    body = f"""
    <ellipse cx="256" cy="478" rx="140" ry="14" fill="{INK}" opacity=".2"/>
    <path d="M82 260 L111 241 M70 293 L100 282 M72 327 L101 325" stroke="{MAGENTA}" stroke-width="7" stroke-linecap="round"/>
    <g transform="translate(0 12)">
      <path d="M122 442 C187 426 309 426 382 442 C397 445 395 464 377 468 C306 482 191 481 124 466 C108 463 106 446 122 442 Z"
            fill="#ff4f87" stroke="{INK}" stroke-width="9"/>
      <circle cx="156" cy="472" r="15" fill="#ffe66d" stroke="{INK}" stroke-width="5"/>
      <circle cx="345" cy="472" r="15" fill="#ffe66d" stroke="{INK}" stroke-width="5"/>
    </g>
    <path d="M188 408 C186 440 199 456 224 458 M316 408 C319 439 307 456 285 458" fill="none" stroke="{INK}" stroke-width="12" stroke-linecap="round"/>
    <path d="M178 296 C182 267 204 252 231 251 L287 251 C317 252 336 270 338 298
             L331 392 C329 420 307 435 280 434 L230 434 C201 435 181 418 179 392 Z"
          fill="#66d9cf" stroke="{INK}" stroke-width="12"/>
    <path d="M231 254 L256 279 L288 253" fill="none" stroke="{INK}" stroke-width="6"/>
    <path d="M256 278 L256 343" stroke="#ff5f8d" stroke-width="12"/>
    <path d="M256 295 L235 313 L256 331 L277 313 Z" fill="#ff5f8d" stroke="{INK}" stroke-width="5"/>
    <path d="M184 315 C157 303 131 314 118 340 C129 359 151 365 168 351 C159 333 166 319 184 315 Z"
          fill="#66d9cf" stroke="{INK}" stroke-width="10"/>
    <path d="M332 318 C358 306 383 318 395 343 C385 362 363 368 347 353 C356 334 349 321 332 318 Z"
          fill="#66d9cf" stroke="{INK}" stroke-width="10"/>
    <path d="M151 349 C137 342 122 348 117 362" fill="none" stroke="{INK}" stroke-width="7" stroke-linecap="round"/>
    <path d="M363 353 C378 348 390 358 390 371" fill="none" stroke="{INK}" stroke-width="7" stroke-linecap="round"/>
    {head(256, 158, hair="#2f2a4a", skin="#9fd6cf", mood="sleepy", grin=True)}
    <path d="M340 128 C376 124 405 139 412 163 C388 176 360 169 348 146 Z" fill="#ffd447" stroke="{INK}" stroke-width="9"/>
    <path d="M345 137 C368 131 391 140 400 152" fill="none" stroke="#fff3b0" stroke-width="5"/>
    <path d="M179 143 C151 143 132 161 135 184 C158 194 180 178 179 143 Z" fill="#2b2142" stroke="{INK}" stroke-width="8"/>
    <path d="M337 157 C371 157 394 177 390 203 C363 212 339 196 337 157 Z" fill="#2b2142" stroke="{INK}" stroke-width="8"/>
    <path d="M173 168 C148 168 132 188 137 210 C160 218 181 201 179 175 Z" fill="#ff5f8d" stroke="{INK}" stroke-width="8"/>
    <path d="M338 176 C364 176 381 195 376 217 C352 225 332 208 335 183 Z" fill="#ff5f8d" stroke="{INK}" stroke-width="8"/>
    <path d="M156 143 C137 123 138 101 158 92" fill="none" stroke="{INK}" stroke-width="9" stroke-linecap="round"/>
    <path d="M356 143 C376 123 374 101 354 92" fill="none" stroke="{INK}" stroke-width="9" stroke-linecap="round"/>
    <path d="M132 206 C113 201 99 212 103 228 C118 238 134 226 132 206 Z" fill="#c8d8a7" stroke="{INK}" stroke-width="5"/>
    <path d="M380 212 C399 207 413 218 409 234 C394 244 378 232 380 212 Z" fill="#c8d8a7" stroke="{INK}" stroke-width="5"/>
    <path d="M185 92 L176 58 M211 83 L214 51 M292 83 L289 51 M319 96 L330 62" stroke="{CYAN}" stroke-width="5" stroke-linecap="round" opacity=".7"/>
    """
    return svg(body)


def paper() -> str:
    sheets = []
    coords = [
        (164, 251, -17, 82, 108), (300, 258, 12, 82, 110), (143, 315, 8, 84, 110),
        (291, 327, -15, 86, 116), (179, 375, 18, 102, 104), (281, 390, -8, 96, 105),
        (198, 240, -4, 108, 74),
    ]
    for x, y, r, w, h in coords:
        lines = "".join(
            f'<path d="M{x + 12} {y + 22 + i * 16} H{x + w - 14}" stroke="#8b8193" stroke-width="4" opacity=".65"/>'
            for i in range(3)
        )
        sheets.append(
            f'<g transform="rotate({r} {x + w / 2} {y + h / 2})">'
            f'<rect x="{x}" y="{y}" width="{w}" height="{h}" fill="#fff8df" stroke="{INK}" stroke-width="5"/>'
            f'{lines}</g>'
        )
    body = f"""
    <ellipse cx="256" cy="476" rx="136" ry="16" fill="{INK}" opacity=".2"/>
    {''.join(sheets[:4])}
    <path d="M178 297 C181 269 202 253 229 252 L283 252 C313 253 331 271 333 299
             L327 393 C325 419 303 434 276 433 L228 434 C201 435 181 418 179 392 Z"
          fill="#e9e1c8" stroke="{INK}" stroke-width="12"/>
    <path d="M205 432 L196 468 M316 432 L325 468" stroke="{INK}" stroke-width="13" stroke-linecap="round"/>
    <path d="M174 308 C151 318 140 343 151 364 C165 375 180 370 187 359 C173 341 173 323 186 310 Z"
          fill="#e9e1c8" stroke="{INK}" stroke-width="9"/>
    <path d="M336 314 C359 324 370 348 359 370 C345 381 330 375 323 364 C338 346 338 328 324 316 Z"
          fill="#e9e1c8" stroke="{INK}" stroke-width="9"/>
    {''.join(sheets[4:])}
    {head(256, 164, hair="#4b3a55", skin="#c9c7a7", mood="sleepy", glasses=True, bun=True)}
    <path d="M176 147 C154 151 143 171 153 187 C169 194 183 181 182 164 Z" fill="#f1e8d3" stroke="{INK}" stroke-width="6"/>
    <path d="M334 151 C358 155 368 175 358 191 C342 197 328 183 329 166 Z" fill="#f1e8d3" stroke="{INK}" stroke-width="6"/>
    <g transform="rotate(-6 256 302)">
      <rect x="191" y="277" width="130" height="44" rx="7" fill="#ffde59" stroke="{INK}" stroke-width="6"/>
      <text x="256" y="307" font-family="Arial Black, sans-serif" font-size="19" fill="{INK}" text-anchor="middle">DRAFT 17</text>
    </g>
    <path d="M338 138 L381 77 L432 112 L391 149 Z" fill="#fff6dc" stroke="{INK}" stroke-width="6"/>
    <path d="M338 138 L381 77 L381 120 L356 142 Z" fill="#ffd7e2" stroke="{INK}" stroke-width="4"/>
    <path d="M364 430 C387 428 398 440 393 456" fill="none" stroke="{INK}" stroke-width="6" stroke-linecap="round"/>
    <path d="M195 118 C174 98 145 106 142 132 C158 151 183 146 195 118 Z" fill="#fff6dc" stroke="{INK}" stroke-width="5"/>
    <path d="M156 126 H183 M154 136 H178" stroke="#b2a6b4" stroke-width="3"/>
    """
    return svg(body)


def coffee() -> str:
    body = f"""
    <ellipse cx="256" cy="478" rx="118" ry="15" fill="{INK}" opacity=".2"/>
    <path d="M203 426 L192 472 M310 426 L322 472" stroke="{INK}" stroke-width="12" stroke-linecap="round"/>
    <path d="M168 470 C191 461 218 466 224 478 L158 478 C158 473 162 471 168 470 Z" fill="#5b3b33" stroke="{INK}" stroke-width="5"/>
    <path d="M345 470 C322 461 295 466 289 478 L355 478 C355 473 351 471 345 470 Z" fill="#5b3b33" stroke="{INK}" stroke-width="5"/>
    <path d="M191 286 C190 262 207 247 228 246 L286 246 C311 247 326 263 326 288
             L321 398 C319 423 299 437 274 436 L231 436 C205 436 190 419 192 396 Z"
          fill="#a96e4d" stroke="{INK}" stroke-width="12"/>
    <path d="M229 250 L256 278 L287 249" fill="none" stroke="{INK}" stroke-width="6"/>
    <path d="M256 279 L256 340" stroke="#3f7b56" stroke-width="12"/>
    <path d="M256 296 L236 313 L256 330 L276 313 Z" fill="#3f7b56" stroke="{INK}" stroke-width="5"/>
    <path d="M193 308 C166 298 142 312 132 338 C144 357 166 362 182 347 C171 329 177 315 193 308 Z"
          fill="#a96e4d" stroke="{INK}" stroke-width="10"/>
    <path d="M327 315 C354 306 377 320 388 345 C376 364 354 369 339 354 C350 335 344 322 327 315 Z"
          fill="#a96e4d" stroke="{INK}" stroke-width="10"/>
    <path d="M310 281 C347 274 376 299 374 333 L371 383 C370 403 352 412 337 400 L310 376 Z"
          fill="#cdeff5" stroke="{INK}" stroke-width="9"/>
    <path d="M318 293 L319 381" stroke="#fff" stroke-width="7" opacity=".65"/>
    <path d="M307 280 L375 280 L371 322 L311 316 Z" fill="url(#coffee)" stroke="{INK}" stroke-width="7"/>
    <path d="M380 301 C408 297 416 319 400 335 C390 343 377 337 374 326" fill="none" stroke="{INK}" stroke-width="9" stroke-linecap="round"/>
    <path d="M342 274 L356 206" stroke="#ff5b82" stroke-width="11" stroke-linecap="round"/>
    <path d="M344 217 C360 203 375 207 381 219 C365 231 351 229 344 217 Z" fill="#ffe28c" stroke="{INK}" stroke-width="4"/>
    {head(256, 148, hair="#3f2e46", skin="#d2b48c", mood="wired", bun=True)}
    <path d="M151 135 C130 125 115 137 119 155 C136 166 152 151 151 135 Z" fill="#c8d8a7" stroke="{INK}" stroke-width="5"/>
    <path d="M362 151 C383 141 398 153 394 171 C377 182 361 167 362 151 Z" fill="#c8d8a7" stroke="{INK}" stroke-width="5"/>
    <path d="M124 268 C101 281 96 307 113 326" fill="none" stroke="{INK}" stroke-width="8" stroke-linecap="round"/>
    <path d="M127 340 C107 353 102 376 117 393" fill="none" stroke="{INK}" stroke-width="8" stroke-linecap="round"/>
    <path d="M384 203 L404 177 M394 225 L424 216 M369 183 L373 151" stroke="{MAGENTA}" stroke-width="6" stroke-linecap="round"/>
    <path d="M161 174 L146 141 M344 166 L362 137" stroke="{CYAN}" stroke-width="5" stroke-linecap="round" opacity=".6"/>
    """
    return svg(body)


def boss() -> str:
    body = f"""
    <ellipse cx="256" cy="492" rx="174" ry="18" fill="{INK}" opacity=".25"/>
    <g opacity=".9">
      <path d="M79 300 L128 279 L140 318 L90 338 Z" fill="#fff2cf" stroke="{INK}" stroke-width="4"/>
      <path d="M380 337 L425 318 L432 355 L386 374 Z" fill="#fff2cf" stroke="{INK}" stroke-width="4"/>
      <path d="M72 225 L108 205 L122 230 L85 249 Z" fill="#fff2cf" stroke="{INK}" stroke-width="4"/>
    </g>
    <path d="M164 349 C137 387 129 442 141 482 L371 482 C383 442 375 387 348 349 Z"
          fill="#2c1b43" stroke="{INK}" stroke-width="13"/>
    <path d="M164 349 L210 482 M348 349 L302 482" stroke="#6b458f" stroke-width="7"/>
    <path d="M178 370 C177 338 201 314 228 311 L284 311 C312 314 334 337 333 368 L325 428 C323 456 297 470 270 469
             L240 469 C212 470 189 454 187 428 Z" fill="#241634" stroke="{INK}" stroke-width="12"/>
    <path d="M228 314 L256 350 L285 313" fill="none" stroke="#ffd76a" stroke-width="7"/>
    <path d="M256 349 L256 423" stroke="#ff4d6d" stroke-width="9"/>
    <path d="M256 365 L234 385 L256 405 L278 385 Z" fill="#ff4d6d" stroke="{INK}" stroke-width="5"/>
    <path d="M199 390 C183 373 176 349 188 327" fill="none" stroke="{INK}" stroke-width="11" stroke-linecap="round"/>
    <path d="M313 390 C329 373 336 349 324 327" fill="none" stroke="{INK}" stroke-width="11" stroke-linecap="round"/>
    {head(256, 198, hair="#d8d0c2", skin="#ecdfc7", mood="stern", glasses=True)}
    <path d="M150 177 C145 112 190 73 256 73 C323 73 368 112 362 178 C356 235 316 262 256 263 C195 262 156 235 150 177 Z"
          fill="none" stroke="{INK}" stroke-width="10"/>
    <path d="M157 171 C174 139 209 119 253 116" fill="none" stroke="#fff" stroke-width="7" opacity=".45" stroke-linecap="round"/>
    <g transform="rotate(-7 256 90)">
      <path d="M163 93 L256 62 L350 94 L256 126 Z" fill="#2d203c" stroke="{INK}" stroke-width="8"/>
      <path d="M256 92 L256 126" stroke="#ffd447" stroke-width="5"/>
      <path d="M350 94 L379 152 M379 152 C392 162 394 176 383 184 C370 187 361 177 363 165" fill="none" stroke="#ffd447" stroke-width="7" stroke-linecap="round"/>
      <text x="256" y="93" font-family="ZCOOL KuaiLe, Microsoft YaHei, sans-serif" font-size="17" fill="#ffd447" text-anchor="middle">终审</text>
    </g>
    <path d="M347 331 L410 380" stroke="{INK}" stroke-width="9" stroke-linecap="round"/>
    <path d="M403 373 C420 371 429 383 419 396 C406 396 398 386 403 373 Z" fill="{MAGENTA}" stroke="{INK}" stroke-width="5"/>
    <path d="M384 405 L454 431 L446 449 L376 423 Z" fill="#ffde59" stroke="{INK}" stroke-width="6"/>
    <text x="413" y="436" transform="rotate(22 413 436)" font-family="Arial Black, sans-serif" font-size="14" fill="{INK}" text-anchor="middle">DDL</text>
    <path d="M172 442 C154 429 150 408 164 392" fill="none" stroke="{INK}" stroke-width="10" stroke-linecap="round"/>
    <path d="M338 442 C356 429 360 408 346 392" fill="none" stroke="{INK}" stroke-width="10" stroke-linecap="round"/>
    <path d="M216 490 L208 506 M296 490 L304 506" stroke="{INK}" stroke-width="11" stroke-linecap="round"/>
    """
    return svg(body)


SPRITES = {
    "zombie_basic": basic,
    "zombie_fast": fast,
    "zombie_paper": paper,
    "zombie_coffee": coffee,
    "zombie_boss": boss,
}


def main() -> None:
    for name, builder in SPRITES.items():
        path = os.path.join(OUT, name + ".svg")
        with open(path, "w", encoding="utf-8") as fh:
            fh.write(builder())
        print("generated", path)


if __name__ == "__main__":
    main()
