import { chromium } from "playwright-core";
import { resolve } from "node:path";
const root = resolve(import.meta.dirname, "..");
const browser = await chromium.launch({ executablePath: "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe", headless: true, args: ["--disable-gpu"] });
const page = await browser.newPage({ viewport: { width: 1600, height: 900 } });
const errors = [];
page.on("console", (m) => { if (m.type() === "error") errors.push(m.text()); });
page.on("pageerror", (e) => errors.push(e.message));
await page.goto("http://127.0.0.1:8000/?debug", { waitUntil: "networkidle" });
await page.waitForTimeout(2400);
await page.click("#start-btn");
await page.waitForTimeout(250);
await page.locator(".level-card").first().click();
await page.waitForTimeout(700);
const setup = await page.evaluate(() => {
  const { game: g, ui } = window.__nailong;
  g.agent = null;
  g.events.onToast = () => {};
  g.events.onNotice = () => {};
  g.sun = 999;
  g.readyAt.flower = 0;
  g.placePlant("flower", 2, 2);
  const p = g.plants.find((x) => x.type === "flower");
  ui.setDialogue("奶龙花：哈哈哈哈哈……你、你别过来啊！");
  return { px: p.x, p: p.uid };
});
await page.waitForTimeout(1800);
const trig = await page.evaluate(() => {
  const g = window.__nailong.game;
  const p = g.plants.find((x) => x.type === "flower");
  g.spawnZombie("basic", 2);
  const z = g.zombies[g.zombies.length - 1];
  z.x = p.x + 62;
  g.wave = 1;
  g.waveActive = true;
  document.querySelector("#toast-layer").innerHTML = "";
  return { zx: z.x, z: z.uid };
});
await page.waitForTimeout(850);
const laugh = await page.evaluate(() => {
  const g = window.__nailong.game;
  const p = g.plants.find((x) => x.type === "flower");
  const z = g.zombies[g.zombies.length - 1];
  return { pDead: p?.dead, pLaugh: p?.laughing, zLaugh: z.laughTimer, zCarry: z.carrying, zx: Math.round(z.x), hp: g.houseHp, carries: g.stats.carries };
});
await page.screenshot({ path: resolve(root, "demo", "laugh-carry-1.png") });
await page.waitForTimeout(2200);
const carry = await page.evaluate(() => {
  const g = window.__nailong.game;
  const p = g.plants.find((x) => x.type === "flower");
  const z = g.zombies[g.zombies.length - 1];
  return { pDead: p?.dead, zLaugh: z.laughTimer, zCarry: z.carrying, zx: Math.round(z.x), carries: g.stats.carries, suns: g.suns.length };
});
await page.screenshot({ path: resolve(root, "demo", "laugh-carry-2.png") });
await page.evaluate(() => {
  const g = window.__nailong.game;
  g.sun = 999;
  g.readyAt.flower = 0;
  g.placePlant("flower", 3, 2);
});
await page.waitForTimeout(200);
const secondSetup = await page.evaluate(() => {
  const g = window.__nailong.game;
  const p = g.plants.find((x) => x.type === "flower" && !x.dead);
  g.spawnZombie("basic", 2);
  const z = g.zombies[g.zombies.length - 1];
  z.x = p.x + 62;
  return { px: p.x, zx: z.x, carries: g.stats.carries };
});
await page.waitForTimeout(3400);
const second = await page.evaluate(() => {
  const g = window.__nailong.game;
  const z = g.zombies[g.zombies.length - 1];
  return { carries: g.stats.carries, zCarry: z.carrying, flowers: g.plants.filter((p) => p.type === "flower" && !p.dead).length };
});
console.log("setup", setup, "trigger", trig);
console.log("laugh", laugh);
console.log("carry", carry);
console.log("second", secondSetup, second);
console.log("errors", errors);
if (!(laugh.zLaugh > 0 && !laugh.zCarry && carry.zCarry && carry.carries === 1 && second.carries === 2)) {
  console.error("FAIL laugh/carry state chain");
  process.exitCode = 1;
} else {
  console.log("PASS laugh/carry state chain (100% trigger)");
}
await browser.close();
