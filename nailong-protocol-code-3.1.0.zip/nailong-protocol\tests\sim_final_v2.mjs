﻿import { chromium } from "playwright-core";
const browser = await chromium.launch({ executablePath: "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe", headless: true, args: ["--disable-gpu"] });
const page = await browser.newPage({ viewport: { width: 1600, height: 900 } });
const errors = [];
page.on("pageerror", (e) => errors.push(e.message));
await page.goto("http://127.0.0.1:8000/?debug", { waitUntil: "networkidle" });
await page.waitForTimeout(2300);
const result = await page.evaluate(() => {
  const { game: g } = window.__nailong;
  g.agent = null;
  g.events.onEnd = () => {};
  g.startLevel(14);
  g.screen = "playing";
  g.sun = 99999;
  const spots = [];
  for (let row = 0; row < 5; row++) {
    for (const [type, col] of [["pea", 1], ["pea", 2], ["frost", 3], ["wall", 4], ["cannon", 2], ["seal", 3]]) {
      spots.push([type, col, row]);
    }
  }
  for (const [type, col, row] of spots) { g.readyAt[type] = 0; g.placePlant(type, col, row); }
  g.wave = 5;
  g.waveActive = true;
  g.waveElapsed = 3;
  g.spawnQueue = [];
  g.spawnZombie("emperor", 2);
  const started = g.time;
  for (let i = 0; i < 4000; i++) {
    g.sun = 9999;
    g.update(0.05);
    if (g.screen === "won" || g.screen === "lost") break;
  }
  return { screen: g.screen, wave: g.wave, total: g.totalWaves, kills: g.stats.kills, time: Math.round(g.time - started), zombies: g.zombies.length, boss: g.zombies.filter(z => z.boss).map(z => ({ type: z.type, hp: Math.round(z.hp), max: Math.round(z.maxHp) })) };
});
console.log(JSON.stringify(result, null, 2));
console.log("errors", errors);
await browser.close();
