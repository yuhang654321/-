from __future__ import annotations

import base64
import binascii
import io
import threading
import time
from pathlib import Path
from typing import Any

from PIL import Image, ImageOps

from .settings import COCO_MODEL, VISION_MODEL

COCO_INTERESTING = {
    "person",
    "cup",
    "book",
    "cell phone",
    "laptop",
    "bottle",
    "keyboard",
    "mouse",
    "banana",
    "apple",
    "chair",
    "backpack",
    "clock",
    "teddy bear",
    "handbag",
    "tv",
    "remote",
}

LABELS_ZH = {
    "plant": "植物",
    "zombie": "僵尸",
    "boss": "导师",
    "sun": "灵感",
    "projectile": "废话",
}


class VisionService:
    def __init__(self) -> None:
        self._models: dict[str, Any] = {}
        self._errors: dict[str, str] = {}
        self._lock = threading.Lock()
        self.device = "cpu"
        self.last_ms = 0.0
        self._torch_checked = False

    def _torch(self):
        import torch  # local import keeps health fast even without torch

        if not self._torch_checked:
            self.device = "cuda:0" if torch.cuda.is_available() else "cpu"
            self._torch_checked = True
        return torch

    def _load(self, domain: str):
        path = VISION_MODEL if domain == "abstract" else COCO_MODEL
        if domain in self._models:
            return self._models[domain]
        if not Path(path).exists():
            raise FileNotFoundError(f"model not found: {path}")
        from ultralytics import YOLO

        self._torch()
        model = YOLO(str(path))
        self._models[domain] = model
        self._errors.pop(domain, None)
        return model

    def warm_abstract(self) -> None:
        try:
            self._load("abstract")
        except Exception as exc:  # noqa: BLE001
            self._errors["abstract"] = str(exc)

    def status(self) -> dict[str, Any]:
        loaded = "abstract" in self._models
        names: list[str] = []
        if loaded:
            try:
                names = list(self._models["abstract"].names.values())
            except Exception:  # noqa: BLE001
                names = []
        return {
            "ready": loaded,
            "model": VISION_MODEL.name if loaded else None,
            "classes": names,
            "device": self.device.upper() if loaded else None,
            "error": self._errors.get("abstract"),
            "coco_ready": COCO_MODEL.exists(),
            "custom_path": str(VISION_MODEL),
            "coco_path": str(COCO_MODEL),
        }

    def _decode_image(self, data_url: str) -> Image.Image:
        if "," in data_url:
            header, encoded = data_url.split(",", 1)
            if "base64" not in header:
                raise ValueError("expected base64 data URL")
        else:
            encoded = data_url
        if len(encoded) > 12_000_000:
            raise ValueError("image too large")
        try:
            raw = base64.b64decode(encoded, validate=False)
        except (binascii.Error, ValueError) as exc:
            raise ValueError("invalid base64 image") from exc
        image = Image.open(io.BytesIO(raw))
        image = ImageOps.exif_transpose(image).convert("RGB")
        if image.width < 32 or image.height < 32:
            raise ValueError("image too small")
        return image

    def detect(self, data_url: str, domain: str = "abstract", conf: float = 0.25) -> dict[str, Any]:
        if domain not in {"abstract", "real"}:
            domain = "abstract"
        started = time.perf_counter()
        image = self._decode_image(data_url)
        with self._lock:
            model = self._load(domain)
            kwargs = {
                "source": image,
                "imgsz": 640,
                "conf": max(0.05, min(0.9, float(conf))),
                "iou": 0.45,
                "verbose": False,
                "max_det": 40,
            }
            if self.device != "cpu":
                kwargs["device"] = 0
            results = model.predict(**kwargs)
        result = results[0]
        names = result.names
        detections = []
        counts: dict[str, int] = {}
        width, height = image.size
        if result.boxes is not None:
            for box in result.boxes:
                cls_id = int(box.cls[0].item())
                cls_name = str(names.get(cls_id, cls_id))
                if domain == "real" and cls_name not in COCO_INTERESTING:
                    continue
                confidence = float(box.conf[0].item())
                x1, y1, x2, y2 = [float(v) for v in box.xyxy[0].tolist()]
                x1 = max(0.0, min(float(width), x1))
                x2 = max(0.0, min(float(width), x2))
                y1 = max(0.0, min(float(height), y1))
                y2 = max(0.0, min(float(height), y2))
                if x2 - x1 < 2 or y2 - y1 < 2:
                    continue
                class_key = cls_name.replace(" ", "_")
                if domain == "abstract":
                    class_key = cls_name
                counts[class_key] = counts.get(class_key, 0) + 1
                detections.append(
                    {
                        "class": class_key,
                        "label": LABELS_ZH.get(class_key, cls_name),
                        "confidence": round(confidence, 4),
                        "x": round(x1, 2),
                        "y": round(y1, 2),
                        "w": round(x2 - x1, 2),
                        "h": round(y2 - y1, 2),
                    }
                )
        detections.sort(key=lambda d: d["confidence"], reverse=True)
        self.last_ms = round((time.perf_counter() - started) * 1000, 1)
        return {
            "detections": detections,
            "counts": counts,
            "ms": self.last_ms,
            "source": "abstract-yolo" if domain == "abstract" else "coco-yolo",
            "image": {"width": width, "height": height},
        }
