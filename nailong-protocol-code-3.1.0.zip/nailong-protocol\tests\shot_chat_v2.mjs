import { chromium } from "playwright-core";
import { resolve } from "node:path";
const root = resolve(import.meta.dirname, "..");
const browser = await chromium.launch({ executablePath: "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe", headless: true, args: ["--disable-gpu"] });
const page = await browser.newPage({ viewport: { width: 1600, height: 900 } });
const errors = [];
page.on("console", (m) => { if (m.type() === "error") errors.push(m.text()); });
page.on("pageerror", (e) => errors.push(e.message));
await page.goto("http://127.0.0.1:8000", { waitUntil: "networkidle" });
await page.waitForTimeout(2400);
await page.click("#start-btn");
await page.waitForTimeout(250);
await page.locator(".level-card").first().click();
await page.waitForTimeout(700);
await page.click('[data-action="chat"]');
await page.waitForTimeout(300);
const asks = ["1+1 等于几", "现在几点", "这关怎么打", "什么是光合作用", "我刚才问了什么"];
for (const text of asks) {
  await page.fill("#chat-input", text);
  await page.press("#chat-input", "Enter");
  await page.waitForTimeout(text === "什么是光合作用" || text === "我刚才问了什么" ? 4500 : 800);
}
const log = await page.locator("#chat-log").innerText();
console.log(log.slice(-1600));
console.log("errors", errors);
await page.screenshot({ path: resolve(root, "demo", "chat-v2.png") });
await browser.close();
