import { chromium } from "playwright-core";
import { resolve } from "node:path";
const root = resolve(import.meta.dirname, "..");
const browser = await chromium.launch({ executablePath: "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe", headless: true, args: ["--disable-gpu"] });
const page = await browser.newPage({ viewport: { width: 1600, height: 900 } });
const errors = [];
page.on("pageerror", (e) => errors.push(e.message));
await page.goto("http://127.0.0.1:8000/?debug", { waitUntil: "networkidle" });
await page.waitForTimeout(2400);
await page.click("#start-btn");
await page.waitForTimeout(250);
await page.evaluate(() => {
  const { game: g, ui } = window.__nailong;
  ui.showGame();
  g.startLevel(9);
  g.agent = null;
  g.events.onToast = () => {};
  g.events.onNotice = () => {};
  g.sun = 9999;
  for (const row of [0, 1, 2, 3]) {
    for (const [type, col] of [["flower", 0], ["pea", 1], ["frost", 2], ["cannon", 3], ["wall", 4]]) {
      g.readyAt[type] = 0;
      g.placePlant(type, col, row);
    }
  }
  const types = ["basic", "fast", "paper", "coffee", "boss"];
  types.forEach((type, row) => {
    g.spawnZombie(type, row);
    const z = g.zombies[g.zombies.length - 1];
    z.x = 880 + row * 35;
    z.abilityTimer = 99;
  });
  g.wave = 1;
  g.waveActive = true;
  g.stats.kills = 23;
  g.stats.plantsPlaced = 20;
  g.texts = [];
  ui.setDialogue("检查一下新敌人：早八人、滑板人、论文僵尸、续命人，还有终审导师。");
});
await page.waitForTimeout(700);
await page.evaluate(() => {
  const g = window.__nailong.game;
  g.pause();
  g.texts = [];
  document.querySelector("#toast-layer").innerHTML = "";
});
await page.waitForTimeout(200);
await page.screenshot({ path: resolve(root, "demo", "enemies-in-game.png") });
console.log("errors", errors);
await browser.close();
