import { chromium } from "playwright-core";
const browser = await chromium.launch({ executablePath: "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe", headless: true, args: ["--disable-gpu"] });
const page = await browser.newPage({ viewport: { width: 1600, height: 900 } });
const errors = [];
page.on("pageerror", (e) => errors.push(e.message));
await page.goto("http://127.0.0.1:8000/?debug", { waitUntil: "networkidle" });
await page.waitForTimeout(2400);
const result = await page.evaluate(() => {
  const { game: g, ui } = window.__nailong;
  ui.showGame();
  g.startLevel(0);
  g.screen = "playing";
  g.waveActive = false;
  g.prepTimer = 60;
  g.events.onToast = () => {};
  g.events.onNotice = () => {};
  g.sun = 9999;
  for (const id of ["flower", "pea", "doublepea", "wall", "frost", "fan", "bomb", "cannon", "vacuum", "boomerang", "seal"]) g.readyAt[id] = 0;
  g.placePlant("pea", 3, 0);
  g.placePlant("doublepea", 6, 0);
  const single = g.plants.find((p) => p.type === "pea");
  const dual = g.plants.find((p) => p.type === "doublepea");
  single.shootTimer = 0;
  dual.shootTimer = 0;
  const before = { single: single.hp, dual: dual.hp };
  for (let i = 0; i < 80; i++) g.update(0.05);
  const duel = { single: single.hp, dual: dual.hp, announced: g.duelRows.has(0) };

  // Remove the double so the survivor can go back to shooting zombies.
  dual.dead = true;
  g.plants = g.plants.filter((p) => p !== dual);
  g.spawnZombie("basic", 0);
  const z = g.zombies[g.zombies.length - 1];
  z.x = 980;
  z.baseSpeed = 0;
  z.speed = 0;
  single.shootTimer = 0;
  const zBefore = z.hp;
  for (let i = 0; i < 70; i++) g.update(0.05);
  return { before, duel, normal: { zBefore, zAfter: z.hp, single: single.hp }, errors: [] };
});
console.log(JSON.stringify(result, null, 2));
console.log("errors", errors);
const ok = result.duel.single < result.before.single && result.duel.dual < result.before.dual && result.normal.zAfter < result.normal.zBefore;
if (!ok) {
  console.error("FAIL single/double duel");
  process.exitCode = 1;
} else {
  console.log("PASS single/double duel and normal zombie attack");
}
await page.screenshot({ path: "demo/mouth-duel.png" });
await browser.close();
