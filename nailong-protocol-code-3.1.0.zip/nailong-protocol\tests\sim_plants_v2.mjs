﻿import { chromium } from "playwright-core";
const browser = await chromium.launch({ executablePath: "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe", headless: true, args: ["--disable-gpu"] });
const page = await browser.newPage({ viewport: { width: 1600, height: 900 } });
const errors = [];
page.on("pageerror", (e) => errors.push(e.message));
await page.goto("http://127.0.0.1:8000/?debug", { waitUntil: "networkidle" });
await page.waitForTimeout(2300);
const result = await page.evaluate(() => {
  const { game: g } = window.__nailong;
  g.agent = null;
  g.events.onEnd = () => {};
  g.startLevel(4);
  g.screen = "playing";
  g.sun = 9999;
  const spots = [
    ["flower", 0, 0], ["flower", 0, 4], ["pea", 1, 0], ["pea", 1, 3],
    ["wall", 3, 0], ["wall", 3, 4], ["frost", 2, 2], ["fan", 2, 4],
    ["cannon", 4, 1], ["vacuum", 4, 3], ["boomerang", 3, 2], ["seal", 4, 2], ["bomb", 5, 2],
  ];
  for (const [type, col, row] of spots) { g.readyAt[type] = 0; g.placePlant(type, col, row); }
  for (let i = 0; i < 7; i++) g.spawnZombie(i === 0 ? "boss" : i % 2 ? "paper" : "fast", i % 5);
  const kinds = new Set();
  const startKills = g.stats.kills;
  for (let i = 0; i < 700; i++) {
    g.update(0.05);
    for (const p of g.projectiles) kinds.add(p.kind);
  }
  return {
    screen: g.screen, kills: g.stats.kills - startKills, plants: g.plants.length,
    kinds: [...kinds], hp: g.houseHp, zombies: g.zombies.length,
  };
});
console.log(JSON.stringify(result, null, 2));
console.log("errors", errors);
await browser.close();
