import { chromium } from "playwright-core";
const browser = await chromium.launch({ executablePath: "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe", headless: true, args: ["--disable-gpu"] });
const page = await browser.newPage({ viewport: { width: 1600, height: 900 } });
const errs=[]; page.on("pageerror",e=>errs.push(e.message));
await page.goto("http://127.0.0.1:8000/?debug", { waitUntil: "networkidle" });
await page.waitForTimeout(2400);
await page.evaluate(() => { const {game:g,ui}=window.__nailong; ui.showGame(); g.startLevel(0); g.screen="playing"; g.waveActive=false; g.prepTimer=60; g.events.onToast=()=>{}; g.events.onNotice=()=>{}; g.sun=9999; for (const id of ["flower","pea","doublepea","wall","frost","fan","bomb","cannon","vacuum","boomerang","seal"]) g.readyAt[id]=0; g.placePlant("doublepea",6,0); g.placePlant("flower",4,0); g.placePlant("wall",5,0); });
await page.waitForTimeout(2200);
const result=await page.evaluate(()=>{ const g=window.__nailong.game; const dp=g.plants.find(p=>p.type==="doublepea"); const fl=g.plants.find(p=>p.type==="flower"); const wl=g.plants.find(p=>p.type==="wall"); return {cards:document.querySelectorAll(".seed-dock .plant-card").length, doublepea:!!dp, flowerHp:fl?.hp, wallHp:wl?.hp, projectiles:g.projectiles.filter(p=>p.friendly).length, cols:12}; });
console.log(JSON.stringify(result,null,2)); console.log("errs", errs);
await page.screenshot({ path: "demo/new-plant.png" });
if (!(result.cards === 11 && result.doublepea && result.flowerHp === 290 && result.wallHp === 1240 && result.cols === 12)) {
  console.error("FAIL doublepea / 11 cards"); process.exitCode = 1;
} else {
  console.log("PASS doublepea + 11 cards");
}
await browser.close();
