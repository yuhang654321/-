from __future__ import annotations

import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DIST = ROOT / "dist"
MODELS = Path(os.environ.get("NAILONG_MODELS_DIR", ROOT / "models"))
ASSETS = ROOT / "public" / "assets"

LMSTUDIO_URL = os.environ.get("LMSTUDIO_URL", "http://127.0.0.1:1234/v1").rstrip("/")
LMSTUDIO_MODEL = os.environ.get("LMSTUDIO_MODEL", "")
VISION_MODEL = Path(os.environ.get("YOLO_MODEL", MODELS / "abstract_yolo.pt"))
COCO_MODEL = Path(os.environ.get("YOLO_COCO_MODEL", MODELS / "yolo11n.pt"))
ALLOW_ORIGINS = [
    origin.strip()
    for origin in os.environ.get(
        "NAILONG_ALLOW_ORIGINS",
        "http://127.0.0.1:5173,http://localhost:5173,http://127.0.0.1:8000,http://localhost:8000",
    ).split(",")
    if origin.strip()
]

APP_VERSION = "3.1.0"
