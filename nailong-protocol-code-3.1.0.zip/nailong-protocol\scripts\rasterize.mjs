import { readFileSync, writeFileSync, readdirSync, mkdirSync } from "node:fs";
import { join, resolve } from "node:path";
import { Resvg } from "@resvg/resvg-js";

const root = resolve(import.meta.dirname, "..");
const src = join(root, "assets", "svg");
const out = join(root, "public", "assets", "sprites");
mkdirSync(out, { recursive: true });

for (const file of readdirSync(src).filter((f) => f.endsWith(".svg"))) {
  const svg = readFileSync(join(src, file), "utf8");
  const resvg = new Resvg(svg, {
    fitTo: { mode: "width", value: 512 },
    font: { loadSystemFonts: true, defaultFontFamily: "Microsoft YaHei" },
    background: "rgba(0,0,0,0)",
  });
  const png = resvg.render().asPng();
  writeFileSync(join(out, file.replace(/\.svg$/, ".png")), png);
  console.log("rasterized", file);
}
