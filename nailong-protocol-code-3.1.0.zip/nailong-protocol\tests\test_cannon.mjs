﻿import { chromium } from "playwright-core";
const browser = await chromium.launch({ executablePath: "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe", headless: true, args: ["--disable-gpu"] });
const page = await browser.newPage({ viewport: { width: 1600, height: 900 } });
const errs=[]; page.on("pageerror",e=>errs.push(e.message));
await page.goto("http://127.0.0.1:8000/?debug", { waitUntil: "networkidle" });
await page.waitForTimeout(2400);
const result = await page.evaluate(() => {
  const { game: g, ui } = window.__nailong;
  ui.showGame(); g.startLevel(0); g.screen="playing"; g.waveActive=false; g.prepTimer=60;
  g.events.onToast=()=>{}; g.events.onNotice=()=>{};
  g.sun=9999; for (const id of ["flower","pea","doublepea","wall","frost","fan","bomb","cannon","vacuum","boomerang","seal"]) g.readyAt[id]=0;
  g.placePlant("cannon", 1, 0);
  const cannon=g.plants.find(p=>p.type==="cannon");
  g.spawnZombie("basic",0); const z1=g.zombies[g.zombies.length-1];
  g.spawnZombie("basic",0); const z2=g.zombies[g.zombies.length-1];
  z1.x=760; z2.x=1040; z1.row=0; z2.row=0;
  for (const z of [z1,z2]) { z.baseSpeed=0; z.speed=0; z.hp=z.maxHp; }
  cannon.shootTimer=0;
  for (let i=0;i<80;i++) g.update(0.05);
  return {
    nearHp:z1.hp, farHp:z2.hp, nearMax:z1.maxHp, farMax:z2.maxHp,
    cannonX:Math.round(cannon.x), farX:Math.round(z2.x),
    projectiles:g.projectiles.map(p=>({kind:p.kind,x:Math.round(p.x),target:p.targetZombieUid,dead:p.dead})),
    kills:g.stats.kills
  };
});
console.log(JSON.stringify(result,null,2)); console.log("errs",errs);
await page.screenshot({ path: "demo/cannon-farthest.png" });
const ok=result.farHp < result.farMax && result.nearHp === result.nearMax;
console.log(ok?"PASS cannon farthest":"FAIL cannon farthest");
if(!ok) process.exitCode=1;
await browser.close();
