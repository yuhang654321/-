﻿import { chromium } from "playwright-core";

const browser = await chromium.launch({
  executablePath: "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe",
  headless: true,
  args: ["--disable-gpu"],
});
const page = await browser.newPage({ viewport: { width: 1600, height: 900 } });
const errors = [];
page.on("pageerror", (e) => errors.push(e.message));
await page.goto("http://127.0.0.1:8000/?debug", { waitUntil: "networkidle" });
await page.waitForTimeout(2300);
const result = await page.evaluate(() => {
  const g = window.__nailong.game;
  g.agent = null;
  g.startClassic();
  g.screen = "playing";
  const log = [];
  let lastWave = 0;
  let placed = 0;
  for (let i = 0; i < 16000; i++) {
    g.sun = 9999;
    for (const id of ["flower", "pea", "wall", "frost", "fan", "bomb"]) g.readyAt[id] = 0;
    // Collect all suns.
    for (const s of g.suns) { g.sun += s.value; s.collected = true; }
    // Build a dense but not insane defense.
    for (let row = 0; row < 5; row++) {
      const layout = [
        ["flower", 0],
        ["pea", 1],
        ["pea", 2],
        ["frost", 3],
        ["wall", 5],
      ];
      for (const [type, col] of layout) {
        if (!g.plants.some((p) => p.row === row && p.col === col && !p.dead)) {
          g.placePlant(type, col, row);
          placed++;
        }
      }
    }
    g.update(0.05);
    if (g.wave !== lastWave) { lastWave = g.wave; log.push({ wave: g.wave, t: g.time.toFixed(1), hp: g.houseHp }); }
    if (g.screen === "won" || g.screen === "lost") break;
  }
  return { screen: g.screen, wave: g.wave, time: g.time, hp: g.houseHp, kills: g.stats.kills, placed, log, errors: [] };
});
console.log(JSON.stringify(result, null, 2));
console.log("page errors", errors);
await browser.close();
