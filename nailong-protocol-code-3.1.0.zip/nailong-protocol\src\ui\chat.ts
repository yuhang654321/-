import type { Game } from "../game/engine";
import type { AgentReply, ChatTurn } from "../types";
import { CHAT_CHIPS, CHAT_FALLBACK } from "../game/content";
import type { ModalHost } from "./modal";

const face = (name = "mascot_face") => `${import.meta.env.BASE_URL}assets/sprites/${name}.png`;

const ACTIONS: Record<string, string> = {
  grant_sun: "行动：奶龙打赏灵感",
  heal: "行动：植物回血",
  spawn: "行动：奶龙投放节目效果",
  bless: "行动：不正规护盾",
  favor: "行动：奶龙破例宠你",
  tip: "行动：奶龙小额打赏",
};

const IDLE_OPENERS = [
  "现在没怪，正好。你可以问我点难的，我会联网查；也可以叫姐姐换 30 灵感。",
  "闲着也是闲着。问我一个你一直没搞懂的问题吧，我不会再背那几句固定傲娇台词了。",
  "没有僵尸的时候，我的脑子终于能转。你可以试试难一点的，或者叫姐姐骗 30 灵感。",
  "这波还没开始。想聊新闻、学习、电脑、冷笑话都行；难的我会先查再答。",
];

export class ChatController {
  private game: Game;
  private modal: ModalHost;
  private getModel: () => string;
  private log: HTMLElement | null = null;
  private form: HTMLFormElement | null = null;
  private input: HTMLInputElement | null = null;
  private sending = false;
  private opened = false;
  private history: ChatTurn[] = [];

  constructor(game: Game, modal: ModalHost, getModel: () => string) {
    this.game = game;
    this.modal = modal;
    this.getModel = getModel;
  }

  open(onClose?: () => void) {
    if (this.opened) return;
    this.opened = true;
    const chips = CHAT_CHIPS.map((c) => `<button type="button" class="chat-chip" data-chip="${c}">${c}</button>`).join("");
    const model = this.getModel();
    const snap = this.game.snapshot();
    const idle = !this.game.waveActive && snap.zombies === 0;
    const opener = idle
      ? IDLE_OPENERS[Math.floor(Math.random() * IDLE_OPENERS.length)]
      : "你终于醒了。左边是睡眠舱，右边是早八。中间这些植物是我从梦里薅出来的。说吧，想让我干什么？";
    const context = `<div class="chat-context">
      <span>${snap.levelName} / WAVE ${String(snap.wave).padStart(2, "0")}·${snap.totalWaves}</span>
      <span>睡眠舱 ${snap.hp}%</span>
      <span>植物 ${snap.plants}</span>
      <span>僵尸 ${snap.zombies}</span>
      <span>灵感 ${snap.sun}</span>
    </div>`;
    const el = this.modal.show(
      `<div class="modal chat-modal">
        <button class="modal-close" data-close aria-label="关闭">×</button>
        <div class="chat-head">
          <div class="big-face"><img src="${face()}" alt="奶龙博士" /></div>
          <div>
            <h3>奶龙博士</h3>
            <div class="sub">LOCAL QWEN · 联网检索 · 偶尔真的聪明</div>
          </div>
          <div class="model-pill">${model || "QWEN / LOCAL"}</div>
        </div>
        <div class="chat-log" id="chat-log" aria-live="polite">
          <div class="msg ai">
            <div class="avatar"><img src="${face()}" alt="" /></div>
            <div class="bubble">${opener}<br /><span class="tiny" style="opacity:.5">游戏规则、这关怎么打、现在几点、1+1 这种简单问题都能问；难的、新的、需要查资料的，我会先联网再慢慢答。以及……想拿小奖励，叫声姐姐。</span></div>
          </div>
          ${context}
        </div>
        <div class="chat-chips">${chips}</div>
        <form class="chat-form" id="chat-form">
          <input id="chat-input" maxlength="120" autocomplete="off" placeholder="问点难的，或者叫姐姐……（Enter 发送）" />
          <button type="submit">发送</button>
        </form>
      </div>`,
      () => {
        this.opened = false;
        this.log = null;
        this.form = null;
        this.input = null;
        onClose?.();
      },
    );
    this.log = el.querySelector("#chat-log");
    this.form = el.querySelector("#chat-form");
    this.input = el.querySelector("#chat-input");
    this.form?.addEventListener("submit", (event) => {
      event.preventDefault();
      void this.send(this.input?.value ?? "");
    });
    el.querySelectorAll<HTMLButtonElement>("[data-chip]").forEach((btn) => {
      btn.addEventListener("click", () => {
        const text = btn.dataset.chip ?? "";
        if (this.input) this.input.value = "";
        void this.send(text);
      });
    });
  }

  close() {
    this.modal.close();
  }

  private async append(
    role: "ai" | "user",
    text: string,
    action?: AgentReply["action"],
    sources?: AgentReply["sources"],
    animate = false,
  ): Promise<void> {
    if (!this.log) return;
    const div = document.createElement("div");
    div.className = `msg ${role}`;
    const avatar =
      role === "ai"
        ? `<div class="avatar"><img src="${face()}" alt="" /></div>`
        : `<div class="avatar">07</div>`;
    div.innerHTML = `${avatar}<div class="bubble"></div>`;
    const bubble = div.querySelector<HTMLElement>(".bubble")!;
    this.log.appendChild(div);
    if (role === "user" || !animate) {
      bubble.textContent = text;
    } else {
      bubble.textContent = "";
      const total = text.length;
      const step = Math.max(1, Math.ceil(total / 62));
      await new Promise<void>((resolve) => {
        let cursor = 0;
        const timer = window.setInterval(() => {
          cursor = Math.min(total, cursor + step);
          bubble.textContent = text.slice(0, cursor);
          this.scroll();
          if (cursor >= total) {
            window.clearInterval(timer);
            resolve();
          }
        }, 22);
      });
    }
    const tag = action && action.type !== "none" ? `<span class="action-tag">${ACTIONS[action.type] ?? "行动已执行"}</span>` : "";
    if (tag) bubble.insertAdjacentHTML("beforeend", `<br />${tag}`);
    if (sources?.length) this.appendSources(bubble, sources);
    this.scroll();
  }

  private appendSources(bubble: HTMLElement, sources: { title: string; url: string }[]) {
    const wrap = document.createElement("div");
    wrap.className = "chat-sources";
    const title = document.createElement("span");
    title.textContent = "联网来源 · ";
    wrap.appendChild(title);
    sources.slice(0, 3).forEach((source, index) => {
      if (index > 0) wrap.appendChild(document.createTextNode(" / "));
      const link = document.createElement("a");
      link.textContent = source.title.slice(0, 32) || "来源";
      if (/^https?:\/\//i.test(source.url)) {
        link.href = source.url;
        link.target = "_blank";
        link.rel = "noopener noreferrer";
      }
      wrap.appendChild(link);
    });
    bubble.appendChild(wrap);
  }

  private scroll() {
    if (this.log) this.log.scrollTop = this.log.scrollHeight;
  }

  private async send(raw: string) {
    const message = raw.trim().slice(0, 120);
    if (!message || this.sending) return;
    this.sending = true;
    await this.append("user", message);
    this.history.push({ role: "user", content: message });
    this.history = this.history.slice(-10);
    if (this.input) this.input.value = "";
    const loading = document.createElement("div");
    loading.className = "chat-loading";
    const hard = /为什么|是什么|什么是|怎么|区别|最新|新闻|查|搜|是谁|推荐|吗|？|\?/.test(message);
    loading.textContent = hard
      ? "> 这题有点难：先联网查资料，再让本地 Qwen 慢慢组织……"
      : "> 奶龙正在调动它仅有的一个脑细胞 + 本地 Qwen ...";
    this.log?.appendChild(loading);
    this.scroll();
    try {
      const reply = await this.game.chat(message, this.history.slice(0, -1));
      loading.remove();
      await this.append("ai", reply.reply, reply.action, reply.sources, true);
      this.history.push({ role: "assistant", content: reply.reply });
      this.history = this.history.slice(-10);
      if (reply.researched) {
        const note = document.createElement("div");
        note.className = "chat-loading";
        note.textContent = "✓ 已联网检索 · 资料在回答下方，自己再核对一眼。";
        this.log?.appendChild(note);
        this.scroll();
      } else if (reply.source === "fallback" || reply.source === "tool") {
        const note = document.createElement("div");
        note.className = "chat-loading";
        note.textContent =
          reply.source === "tool" ? "✓ 本地工具回答 · 不经过大模型，算得准。" : "! 本地大模型未响应，以上由离线人格备份生成。";
        this.log?.appendChild(note);
        this.scroll();
      }
    } catch {
      loading.remove();
      await this.append("ai", CHAT_FALLBACK[message] ?? "我卡住了。不是我的问题，是早八的问题。", undefined, undefined, true);
    } finally {
      this.sending = false;
      this.input?.focus();
    }
  }
}
