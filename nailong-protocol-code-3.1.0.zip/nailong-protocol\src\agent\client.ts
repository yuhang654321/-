import type { AgentReply, ChatTurn, DirectorEvent, GameSnapshot, VisionReport } from "../types";
import { FALLBACK_EVENTS, MODIFIER_POOL } from "../game/content";

const BASE = (import.meta.env.VITE_API_BASE as string | undefined) ?? "";

export interface HealthInfo {
  ok: boolean;
  llm: {
    online: boolean;
    model?: string;
    endpoint?: string;
    latency_ms?: number;
  };
  vision: {
    ready: boolean;
    model?: string;
    classes?: string[];
    device?: string;
    error?: string;
  };
  version?: string;
}

async function request<T>(path: string, init?: RequestInit, timeoutMs = 12000): Promise<T> {
  const ctrl = new AbortController();
  const timer = window.setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(`${BASE}${path}`, {
      ...init,
      signal: ctrl.signal,
      headers: {
        "Content-Type": "application/json",
        ...(init?.headers ?? {}),
      },
    });
    if (!res.ok) {
      const body = await res.text().catch(() => "");
      throw new Error(`${res.status} ${body.slice(0, 180)}`);
    }
    return (await res.json()) as T;
  } finally {
    window.clearTimeout(timer);
  }
}

export class AgentClient {
  health: HealthInfo | null = null;
  lastError = "";
  private offlineUntil = 0;
  private healthPromise: Promise<HealthInfo> | null = null;

  async checkHealth(force = false): Promise<HealthInfo> {
    if (!force && this.health && performance.now() < this.offlineUntil && this.health.ok) return this.health;
    if (this.healthPromise) return this.healthPromise;
    this.healthPromise = (async () => {
      try {
        const h = await request<HealthInfo>("/api/health", { method: "GET" }, 5000);
        this.health = h;
        this.offlineUntil = 0;
        return h;
      } catch (err) {
        this.lastError = String(err);
        this.offlineUntil = performance.now() + 20000;
        this.health = {
          ok: false,
          llm: { online: false },
          vision: { ready: false, error: "backend offline" },
        };
        return this.health;
      } finally {
        this.healthPromise = null;
      }
    })();
    return this.healthPromise;
  }

  async director(payload: { wave: number; snapshot: GameSnapshot }): Promise<DirectorEvent> {
    if (performance.now() < this.offlineUntil) {
      return this.fallbackDirector(payload.wave);
    }
    try {
      const ev = await request<DirectorEvent>(
        "/api/director",
        { method: "POST", body: JSON.stringify(payload) },
        14000,
      );
      if (!ev || typeof ev.title !== "string" || typeof ev.line !== "string") throw new Error("bad director payload");
      return ev;
    } catch (err) {
      this.lastError = String(err);
      this.offlineUntil = performance.now() + 25000;
      return this.fallbackDirector(payload.wave);
    }
  }

  private fallbackDirector(wave: number): DirectorEvent {
    const mod = MODIFIER_POOL[Math.floor(Math.random() * MODIFIER_POOL.length)];
    const base = FALLBACK_EVENTS[mod];
    return { ...base, line: `${base.line}（第 ${wave} 波·本地备份剧本）`, source: "fallback" };
  }

  async chat(payload: { message: string; snapshot: GameSnapshot; history?: ChatTurn[] }): Promise<AgentReply> {
    if (performance.now() < this.offlineUntil) {
      throw new Error("agent offline");
    }
    const reply = await request<AgentReply>(
      "/api/chat",
      { method: "POST", body: JSON.stringify(payload) },
      45000,
    );
    if (!reply || typeof reply.reply !== "string") throw new Error("bad chat payload");
    return reply;
  }

  async vision(image: string, domain: "abstract" | "real" = "abstract", conf = 0.45): Promise<VisionReport> {
    return request<VisionReport>(
      "/api/vision/detect",
      { method: "POST", body: JSON.stringify({ image, domain, conf }) },
      15000,
    );
  }
}
