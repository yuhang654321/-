﻿import { chromium } from "playwright-core";

const browser = await chromium.launch({ executablePath: "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe", headless: true, args: ["--disable-gpu"] });
const page = await browser.newPage({ viewport: { width: 1600, height: 900 } });
await page.goto("http://127.0.0.1:8000/?debug", { waitUntil: "networkidle" });
await page.waitForTimeout(2300);
const result = await page.evaluate(() => {
  const g = window.__nailong.game;
  g.agent = null;
  g.startClassic();
  g.screen = "playing";
  const build = [];
  for (let row = 0; row < 5; row++) {
    build.push(["flower", 0], ["pea", 1], ["wall", 4], ["pea", 2], ["frost", 3], ["fan", 2]);
  }
  let next = 0;
  let lastWave = 0;
  const waveLog = [];
  for (let i = 0; i < 20000; i++) {
    for (const s of g.suns) { g.sun += s.value; s.collected = true; }
    // Try each desired slot in order, but only one successful placement every ~2 ticks.
    if (next < build.length && i % 20 === 0) {
      const [type, col] = build[next];
      const row = next % 5;
      if (!g.plants.some((p) => p.row === row && p.col === col && !p.dead) && g.canPlace(type)) {
        g.placePlant(type, col, row);
        next++;
      } else if (g.plants.some((p) => p.row === row && p.col === col && !p.dead)) {
        next++;
      }
    }
    // Emergency: fill empty lane fronts with walls if possible.
    if (i % 60 === 0 && g.sun > 100) {
      for (let row = 0; row < 5; row++) {
        if (!g.plants.some((p) => p.row === row && p.col === 5 && !p.dead) && g.canPlace("wall")) g.placePlant("wall", 5, row);
      }
    }
    g.update(0.05);
    if (g.wave !== lastWave) { lastWave = g.wave; waveLog.push({ wave: g.wave, t: Math.round(g.time), sun: Math.round(g.sun), plants: g.plants.length, hp: Math.round(g.houseHp) }); }
    if (g.screen === "won" || g.screen === "lost") break;
  }
  return { screen: g.screen, wave: g.wave, time: Math.round(g.time), hp: g.houseHp, kills: g.stats.kills, plants: g.plants.length, sun: Math.round(g.sun), waveLog };
});
console.log(JSON.stringify(result, null, 2));
await browser.close();
