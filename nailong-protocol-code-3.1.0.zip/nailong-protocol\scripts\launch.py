from __future__ import annotations

import argparse
import sys
import threading
import time
import urllib.request
import webbrowser
from pathlib import Path

import uvicorn

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


def open_when_ready(url: str, timeout: float = 90.0) -> None:
    """Open the browser only after FastAPI and the YOLO warmup are ready.

    Without this, clicking the desktop shortcut can open the browser while the
    model is still loading, which looks like a broken app.
    """
    health = f"{url}/api/health"
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            with urllib.request.urlopen(health, timeout=1.5) as resp:
                if 200 <= resp.status < 300:
                    webbrowser.open(url)
                    return
        except Exception:
            pass
        time.sleep(0.35)
    webbrowser.open(url)


def main() -> None:
    parser = argparse.ArgumentParser(description="Launch NAILONG PROTOCOL")
    parser.add_argument("--port", type=int, default=8000)
    parser.add_argument("--no-browser", action="store_true")
    parser.add_argument("--reload", action="store_true")
    args = parser.parse_args()
    url = f"http://127.0.0.1:{args.port}"
    print("\n  NAILONG PROTOCOL / 奶龙协议：早八植物园")
    print(f"  → {url}")
    print("  → LM Studio expected at http://127.0.0.1:1234/v1")
    print("  → Ctrl+C to stop\n")
    if not args.no_browser:
        threading.Thread(target=open_when_ready, args=(url,), daemon=True).start()
    uvicorn.run(
        "server.app:app",
        host="127.0.0.1",
        port=args.port,
        reload=args.reload,
        log_level="info",
    )


if __name__ == "__main__":
    main()
