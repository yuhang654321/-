import "./style.css";
import { preloadSprites } from "./game/assets";
import { AudioEngine } from "./game/audio";
import { Game } from "./game/engine";
import { Renderer } from "./game/renderer";
import { AgentClient, type HealthInfo } from "./agent/client";
import { UI } from "./ui/ui";
import { ModalHost } from "./ui/modal";
import { ChatController } from "./ui/chat";
import { CameraController } from "./ui/camera";
import { PLANT_ORDER, BOARD, LEVELS } from "./game/content";

const app = document.getElementById("app")!;
const ui = new UI(app);
const game = new Game(new AudioEngine());
const renderer = new Renderer(ui.canvas);
const agent = new AgentClient();
const modal = new ModalHost(ui.modalRoot);
const chat = new ChatController(game, modal, () => ui.modelLabel);
const camera = new CameraController(game, agent, modal);

game.attachAgent(agent);
ui.attach(game);

if (import.meta.env.DEV || new URLSearchParams(window.location.search).has("debug")) {
  (window as unknown as { __nailong: unknown }).__nailong = { game, ui, renderer, agent };
}

let visualTime = 0;
let lastFrame = performance.now();
let lastScan = 0;
let scanFailures = 0;
let soundOn = localStorage.getItem("nl_sound") !== "0";
let musicOn = localStorage.getItem("nl_music") !== "0";
let endTimer = 0;
let bootDone = false;

const stage = document.getElementById("stage") as HTMLElement;
function fitStage() {
  const pad = 0;
  const scale = Math.min((window.innerWidth - pad) / 1600, (window.innerHeight - pad) / 900);
  stage.style.transform = `scale(${scale})`;
}
window.addEventListener("resize", fitStage);
fitStage();

function updateAudioButtons() {
  ui.setSoundButton(soundOn);
  ui.setMusicButton(musicOn);
  game.audio.setMuted(!soundOn);
  game.audio.setMusic(musicOn);
}

function beginAudioAndUi() {
  ui.hideEnd();
  ui.showGame();
  game.audio.ensure();
  game.audio.startMusic();
  updateAudioButtons();
  game.audio.setVoice(false);
  scanFailures = 0;
  lastScan = performance.now() + 1000;
  void refreshHealth();
}

function startLevel(index: number) {
  modal.close();
  window.clearTimeout(endTimer);
  beginAudioAndUi();
  game.startLevel(index);
  const lvl = LEVELS[index];
  ui.setDialogue(`${lvl.subtitle} 规则：${lvl.rule === "none" ? "无额外舞台效果" : lvl.rule.toUpperCase()}。先种奶龙花，再补嘴替奶龙。`);
}

function startClassic() {
  modal.close();
  window.clearTimeout(endTimer);
  beginAudioAndUi();
  game.startClassic();
  ui.setDialogue("经典模式：10 波完整早八。AI 导演全程自由发挥，守住就好。");
}

function restartCurrent() {
  if (game.mode === "classic") startClassic();
  else startLevel(game.levelIndex);
}

function openLevels() {
  modal.close();
  window.clearTimeout(endTimer);
  ui.hideEnd();
  game.reset();
  game.screen = "title";
  ui.showLevels();
}

function goTitle() {
  modal.close();
  window.clearTimeout(endTimer);
  ui.hideEnd();
  game.reset();
  game.screen = "title";
  ui.showTitle();
}

function openHelp(resume: boolean) {
  if (modal.open) modal.close();
  const el = modal.show(ui.howtoMarkup(), () => {
    if (resume && game.screen === "paused") game.resume();
  });
  el.querySelector<HTMLElement>("[data-close]")?.addEventListener("click", () => modal.close());
}

function openPause() {
  if (modal.open) return;
  const wasPlaying = game.screen === "playing";
  if (wasPlaying) game.pause();
  let shouldResume = wasPlaying;
  const el = modal.show(ui.pauseMarkup(game.stats), () => {
    if (shouldResume && game.screen === "paused") game.resume();
  });
  el.querySelector("#pause-resume")?.addEventListener("click", () => {
    shouldResume = false;
    modal.close();
    if (game.screen === "paused") game.resume();
  });
  el.querySelector("#pause-restart")?.addEventListener("click", () => {
    shouldResume = false;
    modal.close();
    restartCurrent();
  });
  el.querySelector("#pause-title")?.addEventListener("click", () => {
    shouldResume = false;
    modal.close();
    goTitle();
  });
  el.querySelector("#pause-help")?.addEventListener("click", () => {
    shouldResume = false;
    modal.close();
    window.setTimeout(() => openHelp(true), 20);
  });
}

function openChat() {
  if (modal.open) return;
  const wasPlaying = game.screen === "playing";
  if (wasPlaying) game.pause();
  chat.open(() => {
    if (wasPlaying && game.screen === "paused") game.resume();
  });
}

function openCamera() {
  if (modal.open) return;
  const wasPlaying = game.screen === "playing";
  if (wasPlaying) game.pause();
  camera.open(() => {
    if (wasPlaying && game.screen === "paused") game.resume();
  });
}

function toggleVision() {
  const on = game.toggleVision();
  lastScan = 0;
  scanFailures = 0;
  ui.toast(
    on ? "第三只眼已打开。YOLO 每 2.6 秒看一次战场；按 X 或点「抽象解读」花 25% 同步率抽一张离谱判词。" : "第三只眼已关闭。现在只有你和你的拖延症。",
    on ? "#69e7ff" : "#8b7f9b",
  );
  if (on) void refreshHealth();
}

function toggleSound() {
  soundOn = !soundOn;
  localStorage.setItem("nl_sound", soundOn ? "1" : "0");
  game.audio.setMuted(!soundOn);
  updateAudioButtons();
}

function toggleMusic() {
  musicOn = !musicOn;
  localStorage.setItem("nl_music", musicOn ? "1" : "0");
  game.audio.setMusic(musicOn);
  updateAudioButtons();
}

async function refreshHealth(): Promise<HealthInfo> {
  const h = await agent.checkHealth(true);
  ui.setHealth(h);
  return h;
}

async function maybeScan(now: number) {
  if (game.screen !== "playing" || !game.visionVisible || game.visionBusy || modal.open) return;
  if (now - lastScan < 2600) return;
  lastScan = now;
  game.visionBusy = true;
  try {
    const crop = document.createElement("canvas");
    crop.width = Math.round(BOARD.w);
    crop.height = Math.round(BOARD.h);
    const cropCtx = crop.getContext("2d");
    if (!cropCtx) throw new Error("crop canvas unavailable");
    cropCtx.drawImage(ui.canvas, BOARD.x, BOARD.y, BOARD.w, BOARD.h, 0, 0, crop.width, crop.height);
    const image = crop.toDataURL("image/jpeg", 0.72);
    const report = await agent.vision(image, "abstract");
    game.setVisionReport(report, BOARD.x, BOARD.y);
    scanFailures = 0;
  } catch (err) {
    scanFailures++;
    if (scanFailures === 1) ui.toast("第三只眼没睁开：后端 YOLO 未就绪或模型未加载。", "#ff5d6c");
    if (scanFailures >= 3) {
      game.visionVisible = false;
      ui.toast("连续三次扫描失败，第三只眼已自动关闭。", "#ff5d6c");
    }
  } finally {
    game.visionBusy = false;
  }
}

function saveShareCard() {
  const grade = ui.gradeFor(game.screen === "won", game.stats, game.screen === "won" ? starsForHp(game.houseHp) : 0);
  const levelLabel =
    game.mode === "classic" ? "CLASSIC 10 WAVES" : `${game.level?.id ?? "L??"} · ${game.levelName}`;
  const starLabel = game.screen === "won" ? "★".repeat(starsForHp(game.houseHp)) + "☆".repeat(3 - starsForHp(game.houseHp)) : "";
  const c = document.createElement("canvas");
  c.width = 1200;
  c.height = 1500;
  const ctx = c.getContext("2d");
  if (!ctx) return;
  const bg = ctx.createLinearGradient(0, 0, 1200, 1500);
  bg.addColorStop(0, "#1b0d2f");
  bg.addColorStop(1, "#0d0718");
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, 1200, 1500);

  // Screenshot.
  ctx.save();
  ctx.fillStyle = "#140b23";
  ctx.fillRect(42, 170, 1116, 628);
  const sw = renderer.canvas.width;
  const sh = renderer.canvas.height;
  const scale = Math.max(1116 / sw, 628 / sh);
  const dw = sw * scale;
  const dh = sh * scale;
  ctx.beginPath();
  ctx.rect(42, 170, 1116, 628);
  ctx.clip();
  ctx.drawImage(renderer.canvas, 42 + (1116 - dw) / 2, 170 + (628 - dh) / 2, dw, dh);
  ctx.restore();
  ctx.strokeStyle = "#fff4d6";
  ctx.lineWidth = 4;
  ctx.strokeRect(42, 170, 1116, 628);

  // Doodles.
  ctx.fillStyle = "#dfff43";
  ctx.beginPath();
  ctx.arc(1070, 85, 92, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = "#1c102c";
  ctx.font = '900 24px "Courier New", monospace';
  ctx.textAlign = "center";
  ctx.fillText("EXPERIMENT", 1070, 78);
  ctx.fillText("REPORT 07", 1070, 103);

  ctx.textAlign = "left";
  ctx.fillStyle = "#ff3d8d";
  ctx.font = '900 36px "ZCOOL KuaiLe", "Microsoft YaHei", sans-serif';
  ctx.fillText("奶龙协议", 46, 78);
  ctx.fillStyle = "#fff4d6";
  ctx.font = '900 62px "ZCOOL KuaiLe", "Microsoft YaHei", sans-serif';
  ctx.fillText(game.screen === "won" ? "早八，防住了。" : "睡眠舱，失守。", 46, 137);
  ctx.fillStyle = "#dfff43";
  ctx.font = '900 15px "Courier New", monospace';
  ctx.fillText(`${levelLabel}  ${starLabel}`, 48, 160);

  // Grade.
  ctx.fillStyle = grade.grade === "S" ? "#ffd447" : grade.grade === "A" ? "#dfff43" : "#ff3d8d";
  ctx.beginPath();
  ctx.roundRect(900, 850, 250, 250, 12);
  ctx.fill();
  ctx.strokeStyle = "#1c102c";
  ctx.lineWidth = 8;
  ctx.stroke();
  ctx.fillStyle = "#1c102c";
  ctx.textAlign = "center";
  ctx.font = '900 174px "ZCOOL KuaiLe", "Microsoft YaHei", sans-serif';
  ctx.fillText(grade.grade, 1025, 1035);
  ctx.font = '900 16px "Courier New", monospace';
  ctx.fillText("ABSTRACTION GRADE", 1025, 1070);

  // Stats.
  const rows: [string, string][] = [
    ["WAVES", String(game.stats.waves)],
    ["KILLS", String(game.stats.kills)],
    ["PLANTS", String(game.stats.plantsPlaced)],
    ["SUN", String(game.stats.sunCollected)],
    ["YOLO SCANS", String(game.stats.yoloScans)],
    ["TIME", `${Math.floor(game.stats.time / 60)}:${String(Math.floor(game.stats.time % 60)).padStart(2, "0")}`],
  ];
  ctx.textAlign = "left";
  rows.forEach(([k, v], i) => {
    const x = 48 + (i % 3) * 270;
    const y = 880 + Math.floor(i / 3) * 145;
    ctx.fillStyle = "rgba(255,244,214,.55)";
    ctx.font = '900 14px "Courier New", monospace';
    ctx.fillText(k, x, y);
    ctx.fillStyle = "#fff4d6";
    ctx.font = '900 56px "ZCOOL KuaiLe", "Microsoft YaHei", sans-serif';
    ctx.fillText(v, x, y + 63);
  });

  // Quote & footer.
  ctx.fillStyle = "rgba(255,244,214,.8)";
  ctx.font = '24px "Noto Sans SC", "Microsoft YaHei", sans-serif';
  ctx.fillText(grade.title, 46, 1230);
  ctx.fillStyle = "rgba(255,244,214,.42)";
  ctx.font = '16px "Courier New", monospace';
  ctx.fillText("LOCAL LLM × CUSTOM YOLO × ZERO EXTERNAL ASSETS", 46, 1275);
  ctx.fillStyle = "#dfff43";
  ctx.font = '20px "Noto Sans SC", "Microsoft YaHei", sans-serif';
  ctx.fillText("奶龙协议：早八植物园 / NAILONG PROTOCOL", 46, 1420);
  ctx.textAlign = "right";
  ctx.fillStyle = "rgba(255,244,214,.35)";
  ctx.font = '14px "Courier New", monospace';
  ctx.fillText("SLEEP IS A HUMAN RIGHT.", 1154, 1420);

  // Tape marks.
  ctx.fillStyle = "rgba(255,244,214,.10)";
  for (let i = 0; i < 9; i++) {
    ctx.save();
    ctx.translate(60 + i * 135, 820);
    ctx.rotate(-0.18);
    ctx.fillRect(0, 0, 92, 8);
    ctx.restore();
  }

  c.toBlob((blob) => {
    if (!blob) return;
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `nailong-protocol-${grade.grade}-${Date.now()}.png`;
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 5000);
    ui.toast("战绩卡已生成。发出去，让早八看看。", "#ffd447");
  }, "image/png");
}

ui.bindHandlers({
  onStart: openLevels,
  onLevelStart: startLevel,
  onClassic: startClassic,
  onNext: () => {
    const next = game.levelIndex + 1;
    if (game.mode === "level" && next < LEVELS.length && ui.progress.isUnlocked(next)) startLevel(next);
  },
  onMap: openLevels,
  onHelp: () => openHelp(game.screen === "playing"),
  onPause: () => {
    if (game.screen === "playing") openPause();
    else if (game.screen === "paused") game.resume();
  },
  onResume: () => game.resume(),
  onRestart: restartCurrent,
  onTitle: goTitle,
  onChat: openChat,
  onCamera: openCamera,
  onSound: toggleSound,
  onMusic: toggleMusic,
  onVision: toggleVision,
  onVisionDraw: () => {
    game.drawVisionInterpretation();
  },
  onShovel: () => game.toggleShovel(),
  onShare: saveShareCard,
  onResetProgress: () => ui.toast("进度已重置。第一关重新对你敞开。", "#ffd447"),
});

function starsForHp(hp: number): number {
  if (hp >= 85) return 3;
  if (hp >= 50) return 2;
  return 1;
}

game.events = {
  onWave: (wave, event) => {
    ui.showBanner(wave, event);
    game.audio.setIntensity(Math.min(1, wave / Math.max(1, game.totalWaves)));
  },
  onToast: (text, color) => ui.toast(text, color),
  onEnd: (win, stats) => {
    window.clearTimeout(endTimer);
    const isLevel = stats.mode === "level" && stats.levelIndex !== undefined && stats.levelIndex >= 0;
    const levelIndex = isLevel ? stats.levelIndex! : game.levelIndex;
    const stars = win ? starsForHp(game.houseHp) : 0;
    let nextIndex: number | null = null;
    if (win && isLevel) {
      const lvl = LEVELS[levelIndex];
      ui.progress.complete(lvl.id, stars);
      if (levelIndex + 1 < LEVELS.length && ui.progress.isUnlocked(levelIndex + 1)) nextIndex = levelIndex + 1;
    } else if (win && stats.mode === "classic") {
      ui.progress.completeClassic();
    }
    endTimer = window.setTimeout(() => {
      const quote = win
        ? isLevel
          ? `L${String(levelIndex + 1).padStart(2, "0")}「${LEVELS[levelIndex].name}」通过。${stars === 3 ? "三星，床保住了，作息没有。" : "床保住了。下一关的早八已经在门口。"}`
          : "经典 10 波守住了。你的作息没有变好，但今晚没人能把你叫起来。"
        : game.currentEvent?.line ?? "睡眠舱失守了。早八没有赢，它只是准时到了。";
      ui.showEnd(win, stats, quote, {
        levelIndex,
        levelName: isLevel ? LEVELS[levelIndex].name : "经典 10 波",
        stars,
        nextIndex,
        mode: stats.mode === "classic" ? "classic" : "level",
      });
      game.audio.setMusic(true);
    }, 1100);
  },
  onAgentLine: (line) => ui.setDialogue(line),
  onNotice: (text) => ui.toast(text, "#ffd447"),
  onVision: () => {
    /* HUD polls the report; no extra work needed. */
  },
};

// Canvas input.
function stagePoint(event: PointerEvent): [number, number] {
  const rect = ui.canvas.getBoundingClientRect();
  return [((event.clientX - rect.left) / rect.width) * 1600, ((event.clientY - rect.top) / rect.height) * 900];
}

ui.canvas.addEventListener("pointermove", (event) => {
  const [x, y] = stagePoint(event);
  game.setHover(x, y);
  ui.canvas.style.cursor = game.selected || game.shovel ? "crosshair" : "default";
});
ui.canvas.addEventListener("pointerleave", () => {
  game.hoverCell = null;
});
ui.canvas.addEventListener("pointerdown", (event) => {
  const [x, y] = stagePoint(event);
  game.pointerDown(x, y);
  game.audio.ensure();
});
ui.canvas.addEventListener("contextmenu", (event) => event.preventDefault());

// Keyboard.
window.addEventListener("keydown", (event) => {
  const target = event.target as HTMLElement | null;
  if (target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA")) {
    if (event.key === "Escape") modal.close();
    return;
  }
  if (event.key === "Escape") {
    event.preventDefault();
    if (modal.open) modal.close();
    else if (!document.getElementById("level-screen")?.classList.contains("hidden")) goTitle();
    else if (game.screen === "playing") openPause();
    else if (game.screen === "paused") game.resume();
    return;
  }
  if (modal.open) return;
  if (game.screen === "title" && (event.key === "Enter" || event.key === " ")) {
    event.preventDefault();
    openLevels();
    return;
  }
  if (game.screen !== "playing") return;
  if (event.key >= "1" && event.key <= "9") {
    game.selectPlant(PLANT_ORDER[Number(event.key) - 1]);
  } else if (event.key === "0") {
    game.selectPlant(PLANT_ORDER[9]);
  } else if (event.key === "-") {
    game.selectPlant(PLANT_ORDER[10]);
  } else if (event.key.toLowerCase() === "s") {
    game.toggleShovel();
  } else if (event.key.toLowerCase() === "v") {
    toggleVision();
  } else if (event.key.toLowerCase() === "x") {
    game.drawVisionInterpretation();
  } else if (event.key.toLowerCase() === "t") {
    openChat();
  } else if (event.key.toLowerCase() === "p") {
    openPause();
  } else if (event.key.toLowerCase() === "m") {
    toggleSound();
  }
});

// Main loop.
function frame(now: number) {
  const dt = Math.min(0.05, (now - lastFrame) / 1000);
  lastFrame = now;
  visualTime += dt;
  if (game.screen === "playing") game.update(dt);
  if (game.screen === "title") renderer.drawTitle(visualTime);
  else renderer.draw(game);
  ui.update(dt);
  if (game.screen === "playing") void maybeScan(now);
  requestAnimationFrame(frame);
}

async function boot() {
  ui.showTitle();
  game.screen = "title";
  updateAudioButtons();
  ui.setBootProgress(0.03, "检查实验设备");
  await preloadSprites((ratio) => ui.setBootProgress(0.03 + ratio * 0.66, "加载手绘植物"));
  await document.fonts.ready;
  ui.setBootProgress(0.75, "给字体做心理建设");
  await Promise.race([refreshHealth(), new Promise((resolve) => window.setTimeout(resolve, 3200))]);
  ui.setBootProgress(0.92, "连接第三只眼");
  await new Promise((resolve) => window.setTimeout(resolve, 220));
  ui.setBootProgress(1, "开机完成");
  bootDone = true;
  window.setTimeout(() => ui.hideBoot(), 420);
}

// Poll health without blocking the game.
window.setInterval(() => {
  if (!bootDone) return;
  void refreshHealth();
}, 24000);

void boot();
requestAnimationFrame(frame);
