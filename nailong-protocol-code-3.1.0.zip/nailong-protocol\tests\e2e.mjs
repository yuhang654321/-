import { chromium } from "playwright-core";
import { mkdirSync } from "node:fs";
import { resolve } from "node:path";

const BASE = process.env.BASE_URL || "http://127.0.0.1:8000";
const root = resolve(import.meta.dirname, "..");
mkdirSync(resolve(root, "demo"), { recursive: true });
const failures = [];
const check = (name, ok, extra = "") => {
  console.log(`${ok ? "PASS" : "FAIL"}  ${name}${extra ? `  (${extra})` : ""}`);
  if (!ok) failures.push(name);
};

const browser = await chromium.launch({
  executablePath: process.env.EDGE_PATH || "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe",
  headless: true,
  args: ["--disable-gpu", "--force-device-scale-factor=1"],
});
const page = await browser.newPage({ viewport: { width: 1600, height: 900 }, acceptDownloads: true });
const consoleErrors = [];
page.on("console", (m) => { if (m.type() === "error") consoleErrors.push(m.text()); });
page.on("pageerror", (e) => consoleErrors.push(e.message));

await page.goto(`${BASE}${BASE.includes("?") ? "&" : "?"}debug=1`, { waitUntil: "networkidle" });
await page.waitForTimeout(2600);
check("title visible", await page.locator("#title-screen").isVisible());
check("no boot overlay", (await page.locator("#boot-screen").count()) === 0);
const llm = await page.locator("#title-llm-status").innerText();
const yolo = await page.locator("#title-yolo-status").innerText();
console.log(`      backend: LLM=${llm} YOLO=${yolo}`);

await page.click("#start-btn");
await page.waitForTimeout(500);
check("level select", (await page.locator(".level-card").count()) === 15);
await page.locator(".level-card").first().click();
await page.waitForTimeout(800);
check("game HUD visible", await page.locator("#game-hud").isVisible());

await page.evaluate(() => {
  const g = window.__nailong.game;
  g.sun = 5000;
  const place = (type, col, row) => { g.readyAt[type] = 0; g.placePlant(type, col, row); };
  place("flower", 0, 2);
  place("pea", 1, 2);
  place("pea", 2, 2);
  place("wall", 4, 1);
  place("frost", 3, 3);
  place("fan", 2, 4);
  g.sun = 500;
  for (let row = 0; row < 5; row++) g.spawnZombie(row === 0 ? "boss" : "basic", row);
  g.waveActive = true;
  g.waveElapsed = 5;
});
const beforeKills = await page.evaluate(() => window.__nailong.game.stats.kills);
await page.waitForTimeout(6500);
const after = await page.evaluate(() => {
  const g = window.__nailong.game;
  return {
    plants: g.plants.length,
    zombies: g.zombies.length,
    kills: g.stats.kills,
    damaged: g.zombies.some((z) => z.hp < z.maxHp || z.armor < z.maxArmor),
    projectiles: g.projectiles.length,
    effects: g.effects.length,
  };
});
check("plants placed", after.plants >= 5, `plants=${after.plants}`);
check("combat deals damage", after.damaged || after.kills > beforeKills || after.projectiles > 0, `kills=${after.kills}, damaged=${after.damaged}`);

if (yolo === "ARMED") {
  await page.click('[data-action="vision"]');
  await page.waitForFunction(() => {
    const g = window.__nailong?.game;
    return !!g?.visionReport && g.visionReport.detections.length > 0;
  }, { timeout: 12000 }).catch(() => null);
  const vision = await page.evaluate(() => {
    const g = window.__nailong.game;
    return { visible: g.visionVisible, count: g.visionReport?.detections.length ?? 0, sync: g.visionSync, scans: g.stats.yoloScans };
  });
  check("YOLO live detections", vision.visible && vision.count > 0, `boxes=${vision.count}, sync=${vision.sync}`);
  await page.click('[data-action="vision"]');
} else {
  console.log("SKIP  YOLO live detections (backend model not armed)");
}

await page.click('[data-action="chat"]');
await page.waitForTimeout(400);
await page.click('[data-chip="夸我"]');
await page.waitForTimeout(5200);
const chatText = await page.locator("#chat-log").innerText();
check("agent reply rendered", chatText.includes("07") && chatText.length > 40);
await page.keyboard.press("Escape");
await page.waitForTimeout(400);

await page.click('[data-action="pause"]');
await page.waitForTimeout(250);
check("pause modal", (await page.locator(".pause-modal").count()) === 1);
await page.click("#pause-resume");
await page.waitForTimeout(250);
check("resume", await page.evaluate(() => window.__nailong.game.screen === "playing"));

await page.evaluate(() => {
  const g = window.__nailong.game;
  g.stats.kills = 42;
  g.stats.waves = 6;
  g.stats.plantsPlaced = 19;
  g.stats.sunCollected = 820;
  g.stats.yoloScans = 33;
  g.stats.time = 400;
  g.houseHp = 0;
});
await page.waitForTimeout(1700);
check("end screen", await page.locator("#end-screen.open").isVisible());
const downloadPromise = page.waitForEvent("download", { timeout: 10000 }).catch(() => null);
await page.click("#end-share");
const download = await downloadPromise;
check("share card download", !!download);
if (download) await download.saveAs(resolve(root, "demo", "e2e-share.png"));

check("no console errors", consoleErrors.length === 0, consoleErrors.slice(0, 2).join(" | "));
await browser.close();
if (failures.length) {
  console.error(`\n${failures.length} failure(s): ${failures.join(", ")}`);
  process.exit(1);
}
console.log("\nALL E2E CHECKS PASSED");
