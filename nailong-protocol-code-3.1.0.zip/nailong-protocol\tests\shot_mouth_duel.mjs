﻿import { chromium } from "playwright-core";
const browser = await chromium.launch({ executablePath: "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe", headless: true, args: ["--disable-gpu"] });
const page = await browser.newPage({ viewport: { width: 1600, height: 900 } });
await page.goto("http://127.0.0.1:8000/?debug", { waitUntil: "networkidle" });
await page.waitForTimeout(2400);
await page.evaluate(() => {
  const { game: g, ui } = window.__nailong;
  ui.showGame(); g.startLevel(0); g.screen="playing"; g.waveActive=false; g.prepTimer=60;
  g.events.onToast=()=>{}; g.events.onNotice=()=>{};
  g.sun=9999; for (const id of ["flower","pea","doublepea","wall","frost","fan","bomb","cannon","vacuum","boomerang","seal"]) g.readyAt[id]=0;
  g.placePlant("pea",3,0); g.placePlant("doublepea",6,0);
  const a=g.plants.find(p=>p.type==="pea"), b=g.plants.find(p=>p.type==="doublepea");
  a.shootTimer=0; b.shootTimer=0;
  for (let i=0;i<32;i++) g.update(0.05);
});
await page.waitForTimeout(200);
await page.screenshot({ path: "demo/mouth-duel.png" });
console.log("saved");
await browser.close();
