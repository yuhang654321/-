export class ModalHost {
  private root: HTMLElement;
  private onClose: (() => void) | null = null;
  private isOpen = false;

  constructor(root: HTMLElement) {
    this.root = root;
    this.root.addEventListener("pointerdown", (event) => {
      if (event.target === this.root.querySelector(".modal-backdrop")) this.close();
      const close = (event.target as HTMLElement | null)?.closest("[data-close]");
      if (close) this.close();
    });
  }

  get open() {
    return this.isOpen;
  }

  show(html: string, onClose?: () => void): HTMLElement {
    this.root.innerHTML = `<div class="modal-backdrop"></div>${html}`;
    this.root.classList.add("open");
    this.isOpen = true;
    this.onClose = onClose ?? null;
    const modal = this.root.querySelector<HTMLElement>(".modal");
    if (modal) {
      // Focus the first sensible control without stealing from chat textarea.
      window.setTimeout(() => {
        const input = modal.querySelector<HTMLInputElement>("input, textarea");
        if (input) input.focus();
      }, 80);
    }
    return modal ?? this.root;
  }

  close() {
    if (!this.isOpen) return;
    this.isOpen = false;
    this.root.classList.remove("open");
    this.root.innerHTML = "";
    const cb = this.onClose;
    this.onClose = null;
    cb?.();
  }
}
