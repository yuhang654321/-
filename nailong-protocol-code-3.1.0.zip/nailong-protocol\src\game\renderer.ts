import type { Game } from "./engine";
import { BOARD, CREAM, HOUSE, INK, PLANTS, ZOMBIES, STAGE_W, STAGE_H } from "./content";
import { sprite } from "./assets";
import type { Detection, Particle, Plant, Zombie } from "../types";

const TAU = Math.PI * 2;
const FONT_DISPLAY = '"ZCOOL KuaiLe", "Microsoft YaHei", sans-serif';
const FONT_BODY = '"Noto Sans SC", "Microsoft YaHei", sans-serif';
const FONT_MONO = '"Courier New", monospace';

type SceneMotif =
  | "clock"
  | "bed"
  | "tray"
  | "desk"
  | "paper"
  | "candle"
  | "coffee"
  | "stage"
  | "seal"
  | "mirror"
  | "palace"
  | "throne"
  | "group";

interface SceneTheme {
  label: string;
  washA: string;
  washB: string;
  grassA: string;
  grassB: string;
  ghost: string;
  accent: string;
  motif: SceneMotif;
}

const SCENES: SceneTheme[] = [
  { label: "CLASSROOM / 开学第一天", washA: "#6b4a24", washB: "#1a0d18", grassA: "#35765a", grassB: "#20503f", ghost: "开学第一天", accent: "#dfff43", motif: "clock" },
  { label: "BEDROOM / 闹钟没响", washA: "#3b2c66", washB: "#0e0a1c", grassA: "#31556b", grassB: "#213e52", ghost: "闹钟没响", accent: "#69e7ff", motif: "bed" },
  { label: "ROLL CALL / 早八点名", washA: "#2b5b68", washB: "#0d2028", grassA: "#3b6b63", grassB: "#284f4a", ghost: "早八点名", accent: "#ffd447", motif: "paper" },
  { label: "CANTEEN / 食堂插队", washA: "#77402c", washB: "#241215", grassA: "#6b6b3f", grassB: "#4b4a2f", ghost: "食堂插队", accent: "#ff9b45", motif: "tray" },
  { label: "OFFICE / 导师巡视", washA: "#584757", washB: "#1b1325", grassA: "#5c5a4a", grassB: "#3d3b31", ghost: "导师巡视", accent: "#ff5d6c", motif: "desk" },
  { label: "DEADLINE / 论文截稿", washA: "#6b5b45", washB: "#211827", grassA: "#6b6251", grassB: "#484537", ghost: "论文截稿", accent: "#fff4d6", motif: "paper" },
  { label: "BLACKOUT / 宿舍停电", washA: "#16142a", washB: "#05050b", grassA: "#22423c", grassB: "#142a27", ghost: "宿舍停电", accent: "#ffd447", motif: "candle" },
  { label: "GROUP CHAT / 小组作业", washA: "#2b3c61", washB: "#0e1426", grassA: "#315f68", grassB: "#1f4249", ghost: "小组作业", accent: "#69e7ff", motif: "group" },
  { label: "CAFFEINE / 咖啡因超标", washA: "#603a24", washB: "#1e0d0b", grassA: "#5f513a", grassB: "#403526", ghost: "咖啡因超标", accent: "#c78651", motif: "coffee" },
  { label: "FINALS / 期末周", washA: "#5d2234", washB: "#1a0b16", grassA: "#5c4a44", grassB: "#3c2e2e", ghost: "期末周", accent: "#ff5d6c", motif: "clock" },
  { label: "DEFENSE / 毕业答辩", washA: "#6b203a", washB: "#1b0a18", grassA: "#5a4650", grassB: "#382a34", ghost: "毕业答辩", accent: "#ffd447", motif: "stage" },
  { label: "JADE / 玉玺出土", washA: "#45553a", washB: "#10180f", grassA: "#4e6b54", grassB: "#334b3a", ghost: "玉玺出土", accent: "#9ff2c6", motif: "seal" },
  { label: "MIRROR / 平行早八", washA: "#263a61", washB: "#0b1124", grassA: "#35456b", grassB: "#222f4f", ghost: "平行早八", accent: "#69e7ff", motif: "mirror" },
  { label: "PALACE / 冕旒降临", washA: "#6b2130", washB: "#18070e", grassA: "#5e3f2e", grassB: "#3c271d", ghost: "冕旒降临", accent: "#ffd447", motif: "palace" },
  { label: "THRONE / 传国玉玺", washA: "#5e421d", washB: "#160c04", grassA: "#5e4a28", grassB: "#3e3019", ghost: "传国玉玺", accent: "#ffd447", motif: "throne" },
];

function rr(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  const radius = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.roundRect(x, y, w, h, radius);
}

function hash(n: number): number {
  const x = Math.sin(n * 127.1 + 311.7) * 43758.5453;
  return x - Math.floor(x);
}

function mix(a: string, b: string, t: number): string {
  const pa = [parseInt(a.slice(1, 3), 16), parseInt(a.slice(3, 5), 16), parseInt(a.slice(5, 7), 16)];
  const pb = [parseInt(b.slice(1, 3), 16), parseInt(b.slice(3, 5), 16), parseInt(b.slice(5, 7), 16)];
  return `rgb(${pa.map((v, i) => Math.round(v + (pb[i] - v) * t)).join(",")})`;
}

function starPath(ctx: CanvasRenderingContext2D, x: number, y: number, r: number, points = 5, inner = 0.42) {
  ctx.beginPath();
  for (let i = 0; i < points * 2; i++) {
    const rad = i % 2 === 0 ? r : r * inner;
    const a = (i / (points * 2)) * TAU - Math.PI / 2;
    const px = x + Math.cos(a) * rad;
    const py = y + Math.sin(a) * rad;
    if (i === 0) ctx.moveTo(px, py);
    else ctx.lineTo(px, py);
  }
  ctx.closePath();
}

export class Renderer {
  readonly canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private bg: HTMLCanvasElement;
  private grain: HTMLCanvasElement;
  private dust: { x: number; y: number; r: number; s: number; a: number; p: number }[] = [];
  private doodles: { kind: number; x: number; y: number; r: number; rot: number }[] = [];

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    canvas.width = STAGE_W;
    canvas.height = STAGE_H;
    const ctx = canvas.getContext("2d", { alpha: false });
    if (!ctx) throw new Error("canvas 2d unavailable");
    this.ctx = ctx;
    this.bg = document.createElement("canvas");
    this.bg.width = STAGE_W;
    this.bg.height = STAGE_H;
    this.grain = document.createElement("canvas");
    this.grain.width = 300;
    this.grain.height = 300;
    this.makeBackground();
    this.makeGrain();
    for (let i = 0; i < 46; i++) {
      this.dust.push({
        x: hash(i + 1) * STAGE_W,
        y: hash(i + 91) * STAGE_H,
        r: 1 + hash(i + 12) * 3,
        s: 4 + hash(i + 31) * 12,
        a: 0.1 + hash(i + 41) * 0.3,
        p: hash(i + 51) * TAU,
      });
    }
    for (let i = 0; i < 24; i++) {
      this.doodles.push({
        kind: Math.floor(hash(i + 3) * 4),
        x: hash(i + 19) * STAGE_W,
        y: hash(i + 39) * STAGE_H,
        r: 9 + hash(i + 7) * 28,
        rot: hash(i + 2) * TAU,
      });
    }
  }

  private makeGrain() {
    const g = this.grain.getContext("2d");
    if (!g) return;
    const img = g.createImageData(this.grain.width, this.grain.height);
    for (let i = 0; i < img.data.length; i += 4) {
      const v = Math.random() * 255;
      img.data[i] = v;
      img.data[i + 1] = v;
      img.data[i + 2] = v;
      img.data[i + 3] = Math.random() * 20;
    }
    g.putImageData(img, 0, 0);
  }

  private makeBackground() {
    const ctx = this.bg.getContext("2d");
    if (!ctx) return;
    const grad = ctx.createLinearGradient(0, 0, STAGE_W, STAGE_H);
    grad.addColorStop(0, "#1a0d2f");
    grad.addColorStop(0.46, "#221139");
    grad.addColorStop(1, "#100b22");
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, STAGE_W, STAGE_H);

    const glow = ctx.createRadialGradient(760, 420, 20, 760, 420, 760);
    glow.addColorStop(0, "rgba(87, 255, 173, .14)");
    glow.addColorStop(0.45, "rgba(94, 47, 167, .12)");
    glow.addColorStop(1, "rgba(0, 0, 0, 0)");
    ctx.fillStyle = glow;
    ctx.fillRect(0, 0, STAGE_W, STAGE_H);

    // Giant off-register sun.
    ctx.save();
    ctx.globalAlpha = 0.98;
    ctx.fillStyle = "#e9dcae";
    ctx.beginPath();
    ctx.arc(150, 22, 240, 0, TAU);
    ctx.fill();
    ctx.globalAlpha = 0.16;
    ctx.fillStyle = "#ff3d8d";
    ctx.beginPath();
    ctx.arc(160, 32, 240, 0, TAU);
    ctx.fill();
    ctx.restore();

    // Acid blob top-right.
    ctx.save();
    ctx.translate(1430, 30);
    ctx.rotate(-0.2);
    ctx.fillStyle = "#dfff43";
    ctx.strokeStyle = INK;
    ctx.lineWidth = 7;
    ctx.beginPath();
    for (let i = 0; i < 14; i++) {
      const a = (i / 14) * TAU;
      const r = 138 + Math.sin(i * 4.7) * 35;
      const x = Math.cos(a) * r;
      const y = Math.sin(a) * r * 0.62;
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.restore();

    // Far dorm windows.
    ctx.save();
    ctx.globalAlpha = 0.32;
    for (let row = 0; row < 7; row++) {
      for (let col = 0; col < 14; col++) {
        const x = 30 + col * 112 + hash(row * 31 + col) * 18;
        const y = 78 + row * 108;
        ctx.fillStyle = hash(row * 7 + col) > 0.55 ? "#ffcf6b" : "#5c3d78";
        ctx.fillRect(x, y, 34, 42);
        ctx.strokeStyle = "#1b102b";
        ctx.lineWidth = 3;
        ctx.strokeRect(x, y, 34, 42);
      }
    }
    ctx.restore();

    // Checkerboard strips.
    for (const x0 of [0, STAGE_W - 42]) {
      for (let y = 0; y < STAGE_H; y += 42) {
        for (let i = 0; i < 1; i++) {
          ctx.fillStyle = (y / 42) % 2 === 0 ? "#f4e8c8" : "#1a0f2c";
          ctx.globalAlpha = 0.08;
          ctx.fillRect(x0 + i * 42, y, 42, 42);
        }
      }
    }
    ctx.globalAlpha = 1;

    // Hand doodles.
    for (let i = 0; i < 40; i++) {
      const x = hash(i * 13) * STAGE_W;
      const y = hash(i * 29) * STAGE_H;
      const r = 8 + hash(i * 3) * 50;
      ctx.save();
      ctx.translate(x, y);
      ctx.rotate(hash(i) * TAU);
      ctx.globalAlpha = 0.09;
      ctx.strokeStyle = i % 2 ? "#f9edcb" : "#dfff43";
      ctx.lineWidth = 2;
      if (i % 5 === 0) {
        starPath(ctx, 0, 0, r, 4, 0.18);
        ctx.stroke();
      } else if (i % 5 === 1) {
        ctx.beginPath();
        ctx.arc(0, 0, r, 0, TAU);
        ctx.stroke();
      } else if (i % 5 === 2) {
        ctx.beginPath();
        ctx.moveTo(-r, 0);
        ctx.lineTo(r, 0);
        ctx.moveTo(0, -r);
        ctx.lineTo(0, r);
        ctx.stroke();
      } else {
        ctx.beginPath();
        ctx.moveTo(-r, r);
        ctx.quadraticCurveTo(0, -r, r, r);
        ctx.stroke();
      }
      ctx.restore();
    }

    // Big ghost type.
    ctx.save();
    ctx.translate(1430, 640);
    ctx.rotate(-Math.PI / 2);
    ctx.font = `900 148px ${FONT_DISPLAY}`;
    ctx.fillStyle = "rgba(255, 244, 214, .035)";
    ctx.fillText("早八植物园", 0, 0);
    ctx.restore();

    // Bottom hills.
    ctx.save();
    ctx.fillStyle = "#120a24";
    ctx.beginPath();
    ctx.moveTo(0, STAGE_H);
    ctx.lineTo(0, 824);
    ctx.bezierCurveTo(290, 770, 430, 856, 720, 832);
    ctx.bezierCurveTo(1000, 810, 1150, 865, 1600, 810);
    ctx.lineTo(1600, STAGE_H);
    ctx.closePath();
    ctx.fill();
    ctx.restore();

    // Subtle halftone field.
    ctx.save();
    ctx.globalAlpha = 0.12;
    for (let y = 0; y < STAGE_H; y += 18) {
      for (let x = (y / 18) % 2 === 0 ? 0 : 9; x < STAGE_W; x += 18) {
        ctx.fillStyle = "#f9edcb";
        ctx.beginPath();
        ctx.arc(x, y, 1.05, 0, TAU);
        ctx.fill();
      }
    }
    ctx.restore();
  }

  private drawDust(t: number) {
    const ctx = this.ctx;
    ctx.save();
    for (const d of this.dust) {
      const y = ((d.y - t * d.s) % (STAGE_H + 40) + STAGE_H + 40) % (STAGE_H + 40);
      const x = d.x + Math.sin(t * 0.24 + d.p) * 18;
      ctx.globalAlpha = d.a * (0.55 + 0.45 * Math.sin(t + d.p));
      ctx.fillStyle = d.r > 2.4 ? "#dfff43" : "#fff4d6";
      ctx.beginPath();
      ctx.arc(x, y, d.r, 0, TAU);
      ctx.fill();
    }
    ctx.restore();
  }

  drawTitle(t: number) {
    const ctx = this.ctx;
    ctx.save();
    ctx.drawImage(this.bg, 0, 0);
    this.drawDust(t);

    // Sun rays behind mascot.
    ctx.save();
    ctx.translate(1120, 418);
    ctx.rotate(Math.sin(t * 0.2) * 0.05);
    for (let i = 0; i < 18; i++) {
      ctx.rotate(TAU / 18);
      ctx.fillStyle = i % 2 ? "rgba(255, 212, 71, .18)" : "rgba(255, 61, 141, .12)";
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.lineTo(-70, -620);
      ctx.lineTo(70, -620);
      ctx.closePath();
      ctx.fill();
    }
    ctx.restore();

    ctx.save();
    ctx.translate(1120, 418);
    const pulse = 1 + Math.sin(t * 2.2) * 0.018;
    ctx.scale(pulse, pulse);
    ctx.fillStyle = "rgba(255, 244, 214, .95)";
    ctx.beginPath();
    ctx.arc(0, 0, 310, 0, TAU);
    ctx.fill();
    ctx.strokeStyle = INK;
    ctx.lineWidth = 9;
    ctx.stroke();
    // Offset risograph ring.
    ctx.strokeStyle = "#ff3d8d";
    ctx.lineWidth = 5;
    ctx.globalAlpha = 0.8;
    ctx.beginPath();
    ctx.arc(14, -10, 318, 0, TAU);
    ctx.stroke();
    ctx.restore();

    // Mascot.
    const mascot = sprite("mascot_nailong");
    if (mascot) {
      ctx.save();
      ctx.translate(1125, 400 + Math.sin(t * 2.2) * 12);
      ctx.rotate(Math.sin(t * 1.1) * 0.025);
      ctx.drawImage(mascot, -330, -310, 660, 660);
      ctx.restore();
    }

    // Plant chorus: every Nailong variant gets a cameo.
    const chorus = [
      "plant_flower",
      "plant_pea",
      "plant_wall",
      "plant_frost",
      "plant_fan",
      "plant_bomb",
      "plant_cannon",
      "plant_vacuum",
      "plant_boomerang",
      "plant_seal",
    ];
    chorus.forEach((name, i) => {
      const img = sprite(name);
      if (!img) return;
      const x = 758 + i * 78 + Math.sin(t * 2.4 + i * 1.7) * 3;
      const y = 856 + Math.sin(t * 2.4 + i * 1.7 + 1) * 5;
      ctx.save();
      ctx.translate(x, y);
      ctx.rotate(Math.sin(t * 2 + i) * 0.04);
      ctx.globalAlpha = 0.95;
      ctx.drawImage(img, -40, -82, 80, 80);
      ctx.restore();
    });

    // Creeping zombies.
    for (let i = 0; i < 4; i++) {
      const img = sprite(i === 0 ? "zombie_boss" : i === 1 ? "zombie_paper" : "zombie_basic");
      if (!img) continue;
      const x = i === 0 ? 1510 : 50 + i * 28;
      const y = 740 + Math.sin(t * 1.3 + i) * 5;
      const flip = i !== 0;
      ctx.save();
      ctx.translate(x, y);
      if (flip) ctx.scale(-1, 1);
      ctx.globalAlpha = 0.34;
      ctx.drawImage(img, -90, -180, 180, 180);
      ctx.restore();
    }

    // Floating stickers.
    ctx.save();
    ctx.font = `22px ${FONT_MONO}`;
    ctx.fillStyle = "rgba(255, 244, 214, .5)";
    ctx.translate(780, 110);
    ctx.rotate(-0.06);
    ctx.fillText("SLEEP IS A HUMAN RIGHT / 睡眠是一项人权", 0, 0);
    ctx.restore();

    // Corner registration marks.
    ctx.save();
    ctx.strokeStyle = "rgba(255, 244, 214, .6)";
    ctx.lineWidth = 2;
    for (const [x, y] of [[50, 50], [1550, 50], [50, 850], [1550, 850]]) {
      ctx.beginPath();
      ctx.arc(x, y, 12, 0, TAU);
      ctx.moveTo(x - 22, y);
      ctx.lineTo(x + 22, y);
      ctx.moveTo(x, y - 22);
      ctx.lineTo(x, y + 22);
      ctx.stroke();
    }
    ctx.restore();

    ctx.restore();
  }

  private sceneTheme(game: Game): SceneTheme {
    const index = (game.level?.index ?? 1) - 1;
    return SCENES[Math.max(0, Math.min(SCENES.length - 1, index))];
  }

  private drawScene(game: Game, t: number) {
    const ctx = this.ctx;
    const theme = this.sceneTheme(game);
    ctx.save();
    const wash = ctx.createLinearGradient(0, 0, STAGE_W, STAGE_H);
    wash.addColorStop(0, theme.washA);
    wash.addColorStop(1, theme.washB);
    ctx.globalAlpha = 0.2;
    ctx.fillStyle = wash;
    ctx.fillRect(0, 0, STAGE_W, STAGE_H);

    ctx.globalAlpha = 0.11;
    this.drawSceneMotif(theme.motif, 118, 635, 150, theme.accent, t);
    this.drawSceneMotif(theme.motif, 1135, 95, 72, theme.accent, t + 1.7);

    ctx.globalAlpha = 0.82;
    ctx.fillStyle = theme.accent;
    ctx.font = `10px ${FONT_MONO}`;
    ctx.textAlign = "left";
    ctx.fillText(theme.label, BOARD.x + 10, BOARD.y - 13);
    ctx.restore();
  }

  private drawSceneMotif(kind: SceneMotif, x: number, y: number, r: number, color: string, t: number) {
    const ctx = this.ctx;
    ctx.save();
    ctx.translate(x, y);
    ctx.scale(r / 100, r / 100);
    ctx.strokeStyle = color;
    ctx.fillStyle = color;
    ctx.lineWidth = 5;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    if (kind === "clock") {
      ctx.beginPath();
      ctx.arc(0, 0, 62, 0, TAU);
      ctx.stroke();
      for (let i = 0; i < 12; i++) {
        const a = (i / 12) * TAU;
        ctx.beginPath();
        ctx.moveTo(Math.cos(a) * 50, Math.sin(a) * 50);
        ctx.lineTo(Math.cos(a) * 58, Math.sin(a) * 58);
        ctx.stroke();
      }
      ctx.lineWidth = 8;
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.lineTo(Math.cos(t * 0.2) * 34, Math.sin(t * 0.2) * 34);
      ctx.moveTo(0, 0);
      ctx.lineTo(Math.cos(t * 0.05 - 1.4) * 22, Math.sin(t * 0.05 - 1.4) * 22);
      ctx.stroke();
    } else if (kind === "bed") {
      ctx.strokeRect(-76, -18, 152, 70);
      ctx.strokeRect(-58, -4, 54, 28);
      ctx.beginPath();
      ctx.moveTo(-2, 52);
      ctx.lineTo(65, 52);
      ctx.stroke();
      ctx.font = `42px ${FONT_DISPLAY}`;
      ctx.fillText("Z", 48, -34 + Math.sin(t * 2) * 5);
    } else if (kind === "tray") {
      ctx.strokeRect(-72, -12, 144, 54);
      ctx.beginPath();
      ctx.arc(0, 42, 36, 0, Math.PI);
      ctx.stroke();
      for (const dx of [-38, 0, 38]) {
        ctx.beginPath();
        ctx.moveTo(dx, -26);
        ctx.quadraticCurveTo(dx + 13, -50, dx, -70);
        ctx.stroke();
      }
    } else if (kind === "desk") {
      ctx.strokeRect(-78, -22, 156, 24);
      ctx.strokeRect(-55, 2, 110, 68);
      ctx.strokeRect(-36, 16, 70, 38);
      ctx.beginPath();
      ctx.moveTo(58, -32);
      ctx.lineTo(82, -8);
      ctx.stroke();
    } else if (kind === "paper") {
      for (let i = 0; i < 4; i++) {
        ctx.save();
        ctx.rotate(-0.12 + i * 0.1);
        ctx.strokeRect(-45 + i * 7, -58 + i * 12, 84, 102);
        for (let j = 0; j < 3; j++) {
          ctx.beginPath();
          ctx.moveTo(-34 + i * 7, -34 + i * 12 + j * 18);
          ctx.lineTo(25 + i * 7, -34 + i * 12 + j * 18);
          ctx.stroke();
        }
        ctx.restore();
      }
    } else if (kind === "candle") {
      ctx.strokeRect(-18, -6, 36, 76);
      ctx.beginPath();
      ctx.moveTo(0, -6);
      ctx.quadraticCurveTo(-22, -36, 0, -68 - Math.sin(t * 3) * 5);
      ctx.quadraticCurveTo(22, -36, 0, -6);
      ctx.stroke();
    } else if (kind === "coffee") {
      ctx.strokeRect(-40, -24, 80, 88);
      ctx.beginPath();
      ctx.arc(40, 16, 26, -Math.PI / 2, Math.PI / 2);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(5, -24);
      ctx.lineTo(24, -86);
      ctx.stroke();
      for (const dx of [-14, 14]) {
        ctx.beginPath();
        ctx.moveTo(dx, -44);
        ctx.quadraticCurveTo(dx + 10, -64, dx, -80);
        ctx.stroke();
      }
    } else if (kind === "stage") {
      ctx.beginPath();
      ctx.moveTo(-100, -80);
      ctx.lineTo(-20, 55);
      ctx.lineTo(-65, 70);
      ctx.closePath();
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(100, -80);
      ctx.lineTo(20, 55);
      ctx.lineTo(65, 70);
      ctx.closePath();
      ctx.stroke();
      ctx.strokeRect(-46, 28, 92, 47);
      ctx.beginPath();
      ctx.moveTo(-46, 75);
      ctx.lineTo(46, 75);
      ctx.stroke();
    } else if (kind === "seal") {
      ctx.strokeRect(-56, -38, 112, 76);
      ctx.beginPath();
      ctx.moveTo(-24, -38);
      ctx.lineTo(-24, -62);
      ctx.lineTo(24, -62);
      ctx.lineTo(24, -38);
      ctx.stroke();
      ctx.font = `54px ${FONT_DISPLAY}`;
      ctx.textAlign = "center";
      ctx.fillText("玺", 0, 20);
    } else if (kind === "mirror") {
      ctx.beginPath();
      ctx.ellipse(0, 0, 48, 72, 0, 0, TAU);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(-24, -52);
      ctx.lineTo(22, -12);
      ctx.lineTo(-8, 32);
      ctx.lineTo(30, 64);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(-78, 52);
      ctx.lineTo(-40, 70);
      ctx.lineTo(-58, 94);
      ctx.stroke();
    } else if (kind === "palace") {
      for (const dx of [-60, 0, 60]) {
        ctx.strokeRect(dx - 12, -30, 24, 105);
        ctx.beginPath();
        ctx.moveTo(dx - 22, -30);
        ctx.lineTo(dx + 22, -30);
        ctx.stroke();
      }
      ctx.beginPath();
      ctx.moveTo(-96, -30);
      ctx.quadraticCurveTo(0, -92, 96, -30);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(-76, -16);
      ctx.lineTo(76, -16);
      ctx.stroke();
    } else if (kind === "throne") {
      ctx.strokeRect(-58, -22, 116, 78);
      ctx.strokeRect(-42, -58, 84, 36);
      ctx.beginPath();
      ctx.moveTo(-58, 56);
      ctx.lineTo(-82, 90);
      ctx.moveTo(58, 56);
      ctx.lineTo(82, 90);
      ctx.stroke();
      ctx.strokeRect(-26, 8, 52, 36);
    } else {
      ctx.strokeRect(-72, 0, 144, 68);
      ctx.beginPath();
      ctx.moveTo(-72, 0);
      ctx.lineTo(-36, -42);
      ctx.lineTo(36, -42);
      ctx.lineTo(72, 0);
      ctx.stroke();
      for (const dx of [-42, 0, 42]) {
        ctx.beginPath();
        ctx.arc(dx, -70, 22, 0, TAU);
        ctx.stroke();
      }
    }
    ctx.restore();
  }

  draw(game: Game) {
    const ctx = this.ctx;
    const t = game.time;
    ctx.save();
    if (game.shake > 0) {
      const s = game.shake;
      ctx.translate((Math.random() - 0.5) * s, (Math.random() - 0.5) * s);
    }
    ctx.drawImage(this.bg, 0, 0);
    this.drawScene(game, t);
    this.drawDust(t);
    this.drawBoard(game, t);
    this.drawHouse(game, t);
    this.drawEffectsUnder(game);
    this.drawSuns(game, t);

    // Depth sort by row, then by feet position.
    const drawables: { row: number; y: number; fn: () => void }[] = [];
    for (const p of game.plants) drawables.push({ row: p.row, y: p.y + 30, fn: () => this.drawPlant(p, game, t) });
    for (const z of game.zombies) drawables.push({ row: z.row, y: z.y + 20, fn: () => this.drawZombie(z, game, t) });
    drawables.sort((a, b) => a.row - b.row || a.y - b.y);
    for (const d of drawables) d.fn();

    this.drawProjectiles(game, t);
    this.drawEffectsOver(game, t);
    this.drawParticles(game.particles);
    this.drawFloating(game);
    this.drawHover(game, t);
    this.drawFog(game, t);
    this.drawVision(game, t);
    this.drawBossBar(game);
    this.drawVignette();
    ctx.restore();
  }

  private drawBoard(game: Game, t: number) {
    const ctx = this.ctx;
    const { x, y, cols, rows, cw, ch, w, h } = BOARD;
    ctx.save();

    // Drop shadow.
    ctx.fillStyle = "rgba(0, 0, 0, .32)";
    rr(ctx, x + 14, y + 18, w, h, 26);
    ctx.fill();

    // Outer frame.
    ctx.fillStyle = "#e9dfb9";
    rr(ctx, x - 10, y - 10, w + 20, h + 20, 28);
    ctx.fill();
    ctx.strokeStyle = INK;
    ctx.lineWidth = 7;
    ctx.stroke();

    const theme = this.sceneTheme(game);
    const panel = ctx.createLinearGradient(x, y, x + w, y + h);
    panel.addColorStop(0, mix(theme.grassA, "#07120f", 0.52));
    panel.addColorStop(0.5, mix(theme.grassB, "#07120f", 0.62));
    panel.addColorStop(1, mix(theme.grassB, "#050a09", 0.76));
    ctx.fillStyle = panel;
    rr(ctx, x, y, w, h, 20);
    ctx.fill();

    for (let row = 0; row < rows; row++) {
      const safe = game.laneDanger[row];
      const rowGrad = ctx.createLinearGradient(0, y + row * ch, 0, y + (row + 1) * ch);
      rowGrad.addColorStop(0, row % 2 ? theme.grassA : theme.grassB);
      rowGrad.addColorStop(1, mix(row % 2 ? theme.grassA : theme.grassB, "#06100d", 0.28));
      ctx.fillStyle = rowGrad;
      ctx.fillRect(x + 4, y + row * ch + 3, w - 8, ch - 6);
      if (safe > 0) {
        ctx.save();
        ctx.globalAlpha = safe * 0.24;
        ctx.fillStyle = "#ff3d5f";
        ctx.fillRect(x + 4, y + row * ch + 3, w - 8, ch - 6);
        ctx.restore();
      }

      // Mowed lawn columns: two-tone stripes make the grid readable without
      // turning it into a spreadsheet.
      for (let col = 0; col < cols; col++) {
        if ((col + row) % 2 === 0) {
          ctx.fillStyle = "rgba(218, 255, 140, .035)";
          ctx.fillRect(x + col * cw + 2, y + row * ch + 4, cw - 4, ch - 8);
        }
        ctx.strokeStyle = "rgba(13, 34, 28, .2)";
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(x + col * cw + 2, y + row * ch + 7);
        ctx.lineTo(x + col * cw + 2, y + row * ch + ch - 7);
        ctx.stroke();
      }

      // Chalk field lines.
      ctx.save();
      ctx.strokeStyle = "rgba(239, 255, 209, .18)";
      ctx.lineWidth = 2;
      ctx.setLineDash([4, 13]);
      ctx.beginPath();
      ctx.moveTo(x + 10, y + (row + 1) * ch - 1);
      ctx.lineTo(x + w - 10, y + (row + 1) * ch - 1);
      ctx.stroke();
      ctx.restore();

      // Little tufts.
      for (let col = 0; col < cols; col++) {
        const px = x + col * cw + 14 + hash(row * 13 + col) * (cw - 28);
        const py = y + row * ch + ch - 11;
        ctx.strokeStyle = "rgba(174, 255, 129, .34)";
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(px, py);
        ctx.quadraticCurveTo(px + 3, py - 9, px + 7, py - 3);
        ctx.moveTo(px + 5, py);
        ctx.quadraticCurveTo(px + 8, py - 7, px + 12, py - 1);
        ctx.stroke();
      }
    }

    // Ghost crop rows painted on the soil.
    ctx.save();
    ctx.globalAlpha = 0.055;
    ctx.fillStyle = "#fff4d6";
    ctx.font = `900 82px ${FONT_DISPLAY}`;
    ctx.textAlign = "center";
    ctx.translate(x + w * 0.52, y + h * 0.57);
    ctx.rotate(-0.045);
    ctx.fillText(theme.ghost, 0, 0);
    ctx.restore();

    ctx.save();
    ctx.globalAlpha = 0.075;
    this.drawSceneMotif(theme.motif, x + w * 0.5, y + h * 0.5, 190, theme.accent, t);
    ctx.restore();

    // Column grid.
    ctx.save();
    ctx.strokeStyle = "rgba(255, 244, 214, .06)";
    ctx.lineWidth = 2;
    for (let col = 1; col < cols; col++) {
      ctx.beginPath();
      ctx.moveTo(x + col * cw, y + 8);
      ctx.lineTo(x + col * cw, y + h - 8);
      ctx.stroke();
    }
    ctx.restore();

    // Hazard tape along both edges. The right side is where the semester
    // breaks in; the left side is where the bed is.
    ctx.save();
    rr(ctx, x + 2, y + 2, w - 4, h - 4, 18);
    ctx.clip();
    for (const ex of [x + 4, x + w - 14]) {
      for (let yy = y; yy < y + h; yy += 20) {
        ctx.fillStyle = (yy / 20) % 2 === 0 ? "rgba(255, 212, 71, .18)" : "rgba(28, 16, 44, .22)";
        ctx.save();
        ctx.translate(ex, yy);
        ctx.rotate(-0.45);
        ctx.fillRect(-10, -12, 18, 24);
        ctx.restore();
      }
    }
    ctx.restore();

    // Discreet field notes.
    ctx.save();
    ctx.globalAlpha = 0.12;
    const fieldDaisy = sprite("daisy");
    const fieldMushroom = sprite("mushroom");
    if (fieldDaisy) ctx.drawImage(fieldDaisy, x + cw * 2 + 28, y + ch * 1 + 20, 44, 44);
    if (fieldMushroom) ctx.drawImage(fieldMushroom, x + cw * 6 + 20, y + ch * 4 + 16, 46, 46);
    ctx.globalAlpha = 1;
    ctx.restore();

    // Lane number tabs.
    for (let row = 0; row < rows; row++) {
      ctx.save();
      const cy = y + row * ch + ch / 2;
      ctx.translate(x - 22, cy);
      ctx.rotate(-Math.PI / 2);
      ctx.font = `12px ${FONT_MONO}`;
      ctx.fillStyle = "rgba(255, 244, 214, .45)";
      ctx.textAlign = "center";
      ctx.fillText(`LANE 0${row + 1}`, 0, 4);
      ctx.restore();
    }

    // Corner decorations.
    const daisy = sprite("daisy");
    const mushroom = sprite("mushroom");
    const tape = sprite("tape");
    if (daisy) {
      ctx.save();
      ctx.globalAlpha = 0.7;
      ctx.drawImage(daisy, x - 16, y - 32, 54, 54);
      ctx.restore();
    }
    if (mushroom) {
      ctx.save();
      ctx.globalAlpha = 0.8;
      ctx.drawImage(mushroom, x + w - 54, y + h - 43, 70, 70);
      ctx.restore();
    }
    if (tape) {
      ctx.save();
      ctx.translate(x + w / 2, y - 17);
      ctx.rotate(-0.025);
      ctx.globalAlpha = 0.9;
      ctx.drawImage(tape, -84, -18, 168, 36);
      ctx.restore();
    }

    ctx.restore();
  }

  private drawHouse(game: Game, t: number) {
    const ctx = this.ctx;
    const x = HOUSE.x;
    const y = HOUSE.y;
    const w = HOUSE.w;
    const h = HOUSE.h;
    ctx.save();

    ctx.fillStyle = "rgba(0,0,0,.3)";
    rr(ctx, x + 8, y + 12, w, h, 24);
    ctx.fill();

    const grad = ctx.createLinearGradient(x, y, x + w, y + h);
    grad.addColorStop(0, "#ffb6ca");
    grad.addColorStop(1, "#e879a3");
    ctx.fillStyle = grad;
    rr(ctx, x, y, w, h, 24);
    ctx.fill();
    ctx.strokeStyle = INK;
    ctx.lineWidth = 7;
    ctx.stroke();

    // Roof sign.
    ctx.save();
    ctx.translate(x + w / 2, y - 22);
    ctx.fillStyle = "#ffd447";
    rr(ctx, -78, -22, 156, 44, 10);
    ctx.fill();
    ctx.strokeStyle = INK;
    ctx.lineWidth = 5;
    ctx.stroke();
    ctx.fillStyle = INK;
    ctx.font = `20px ${FONT_DISPLAY}`;
    ctx.textAlign = "center";
    ctx.fillText("请勿叫醒", 0, 7);
    ctx.restore();

    // Alarm beacon.
    const danger = game.laneDanger.some((v) => v > 0);
    ctx.save();
    ctx.translate(x + w / 2, y + 30);
    ctx.fillStyle = danger ? "#ff334f" : "#ffd447";
    if (danger) {
      ctx.shadowColor = "#ff334f";
      ctx.shadowBlur = 22 + Math.sin(t * 14) * 10;
    }
    ctx.beginPath();
    ctx.arc(0, 0, 12, 0, TAU);
    ctx.fill();
    ctx.shadowBlur = 0;
    ctx.strokeStyle = INK;
    ctx.lineWidth = 4;
    ctx.stroke();
    ctx.restore();

    // Five sleep pods.
    for (let row = 0; row < BOARD.rows; row++) {
      const py = y + row * BOARD.ch + 18;
      const ph = BOARD.ch - 36;
      const active = game.laneDanger[row] > 0;
      ctx.save();
      ctx.translate(x + 10, py);
      ctx.fillStyle = active ? "#ffd5de" : "#5a3d83";
      rr(ctx, 0, 0, w - 20, ph, 18);
      ctx.fill();
      ctx.strokeStyle = INK;
      ctx.lineWidth = 5;
      ctx.stroke();

      const glass = ctx.createLinearGradient(0, 0, w, ph);
      glass.addColorStop(0, active ? "#ffd9df" : "#baf4ff");
      glass.addColorStop(1, active ? "#ff6f8f" : "#59c9e6");
      ctx.fillStyle = glass;
      rr(ctx, 13, 9, 60, ph - 18, 12);
      ctx.fill();
      ctx.strokeStyle = INK;
      ctx.lineWidth = 3;
      ctx.stroke();

      // Sleeping blob inside.
      ctx.fillStyle = "#ffd447";
      ctx.beginPath();
      ctx.ellipse(43, ph / 2 + 5, 19, 14 + Math.sin(t * 2 + row) * 1.5, 0, 0, TAU);
      ctx.fill();
      ctx.strokeStyle = INK;
      ctx.lineWidth = 2.5;
      ctx.stroke();
      ctx.strokeStyle = INK;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(38, ph / 2 + 2, 5, 0.2, Math.PI - 0.2);
      ctx.arc(49, ph / 2 + 2, 5, 0.2, Math.PI - 0.2);
      ctx.stroke();

      ctx.fillStyle = CREAM;
      ctx.font = `13px ${FONT_MONO}`;
      ctx.fillText(`POD 0${row + 1}`, 84, 26);
      ctx.font = `11px ${FONT_BODY}`;
      ctx.fillStyle = "rgba(255, 244, 214, .6)";
      ctx.fillText(active ? "WARNING" : "SLEEPING", 84, 44);
      ctx.fillStyle = active ? "#ff334f" : "#dfff43";
      ctx.font = `10px ${FONT_MONO}`;
      ctx.fillText(active ? "!!!" : "zzz", 84, 60);

      if (active) {
        ctx.save();
        ctx.globalAlpha = 0.35 + Math.sin(t * 18) * 0.2;
        ctx.strokeStyle = "#ff334f";
        ctx.lineWidth = 6;
        rr(ctx, 0, 0, w - 20, ph, 18);
        ctx.stroke();
        ctx.restore();
      }
      ctx.restore();

      // Slipper.
      if (game.slippers[row]) {
        const slip = sprite("slipper");
        if (slip) {
          ctx.save();
          ctx.translate(x + w - 52, py + ph - 6);
          const glow = 0.75 + Math.sin(t * 3 + row) * 0.2;
          ctx.globalAlpha = glow;
          ctx.rotate(-0.15);
          ctx.drawImage(slip, -24, -24, 54, 30);
          ctx.globalAlpha = 0.12;
          ctx.fillStyle = "#ffe66d";
          ctx.beginPath();
          ctx.arc(2, -2, 25, 0, TAU);
          ctx.fill();
          ctx.restore();
        }
      }
    }

    // Vertical neon strip.
    ctx.save();
    ctx.translate(x + w - 2, y + h / 2);
    ctx.rotate(Math.PI / 2);
    ctx.font = `12px ${FONT_MONO}`;
    ctx.fillStyle = "rgba(28, 16, 44, .5)";
    ctx.textAlign = "center";
    ctx.fillText("SLEEP RESEARCH UNIT · 07 · DO NOT DISTURB", 0, 4);
    ctx.restore();

    ctx.restore();
  }

  private drawPlant(p: Plant, game: Game, t: number) {
    const ctx = this.ctx;
    const def = PLANTS[p.type];
    const img = sprite(def.sprite);
    if (!img) return;
    const cell = BOARD.cw;
    const size = p.type === "wall" ? 114 : p.type === "seal" ? 126 : p.type === "doublepea" ? 114 : p.type === "fan" ? 114 : p.type === "cannon" ? 112 : p.type === "vacuum" ? 112 : p.type === "bomb" ? 104 : 108;
    const laughing = p.laughing ?? 0;
    const bob = Math.sin(t * 2.1 + p.uid * 1.7) * (p.stun ? 0.5 : 2.2) + (laughing > 0 ? Math.sin(t * 18 + p.uid) * 6 : 0);
    const recoil = p.action > 0 ? p.action : 0;
    const sx = 1 - recoil * 0.09 + Math.sin(t * 5 + p.uid) * 0.008 + (laughing > 0 ? Math.sin(t * 19) * 0.035 : 0);
    const sy = 1 + recoil * 0.05 - (laughing > 0 ? Math.abs(Math.sin(t * 18)) * 0.035 : 0);

    ctx.save();
    ctx.translate(p.x + cell / 2, p.y + BOARD.ch - 15 + bob);
    ctx.rotate(Math.sin(t * 1.4 + p.uid) * 0.018 + (laughing > 0 ? Math.sin(t * 17 + p.uid) * 0.08 : 0));
    ctx.scale(sx, sy);

    // Ground shadow.
    ctx.fillStyle = "rgba(0, 0, 0, .28)";
    ctx.beginPath();
    ctx.ellipse(0, 4, size * 0.36, 11, 0, 0, TAU);
    ctx.fill();

    if (laughing > 0) {
      ctx.save();
      ctx.globalAlpha = 0.45 + Math.sin(t * 16) * 0.15;
      ctx.fillStyle = "#ffe66d";
      ctx.beginPath();
      ctx.arc(0, -size * 0.4, size * 0.54, 0, TAU);
      ctx.fill();
      ctx.restore();
    }

    if (p.shield) {
      ctx.strokeStyle = "rgba(255, 225, 110, .8)";
      ctx.lineWidth = 4;
      ctx.setLineDash([7, 9]);
      ctx.beginPath();
      ctx.arc(0, -size * 0.38, size * 0.54, 0, TAU);
      ctx.stroke();
      ctx.setLineDash([]);
    }

    if (p.stun) {
      ctx.save();
      ctx.globalAlpha = 0.22;
      ctx.fillStyle = "#ff334f";
      ctx.beginPath();
      ctx.arc(0, -size * 0.35, size * 0.5, 0, TAU);
      ctx.fill();
      ctx.restore();
    }

    if (p.type === "bomb") {
      const fuse = p.fuse ?? 0;
      const pulse = 1 + Math.sin(t * (14 - fuse * 5)) * 0.04;
      ctx.scale(pulse, pulse);
      ctx.shadowColor = "#ff5d6c";
      ctx.shadowBlur = 24 + Math.sin(t * 18) * 14;
    }

    ctx.drawImage(img, -size / 2, -size * 0.9, size, size);
    ctx.shadowBlur = 0;

    if (laughing > 0) {
      ctx.save();
      ctx.textAlign = "center";
      ctx.font = `17px ${FONT_DISPLAY}`;
      ctx.lineWidth = 4;
      ctx.strokeStyle = INK;
      ctx.fillStyle = "#ffd447";
      const word = Math.sin(t * 14 + p.uid) > 0 ? "哈哈哈哈哈" : "哈哈哈哈哈！";
      ctx.strokeText(word, 0, -size * 0.92 + Math.sin(t * 18) * 3);
      ctx.fillText(word, 0, -size * 0.92 + Math.sin(t * 18) * 3);
      for (let i = 0; i < 3; i++) {
        const a = t * 2.2 + i * 2.1;
        ctx.font = "16px sans-serif";
        ctx.fillStyle = i % 2 ? "#ff8fb0" : "#ffd447";
        ctx.fillText("♥", Math.cos(a) * 34, -size * 0.55 + Math.sin(a) * 18);
      }
      ctx.restore();
    }

    // Little spell glints.
    if (p.type === "flower" && p.produceTimer < 0.4) {
      for (let i = 0; i < 4; i++) {
        const a = t * 2 + (i / 4) * TAU;
        ctx.fillStyle = "#ffe66d";
        starPath(ctx, Math.cos(a) * 38, -42 + Math.sin(a) * 15, 4 + Math.sin(t * 8 + i) * 2);
        ctx.fill();
      }
    }
    if (p.type === "fan") {
      ctx.save();
      ctx.translate(0, -size * 0.56);
      ctx.rotate(t * 9);
      ctx.strokeStyle = "rgba(190, 255, 235, .7)";
      ctx.lineWidth = 3;
      for (let i = 0; i < 3; i++) {
        ctx.rotate(TAU / 3);
        ctx.beginPath();
        ctx.arc(0, 0, 27, 0.2, 1.7);
        ctx.stroke();
      }
      ctx.restore();
    }

    // Health bar.
    if (p.hp < p.maxHp && p.type !== "bomb") {
      const pct = Math.max(0, p.hp / p.maxHp);
      ctx.fillStyle = "rgba(15, 8, 25, .75)";
      rr(ctx, -30, -size * 0.93, 60, 7, 3);
      ctx.fill();
      ctx.fillStyle = pct > 0.5 ? "#6ff2a1" : pct > 0.25 ? "#ffd447" : "#ff5d6c";
      rr(ctx, -29, -size * 0.93 + 1, 58 * pct, 5, 2);
      ctx.fill();
    }
    ctx.restore();

    if (p.action > 0.9 && p.type === "pea") {
      ctx.save();
      ctx.globalAlpha = 0.8;
      ctx.fillStyle = "#dfff43";
      ctx.font = `14px ${FONT_DISPLAY}`;
      ctx.fillText("典", p.x + cell + 14, p.y + 48);
      ctx.restore();
    }
    void game;
  }

  private drawZombie(z: Zombie, game: Game, t: number) {
    const ctx = this.ctx;
    const def = ZOMBIES[z.type];
    const img = sprite(def.sprite);
    if (!img) return;
    const size = 128 * z.scale;
    const laughing = z.laughTimer > 0;
    const carrying = z.carrying;
    const bob = laughing
      ? Math.sin(t * 18 + z.uid) * 6
      : carrying
        ? Math.sin(t * 10 + z.uid) * 5
        : z.eating
          ? Math.sin(t * 11 + z.uid) * 2.4
          : Math.sin(t * 4.2 + z.uid) * 3.4;
    const sway = laughing ? Math.sin(t * 17 + z.uid) * 7 : z.eating ? Math.sin(t * 13 + z.uid) * 3 : Math.sin(t * 2.1 + z.uid) * 1.8;
    const h = size;

    ctx.save();
    ctx.translate(z.x, z.y + 26 + bob);
    if (carrying) ctx.scale(-1, 1);
    if (z.slow > 0) {
      ctx.shadowColor = "#69e7ff";
      ctx.shadowBlur = 16;
    }
    if (z.boss) {
      ctx.shadowColor = "rgba(255, 51, 79, .5)";
      ctx.shadowBlur = 26;
    }
    if (laughing) {
      ctx.shadowColor = "rgba(255, 212, 71, .7)";
      ctx.shadowBlur = 20;
    }
    ctx.rotate(sway * 0.004);
    ctx.fillStyle = "rgba(0, 0, 0, .28)";
    ctx.beginPath();
    ctx.ellipse(0, 6, size * 0.31, 11 * z.scale, 0, 0, TAU);
    ctx.fill();
    ctx.drawImage(img, -size / 2, -h * 0.91, size, h);
    ctx.shadowBlur = 0;

    if (carrying) {
      const flower = sprite("plant_flower");
      if (flower) {
        const fs = size * 0.5;
        ctx.save();
        ctx.translate(-size * 0.3, -h * 0.4 + Math.sin(t * 9 + z.uid) * 4);
        ctx.rotate(Math.sin(t * 7 + z.uid) * 0.1);
        ctx.drawImage(flower, -fs / 2, -fs / 2, fs, fs);
        ctx.restore();
      }
    }

    ctx.restore();

    if (carrying) {
      ctx.save();
      ctx.textAlign = "center";
      ctx.font = `13px ${FONT_DISPLAY}`;
      ctx.lineWidth = 4;
      ctx.strokeStyle = INK;
      ctx.fillStyle = "#ff8fb0";
      ctx.strokeText("抱走～", z.x, z.y - h * 0.98);
      ctx.fillText("抱走～", z.x, z.y - h * 0.98);
      ctx.restore();
    }

    if (laughing) {
      ctx.save();
      ctx.textAlign = "center";
      ctx.font = `13px ${FONT_DISPLAY}`;
      ctx.lineWidth = 4;
      ctx.strokeStyle = INK;
      ctx.fillStyle = "#ff8fb0";
      ctx.strokeText("哈哈", z.x + 46, z.y - h * 0.72 + Math.sin(t * 16) * 4);
      ctx.fillText("哈哈", z.x + 46, z.y - h * 0.72 + Math.sin(t * 16) * 4);
      ctx.font = "14px sans-serif";
      ctx.fillStyle = "#ff8fb0";
      ctx.fillText("♥", z.x + 74, z.y - h * 0.86 + Math.cos(t * 12) * 4);
      ctx.restore();
    }

    if (z.slow > 0) {
      ctx.save();
      ctx.globalAlpha = 0.55;
      ctx.strokeStyle = "#bff8ff";
      ctx.lineWidth = 2.5;
      for (let i = 0; i < 3; i++) {
        const a = t * 1.7 + i * 2.1;
        ctx.beginPath();
        ctx.arc(0, -h * 0.4, size * 0.3 + Math.sin(a) * 8, a, a + 0.7);
        ctx.stroke();
      }
      ctx.restore();
    }
    if (z.flash > 0) {
      ctx.save();
      ctx.globalAlpha = z.flash * 0.28;
      ctx.fillStyle = "#fff";
      ctx.beginPath();
      ctx.ellipse(0, -h * 0.42, size * 0.32, h * 0.4, 0, 0, TAU);
      ctx.fill();
      ctx.restore();
    }
    ctx.restore();

    // HP and armor bars.
    if (z.hp < z.maxHp || z.armor < z.maxArmor || z.boss) {
      const barW = z.boss ? 96 : 50 * z.scale;
      const bx = z.x - barW / 2;
      const by = z.y - h * 0.95 - (z.boss ? 20 : 12);
      ctx.save();
      ctx.fillStyle = "rgba(15, 8, 25, .72)";
      rr(ctx, bx, by, barW, 7, 3);
      ctx.fill();
      const hpPct = Math.max(0, z.hp / z.maxHp);
      ctx.fillStyle = z.boss ? "#ff334f" : hpPct > 0.5 ? "#8df0a2" : hpPct > 0.25 ? "#ffd447" : "#ff5d6c";
      rr(ctx, bx + 1, by + 1, (barW - 2) * hpPct, 5, 2);
      ctx.fill();
      if (z.armor > 0) {
        ctx.fillStyle = "#fff4d6";
        const armorPct = z.armor / Math.max(1, z.maxArmor);
        rr(ctx, bx + 1, by - 4, (barW - 2) * armorPct, 3, 1);
        ctx.fill();
      }
      ctx.restore();
    }

    if (z.boss) {
      ctx.save();
      ctx.fillStyle = "#ffcf4a";
      ctx.font = `12px ${FONT_MONO}`;
      ctx.textAlign = "center";
      ctx.fillText(z.type === "emperor" ? "THE 8AM EMPEROR · 早八皇帝" : "THE FINAL BOSS · 终审导师", z.x, z.y - h * 0.95 - 33);
      ctx.restore();
    }

    if (z.stun > 0) {
      ctx.save();
      ctx.fillStyle = "#ffd447";
      ctx.font = `22px ${FONT_DISPLAY}`;
      ctx.textAlign = "center";
      ctx.fillText("★", z.x - 14, z.y - h * 0.9 + Math.sin(t * 8) * 4);
      ctx.fillText("☆", z.x + 15, z.y - h * 0.95 + Math.cos(t * 8) * 4);
      ctx.restore();
    }
    void game;
  }

  private drawProjectiles(game: Game, t: number) {
    const ctx = this.ctx;
    for (const p of game.projectiles) {
      ctx.save();
      ctx.translate(p.x, p.y);
      if (p.kind === "speech") {
        ctx.rotate(Math.sin(p.x * 0.02) * 0.08);
        const texts = ["典", "6", "急", "？", "啊", "乐"];
        const label = p.text ?? texts[Math.floor(p.uid) % texts.length];
        ctx.fillStyle = p.friendly ? "#ffd7e2" : CREAM;
        ctx.strokeStyle = p.friendly ? "#ff3d8d" : INK;
        ctx.lineWidth = 4;
        rr(ctx, -22, -20, 44, 34, 12);
        ctx.fill();
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(-12, 12);
        ctx.lineTo(-20, 24);
        ctx.lineTo(-2, 14);
        ctx.closePath();
        ctx.fill();
        ctx.stroke();
        ctx.fillStyle = INK;
        ctx.font = `18px ${FONT_DISPLAY}`;
        ctx.textAlign = "center";
        ctx.fillText(label, 0, 5);
        ctx.globalAlpha = 0.22;
        ctx.fillStyle = "#dfff43";
        ctx.beginPath();
        ctx.ellipse(-20, 3, 12, 4, 0, 0, TAU);
        ctx.fill();
      } else if (p.kind === "ice") {
        ctx.rotate(t * 5);
        ctx.fillStyle = "#b8f5ff";
        ctx.strokeStyle = INK;
        ctx.lineWidth = 3;
        starPath(ctx, 0, 0, 18, 4, 0.24);
        ctx.fill();
        ctx.stroke();
      } else if (p.kind === "ddl" || p.kind === "seal") {
        if (p.kind === "seal") {
          ctx.rotate(Math.sin(t * 5 + p.uid) * 0.16);
          ctx.shadowColor = "#7ff0c0";
          ctx.shadowBlur = 16;
          ctx.fillStyle = "#bff2d0";
          ctx.strokeStyle = INK;
          ctx.lineWidth = 4;
          rr(ctx, -24, -24, 48, 48, 8);
          ctx.fill();
          ctx.stroke();
          ctx.shadowBlur = 0;
          ctx.fillStyle = "#2c8c65";
          ctx.font = `26px ${FONT_DISPLAY}`;
          ctx.textAlign = "center";
          ctx.fillText("玺", 0, 9);
          ctx.fillStyle = "rgba(255, 61, 141, .82)";
          ctx.fillRect(-18, -18, 36, 5);
        } else {
          const img = sprite("projectile_ddl");
          if (img) {
            ctx.rotate(Math.sin(t * 3 + p.uid) * 0.2);
            ctx.drawImage(img, -40, -40, 80, 80);
          }
        }
      } else if (p.kind === "boba") {
        ctx.rotate(p.spin);
        ctx.shadowColor = "#c78651";
        ctx.shadowBlur = 14;
        ctx.fillStyle = "#8c5133";
        ctx.strokeStyle = INK;
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.arc(0, 0, 17, 0, TAU);
        ctx.fill();
        ctx.stroke();
        ctx.shadowBlur = 0;
        ctx.fillStyle = "#2a1720";
        for (const [bx, by] of [[-7, 4], [2, 8], [8, 1], [-1, -5], [-9, -4]]) {
          ctx.beginPath();
          ctx.arc(bx, by, 3.2, 0, TAU);
          ctx.fill();
        }
        ctx.strokeStyle = "#ffe0b2";
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.moveTo(-8, -18);
        ctx.quadraticCurveTo(0, -26, 8, -18);
        ctx.stroke();
      } else if (p.kind === "boomerang") {
        ctx.rotate(p.spin);
        ctx.strokeStyle = INK;
        ctx.lineWidth = 10;
        ctx.lineCap = "round";
        ctx.beginPath();
        ctx.moveTo(-30, 18);
        ctx.quadraticCurveTo(-6, -30, 32, -6);
        ctx.stroke();
        ctx.strokeStyle = "#e6b86b";
        ctx.lineWidth = 6;
        ctx.beginPath();
        ctx.moveTo(-28, 16);
        ctx.quadraticCurveTo(-4, -26, 30, -5);
        ctx.stroke();
        ctx.fillStyle = "#fff2c9";
        ctx.beginPath();
        ctx.arc(-21, 13, 3, 0, TAU);
        ctx.fill();
      } else if (p.kind === "wind") {
        ctx.strokeStyle = "rgba(190, 255, 235, .85)";
        ctx.lineWidth = 4;
        for (let i = 0; i < 3; i++) {
          ctx.beginPath();
          ctx.arc(0, (i - 1) * 12, 45 + i * 8, -1.2, 1.2);
          ctx.stroke();
        }
      } else if (p.kind === "slipper") {
        const img = sprite("slipper");
        if (img) {
          ctx.rotate(p.spin);
          ctx.drawImage(img, -55, -38, 110, 70);
        }
      }
      ctx.restore();
    }
  }

  private drawSuns(game: Game, t: number) {
    const ctx = this.ctx;
    const img = sprite("sun");
    if (!img) return;
    for (const s of game.suns) {
      const bob = Math.sin(t * 2.4 + s.phase) * 5;
      const fade = Math.min(1, s.life / 1.4) * Math.min(1, s.age * 4);
      ctx.save();
      ctx.globalAlpha = fade;
      ctx.translate(s.x, s.y + bob);
      ctx.scale(1 + Math.sin(t * 3 + s.phase) * 0.025, 1 - Math.sin(t * 3 + s.phase) * 0.02);
      ctx.shadowColor = "#ffe66d";
      ctx.shadowBlur = 25;
      ctx.drawImage(img, -34, -40, 68, 68);
      ctx.shadowBlur = 0;

      // Hand-drawn collect ring.
      ctx.strokeStyle = "rgba(255, 244, 214, .5)";
      ctx.lineWidth = 2;
      ctx.setLineDash([3, 6]);
      ctx.beginPath();
      ctx.arc(0, 0, 39 + Math.sin(t * 5 + s.phase) * 3, 0, TAU);
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.restore();
    }
  }

  private drawEffectsUnder(game: Game) {
    void game;
  }

  private drawEffectsOver(game: Game, t: number) {
    const ctx = this.ctx;
    for (const e of game.effects) {
      const pct = 1 - e.life / e.maxLife;
      ctx.save();
      ctx.translate(e.x, e.y);
      if (e.kind === "explosion") {
        const r = e.radius * (0.25 + pct * 1.05);
        const alpha = 1 - pct;
        ctx.globalAlpha = alpha * 0.9;
        ctx.strokeStyle = "#ffd447";
        ctx.lineWidth = 12 * (1 - pct) + 2;
        ctx.beginPath();
        ctx.arc(0, 0, r, 0, TAU);
        ctx.stroke();
        ctx.strokeStyle = "#ff3d8d";
        ctx.lineWidth = 5;
        ctx.beginPath();
        ctx.arc(0, 0, r * 0.72, 0, TAU);
        ctx.stroke();
        ctx.fillStyle = "rgba(255, 93, 108, .2)";
        ctx.beginPath();
        ctx.arc(0, 0, r, 0, TAU);
        ctx.fill();
        ctx.globalAlpha = alpha;
        ctx.font = `900 ${34 + 12 * (1 - pct)}px ${FONT_DISPLAY}`;
        ctx.fillStyle = "#fff4d6";
        ctx.strokeStyle = INK;
        ctx.lineWidth = 7;
        ctx.textAlign = "center";
        ctx.strokeText("炸！", 0, -r * 0.6);
        ctx.fillText("炸！", 0, -r * 0.6);
      } else if (e.kind === "wind") {
        ctx.globalAlpha = 1 - pct;
        ctx.strokeStyle = "#bff8e5";
        ctx.lineWidth = 5;
        for (let i = 0; i < 4; i++) {
          ctx.beginPath();
          ctx.arc(0, (i - 1.5) * 18, 50 + pct * 180 + i * 12, -0.8, 0.8);
          ctx.stroke();
        }
      } else if (e.kind === "freeze") {
        ctx.globalAlpha = 1 - pct;
        ctx.strokeStyle = "#bff8ff";
        ctx.lineWidth = 3;
        for (let i = 0; i < 8; i++) {
          const a = (i / 8) * TAU;
          const r = 20 + pct * 60;
          ctx.beginPath();
          ctx.moveTo(Math.cos(a) * 5, Math.sin(a) * 5);
          ctx.lineTo(Math.cos(a) * r, Math.sin(a) * r);
          ctx.stroke();
        }
      } else if (e.kind === "suck") {
        ctx.globalAlpha = 1 - pct;
        ctx.strokeStyle = "#c9a3ff";
        ctx.lineWidth = 5;
        for (let i = 0; i < 3; i++) {
          ctx.beginPath();
          ctx.arc(0, 0, 20 + pct * 66 + i * 14, -0.9 + pct * 3, 0.9 + pct * 3);
          ctx.stroke();
        }
        ctx.fillStyle = "#e4d8ff";
        ctx.font = `22px ${FONT_DISPLAY}`;
        ctx.textAlign = "center";
        ctx.fillText("吸——", 0, -10 - pct * 24);
      } else if (e.kind === "seal") {
        ctx.globalAlpha = 1 - pct;
        ctx.strokeStyle = "#7ff0c0";
        ctx.lineWidth = 9 * (1 - pct) + 2;
        ctx.beginPath();
        ctx.arc(0, 0, e.radius * (0.4 + pct * 0.7), 0, TAU);
        ctx.stroke();
        ctx.fillStyle = "rgba(127, 240, 192, .18)";
        ctx.beginPath();
        ctx.arc(0, 0, e.radius * (0.5 + pct * 0.6), 0, TAU);
        ctx.fill();
        ctx.strokeStyle = "#fff4d6";
        ctx.lineWidth = 4;
        ctx.strokeRect(-42, -42, 84, 84);
        ctx.fillStyle = "#9ff2c6";
        ctx.font = `900 ${30 + pct * 10}px ${FONT_DISPLAY}`;
        ctx.textAlign = "center";
        ctx.fillText("盖", 0, 12);
      } else if (e.kind === "shockwave") {
        ctx.globalAlpha = 1 - pct;
        ctx.strokeStyle = e.color;
        ctx.lineWidth = 6;
        ctx.beginPath();
        ctx.arc(0, 0, e.radius * pct, 0, TAU);
        ctx.stroke();
      } else if (e.kind === "heal") {
        ctx.globalAlpha = 1 - pct;
        ctx.fillStyle = "#6ff2a1";
        ctx.font = `28px ${FONT_DISPLAY}`;
        ctx.textAlign = "center";
        ctx.fillText("+", 0, -pct * 55);
      } else if (e.kind === "slipper") {
        ctx.globalAlpha = 1 - pct;
        ctx.font = `900 ${40 + pct * 20}px ${FONT_DISPLAY}`;
        ctx.fillStyle = "#ffd447";
        ctx.strokeStyle = INK;
        ctx.lineWidth = 8;
        ctx.textAlign = "center";
        ctx.strokeText("啪！", 0, 0);
        ctx.fillText("啪！", 0, 0);
      } else if (e.kind === "boss") {
        ctx.globalAlpha = 1 - pct;
        ctx.strokeStyle = "#ff334f";
        ctx.lineWidth = 8;
        ctx.beginPath();
        ctx.arc(0, 0, e.radius * (0.4 + pct), 0, TAU);
        ctx.stroke();
      } else if (e.kind === "scan") {
        ctx.globalAlpha = (1 - pct) * 0.6;
        ctx.strokeStyle = "#69e7ff";
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(-e.radius, 0);
        ctx.lineTo(e.radius, 0);
        ctx.stroke();
      }
      ctx.restore();
    }
    void t;
  }

  private drawParticles(particles: Particle[]) {
    const ctx = this.ctx;
    for (const p of particles) {
      const pct = p.life / p.maxLife;
      ctx.save();
      ctx.globalAlpha = Math.min(1, pct * 2) * p.alpha;
      ctx.translate(p.x, p.y);
      ctx.rotate(p.rot);
      if (p.kind === "text" && p.text) {
        ctx.font = `900 ${p.size * 2.2}px ${FONT_DISPLAY}`;
        ctx.fillStyle = p.color;
        ctx.strokeStyle = INK;
        ctx.lineWidth = 4;
        ctx.textAlign = "center";
        ctx.strokeText(p.text, 0, 0);
        ctx.fillText(p.text, 0, 0);
      } else if (p.kind === "ring") {
        ctx.strokeStyle = p.color;
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.arc(0, 0, p.size * (2.2 - pct), 0, TAU);
        ctx.stroke();
      } else if (p.kind === "star") {
        ctx.fillStyle = p.color;
        starPath(ctx, 0, 0, p.size, 4, 0.25);
        ctx.fill();
      } else if (p.kind === "paper") {
        ctx.fillStyle = p.color;
        ctx.fillRect(-p.size, -p.size * 0.65, p.size * 2, p.size * 1.3);
        ctx.strokeStyle = INK;
        ctx.lineWidth = 1.5;
        ctx.strokeRect(-p.size, -p.size * 0.65, p.size * 2, p.size * 1.3);
      } else if (p.kind === "leaf") {
        ctx.fillStyle = p.color;
        ctx.beginPath();
        ctx.ellipse(0, 0, p.size, p.size * 0.45, 0, 0, TAU);
        ctx.fill();
      } else {
        ctx.fillStyle = p.color;
        if (p.kind === "square") ctx.fillRect(-p.size, -p.size, p.size * 2, p.size * 2);
        else {
          ctx.beginPath();
          ctx.arc(0, 0, p.size, 0, TAU);
          ctx.fill();
        }
      }
      ctx.restore();
    }
  }

  private drawFloating(game: Game) {
    const ctx = this.ctx;
    for (const f of game.texts) {
      const pct = f.life / f.maxLife;
      ctx.save();
      ctx.globalAlpha = Math.min(1, pct * 2.4);
      ctx.translate(f.x, f.y);
      ctx.rotate(f.rot);
      ctx.font = `900 ${f.size}px ${FONT_DISPLAY}`;
      ctx.textAlign = "center";
      ctx.lineWidth = 7;
      ctx.strokeStyle = INK;
      ctx.strokeText(f.text, 0, 0);
      ctx.fillStyle = f.color;
      ctx.fillText(f.text, 0, 0);
      ctx.restore();
    }
  }

  private drawHover(game: Game, t: number) {
    if (!game.selected && !game.shovel) return;
    const ctx = this.ctx;
    const { x, y, cw, ch } = BOARD;
    if (game.hoverCell) {
      const [col, row] = game.hoverCell;
      const occupied = game.plants.some((p) => p.col === col && p.row === row && !p.dead);
      const valid = game.shovel ? occupied : !occupied;
      ctx.save();
      ctx.globalAlpha = 0.8;
      ctx.fillStyle = valid ? "rgba(223, 255, 67, .17)" : "rgba(255, 61, 141, .18)";
      rr(ctx, x + col * cw + 5, y + row * ch + 5, cw - 10, ch - 10, 12);
      ctx.fill();
      ctx.strokeStyle = valid ? "#dfff43" : "#ff3d8d";
      ctx.lineWidth = 3;
      ctx.setLineDash([8, 8]);
      ctx.lineDashOffset = -t * 30;
      ctx.stroke();
      ctx.setLineDash([]);

      if (game.selected && valid) {
        const ghost = sprite(PLANTS[game.selected].sprite);
        if (ghost) {
          ctx.globalAlpha = 0.42;
          ctx.drawImage(ghost, x + col * cw + 3, y + row * ch + 1, cw - 6, ch - 6);
        }
      }
      ctx.restore();
    }
  }

  private drawFog(game: Game, t: number) {
    if (!game.modifiers.has("fog")) return;
    const ctx = this.ctx;
    ctx.save();
    ctx.globalCompositeOperation = "screen";
    for (let i = 0; i < 5; i++) {
      const x = ((t * 18 + i * 340) % (STAGE_W + 500)) - 250;
      const y = BOARD.y + 50 + i * 105 + Math.sin(t * 0.3 + i) * 20;
      const g = ctx.createRadialGradient(x, y, 20, x, y, 280);
      g.addColorStop(0, "rgba(218, 232, 255, .16)");
      g.addColorStop(0.6, "rgba(205, 222, 255, .08)");
      g.addColorStop(1, "rgba(200, 220, 255, 0)");
      ctx.fillStyle = g;
      ctx.fillRect(x - 300, y - 200, 600, 400);
    }
    ctx.restore();
  }

  private drawVision(game: Game, t: number) {
    if (!game.visionVisible || !game.visionReport) return;
    const ctx = this.ctx;
    const colors: Record<string, string> = {
      plant: "#6ff2a1",
      zombie: "#ff5d6c",
      boss: "#ffd447",
      sun: "#ffe66d",
      projectile: "#69e7ff",
    };
    ctx.save();
    for (const d of game.visionReport.detections) {
      const color = colors[d.class] ?? "#bca7ff";
      const x = d.x;
      const y = d.y;
      const w = d.w;
      const h = d.h;
      const len = Math.min(18, w * 0.22);
      ctx.globalAlpha = 0.9;
      ctx.strokeStyle = color;
      ctx.lineWidth = 2.2;
      ctx.beginPath();
      ctx.moveTo(x, y + len);
      ctx.lineTo(x, y);
      ctx.lineTo(x + len, y);
      ctx.moveTo(x + w - len, y);
      ctx.lineTo(x + w, y);
      ctx.lineTo(x + w, y + len);
      ctx.moveTo(x, y + h - len);
      ctx.lineTo(x, y + h);
      ctx.lineTo(x + len, y + h);
      ctx.moveTo(x + w - len, y + h);
      ctx.lineTo(x + w, y + h);
      ctx.lineTo(x + w, y + h - len);
      ctx.stroke();
      ctx.fillStyle = color;
      ctx.globalAlpha = 0.82;
      ctx.font = `10px ${FONT_MONO}`;
      const label = `${d.label} ${(d.confidence * 100).toFixed(0)}%`;
      ctx.fillText(label, x + 2, y - 5 < 10 ? y + h + 12 : y - 5);
    }
    // Scanning sweep line.
    const sweep = (t * 0.6) % 1;
    const sy = BOARD.y + sweep * BOARD.h;
    ctx.globalAlpha = 0.35;
    ctx.strokeStyle = "#69e7ff";
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(BOARD.x, sy);
    ctx.lineTo(BOARD.right, sy);
    ctx.stroke();
    ctx.globalAlpha = 0.08;
    ctx.fillStyle = "#69e7ff";
    ctx.fillRect(BOARD.x, sy - 30, BOARD.w, 30);

    // Frame label.
    ctx.globalAlpha = 0.9;
    ctx.strokeStyle = "#69e7ff";
    ctx.lineWidth = 2;
    ctx.strokeRect(BOARD.x - 4, BOARD.y - 4, BOARD.w + 8, BOARD.h + 8);
    ctx.fillStyle = "#69e7ff";
    ctx.font = `11px ${FONT_MONO}`;
    ctx.fillText("YOLO-EYE / LIVE INFERENCE", BOARD.x + 2, BOARD.y - 10);
    ctx.restore();
  }

  private drawBossBar(game: Game) {
    const boss = game.zombies.find((z) => z.boss && !z.dead);
    if (!boss) return;
    const emperor = boss.type === "emperor";
    const ctx = this.ctx;
    const w = 620;
    const x = (STAGE_W - w) / 2;
    const y = 104;
    ctx.save();
    ctx.fillStyle = "rgba(20, 7, 26, .8)";
    rr(ctx, x - 8, y - 8, w + 16, 38, 10);
    ctx.fill();
    ctx.strokeStyle = emperor ? "#ffd447" : "#ff334f";
    ctx.lineWidth = 3;
    ctx.stroke();
    ctx.fillStyle = "#ffcf4a";
    ctx.font = `12px ${FONT_MONO}`;
    ctx.fillText(
      game.finalBossSpawned
        ? `FINAL DEFENSE / ${game.bossName}`
        : emperor
          ? "FINAL DEFENSE / 早八皇帝 · 受命于天"
          : "FINAL DEFENSE / 终审导师",
      x + 4,
      y + 3,
    );
    const pct = Math.max(0, boss.hp / boss.maxHp);
    ctx.fillStyle = emperor ? "rgba(255,212,71,.18)" : "rgba(255,51,79,.2)";
    rr(ctx, x, y + 8, w, 10, 5);
    ctx.fill();
    ctx.fillStyle = emperor ? "#ffd447" : "#ff334f";
    rr(ctx, x, y + 8, w * pct, 10, 5);
    ctx.fill();
    ctx.restore();
  }

  private drawVignette() {
    const ctx = this.ctx;
    const g = ctx.createRadialGradient(STAGE_W / 2, STAGE_H / 2, 380, STAGE_W / 2, STAGE_H / 2, 1000);
    g.addColorStop(0, "rgba(0,0,0,0)");
    g.addColorStop(1, "rgba(8,3,18,.48)");
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, STAGE_W, STAGE_H);

    ctx.save();
    ctx.globalAlpha = 0.5;
    ctx.globalCompositeOperation = "multiply";
    ctx.fillStyle = ctx.createPattern(this.grain, "repeat")!;
    ctx.fillRect(0, 0, STAGE_W, STAGE_H);
    ctx.restore();
  }

  drawScanFlash(color = "#dfff43") {
    const ctx = this.ctx;
    ctx.save();
    ctx.globalAlpha = 0.18;
    ctx.fillStyle = color;
    ctx.fillRect(0, 0, STAGE_W, STAGE_H);
    ctx.restore();
  }

  detectionBoxes(detections: Detection[]) {
    return detections;
  }

  drawCursorGlow(x: number, y: number, color: string, t: number) {
    const ctx = this.ctx;
    ctx.save();
    ctx.globalAlpha = 0.4;
    ctx.strokeStyle = color;
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(x, y, 12 + Math.sin(t * 6) * 3, 0, TAU);
    ctx.stroke();
    ctx.restore();
  }
}
