import { chromium } from "playwright-core";
const browser = await chromium.launch({ executablePath: "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe", headless: true, args: ["--disable-gpu"] });
const page = await browser.newPage({ viewport: { width: 1600, height: 900 } });
const errors = [];
page.on("pageerror", (e) => errors.push(e.message));
await page.goto("http://127.0.0.1:8000/?debug", { waitUntil: "networkidle" });
await page.waitForTimeout(2400);
const result = await page.evaluate(() => {
  const { game: g, ui } = window.__nailong;
  g.agent = null;
  g.events.onToast = () => {};
  g.events.onNotice = () => {};
  ui.showGame();
  g.startLevel(0);
  g.screen = "playing";
  g.wave = 1;
  g.waveActive = true;
  g.sun = 9999;
  g.prepTimer = 60;
  for (const id of ["flower", "pea", "doublepea", "wall", "frost", "fan", "bomb", "cannon", "vacuum", "boomerang", "seal"]) g.readyAt[id] = 0;
  g.placePlant("flower", 2, 0);
  g.placePlant("doublepea", 5, 0);
  g.placePlant("wall", 4, 1);
  g.spawnZombie("basic", 1);
  const z = g.zombies[g.zombies.length - 1];
  z.x = 4 * (946 / 12) + 250 + 60;
  z.hp = z.maxHp * 0.5;
  const wall = g.plants.find((p) => p.type === "wall");
  const flower = g.plants.find((p) => p.type === "flower");
  const shooter = g.plants.find((p) => p.type === "doublepea");
  shooter.shootTimer = 0;
  const before = { flowerHp: flower.hp, zHp: z.hp, zSpeed: z.baseSpeed, wallHp: wall.hp };
  for (let i = 0; i < 140; i++) g.update(0.05);
  const after = {
    flowerHp: flower.hp,
    zHp: z.hp,
    zSpeed: z.baseSpeed,
    wallHp: wall.hp,
    cols: 12,
    farPlant: g.placePlant("flower", 10, 4),
  };
  g.pause();
  document.querySelector("#toast-layer").innerHTML = "";
  return { before, after, plants: g.plants.length, zombies: g.zombies.length };
});
console.log(JSON.stringify(result, null, 2));
console.log("errors", errors);
await page.screenshot({ path: "demo/new-mechanics.png" });
await browser.close();
