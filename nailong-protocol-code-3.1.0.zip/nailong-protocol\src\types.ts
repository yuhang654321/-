export type PlantId =
  | "flower"
  | "pea"
  | "doublepea"
  | "wall"
  | "frost"
  | "fan"
  | "bomb"
  | "cannon"
  | "vacuum"
  | "boomerang"
  | "seal";
export type ZombieId = "basic" | "fast" | "paper" | "coffee" | "shield" | "ranged" | "weird" | "boss" | "emperor";
export type ModifierId =
  | "none"
  | "sunstorm"
  | "fog"
  | "discount"
  | "speed"
  | "tank"
  | "heal"
  | "paper"
  | "gold"
  | "clone"
  | "blessing";

export type Screen = "boot" | "title" | "playing" | "paused" | "won" | "lost";

export interface PlantDef {
  id: PlantId;
  name: string;
  en: string;
  role: string;
  cost: number;
  cooldown: number;
  hp: number;
  sprite: string;
  color: string;
  accent: string;
  glyph: string;
  desc: string;
}

export interface ZombieDef {
  id: ZombieId;
  name: string;
  en: string;
  hp: number;
  armor: number;
  speed: number;
  dps: number;
  reward: number;
  sprite: string;
  color: string;
  scale: number;
  desc: string;
}

export interface DirectorEvent {
  title: string;
  line: string;
  modifier: ModifierId;
  source: "llm" | "fallback" | "local";
}

export interface WaveGroup {
  type: ZombieId;
  count: number;
  start: number;
  gap: number;
  boss?: boolean;
}

export interface WaveDef {
  index: number;
  name: string;
  subtitle: string;
  groups: WaveGroup[];
  breakAfter: number;
  hpScale: number;
}

export interface LevelDef {
  id: string;
  index: number;
  name: string;
  codename: string;
  subtitle: string;
  desc: string;
  difficulty: number;
  rule: ModifierId;
  startSun: number;
  houseHp: number;
  waves: WaveDef[];
  boss: boolean;
  accent: string;
  stamp: string;
}

export interface Plant {
  uid: number;
  type: PlantId;
  col: number;
  row: number;
  x: number;
  y: number;
  hp: number;
  maxHp: number;
  shootTimer: number;
  produceTimer: number;
  age: number;
  flash: number;
  action: number;
  dead: boolean;
  fuse?: number;
  shield: number;
  stun: number;
  laughing?: number;
}

export interface Zombie {
  uid: number;
  type: ZombieId;
  row: number;
  x: number;
  y: number;
  hp: number;
  maxHp: number;
  armor: number;
  maxArmor: number;
  speed: number;
  baseSpeed: number;
  dps: number;
  attackTimer: number;
  eating: boolean;
  flash: number;
  slow: number;
  stun: number;
  age: number;
  action: number;
  dead: boolean;
  boss: boolean;
  scale: number;
  abilityTimer: number;
  hitStop: number;
  laughTimer: number;
  carrying: boolean;
  carryPlantUid?: number;
  carryType?: PlantId;
  wallFed?: boolean;
  finalBoss?: boolean;
  bossSkill?: number;
}

export interface Projectile {
  uid: number;
  kind: "speech" | "ice" | "ddl" | "wind" | "slipper" | "boba" | "boomerang" | "seal";
  x: number;
  y: number;
  row: number;
  vx: number;
  vy: number;
  damage: number;
  slow: number;
  life: number;
  dead: boolean;
  gravity?: number;
  spin: number;
  text?: string;
  originX?: number;
  returning?: boolean;
  groundY?: number;
  hitIds?: number[];
  friendly?: boolean;
  targetPlantUid?: number;
  targetZombieUid?: number;
}

export interface SunToken {
  uid: number;
  x: number;
  y: number;
  targetY: number;
  vy: number;
  value: number;
  life: number;
  age: number;
  phase: number;
  collected: boolean;
  fromSky: boolean;
}

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  gravity: number;
  life: number;
  maxLife: number;
  size: number;
  color: string;
  kind: "dot" | "square" | "ring" | "text" | "leaf" | "star" | "paper";
  text?: string;
  rot: number;
  vr: number;
  alpha: number;
}

export interface FloatingText {
  x: number;
  y: number;
  text: string;
  color: string;
  life: number;
  maxLife: number;
  size: number;
  vy: number;
  rot: number;
}

export interface VisualEffect {
  kind: "explosion" | "wind" | "freeze" | "slipper" | "boss" | "heal" | "scan" | "shockwave" | "suck" | "seal";
  x: number;
  y: number;
  row: number;
  life: number;
  maxLife: number;
  radius: number;
  color: string;
}

export interface Detection {
  class: string;
  label: string;
  confidence: number;
  x: number;
  y: number;
  w: number;
  h: number;
}

export interface VisionReport {
  detections: Detection[];
  counts: Record<string, number>;
  ms: number;
  source: string;
  error?: string;
}

export interface AgentAction {
  type: "grant_sun" | "heal" | "spawn" | "bless" | "favor" | "tip" | "none";
  amount?: number;
  zombie?: ZombieId;
  reason?: string;
}

export interface ChatTurn {
  role: "user" | "assistant";
  content: string;
}

export interface AgentReply {
  reply: string;
  action: AgentAction;
  source: "llm" | "fallback" | "tool";
  model?: string;
  sources?: { title: string; url: string }[];
  researched?: boolean;
}

export interface GameStats {
  kills: number;
  sunCollected: number;
  plantsPlaced: number;
  waves: number;
  time: number;
  aiLines: number;
  yoloScans: number;
  bombs: number;
  carries?: number;
  levelIndex?: number;
  levelName?: string;
  totalWaves?: number;
  mode?: "level" | "classic";
}

export interface GameSnapshot {
  wave: number;
  totalWaves: number;
  sun: number;
  hp: number;
  kills: number;
  plants: number;
  zombies: number;
  boss: boolean;
  lanesInDanger: number;
  selected: PlantId | null;
  levelIndex: number;
  levelName: string;
  levelId: string;
  difficulty: number;
  mode: "level" | "classic";
  stageRule: ModifierId;
  totalLevels: number;
  flowers?: number;
  walls?: number;
  shooters?: number;
  dangerRows?: number[];
  plantWipe?: boolean;
  matchProgress?: number;
  bossActive?: boolean;
  bossDefeated?: boolean;
}
