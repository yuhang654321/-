import { chromium } from "playwright-core";
const browser = await chromium.launch({ executablePath: "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe", headless: true, args: ["--disable-gpu"] });
const page = await browser.newPage({ viewport: { width: 1600, height: 900 } });
const errors = [];
page.on("pageerror", (e) => errors.push(e.message));
page.on("console", (m) => { if (m.type() === "error") errors.push(m.text()); });
await page.goto("http://127.0.0.1:8000/?debug", { waitUntil: "networkidle" });
await page.waitForTimeout(2400);
await page.click("#start-btn");
await page.waitForTimeout(250);
await page.locator(".level-card").first().click();
await page.waitForTimeout(600);
const wiped = await page.evaluate(() => {
  const { game: g } = window.__nailong;
  g.events.onToast = () => {};
  g.events.onNotice = () => {};
  g.sun = 999;
  for (const id of ["flower", "pea", "wall", "frost", "fan", "bomb", "cannon", "vacuum", "boomerang", "seal"]) g.readyAt[id] = 0;
  g.placePlant("flower", 0, 0);
  g.placePlant("wall", 1, 1);
  g.placePlant("frost", 2, 2);
  const before = { plants: g.plants.length, sun: g.sun, flowerHp: g.plants[0].hp };
  g.wipePlants();
  return {
    before,
    wiped: {
      plantWipe: g.plantWipe,
      plants: g.plants.length,
      cooldown: Math.round(g.cooldownLeft("flower")),
      backup: g.plantWipeBackup.length,
      sun: g.sun,
    },
  };
});
await page.waitForTimeout(250);
await page.screenshot({ path: "demo/doom-wipe.png" });
const rescued = await page.evaluate(async () => {
  const { game: g } = window.__nailong;
  const reply = await g.chat("妈妈求求你帮我", []);
  return {
    plantWipe: g.plantWipe,
    plants: g.plants.length,
    cooldown: Math.round(g.cooldownLeft("flower")),
    sun: g.sun,
    reply: reply.reply,
    action: reply.action.type,
    verdict: g.visionVerdict,
  };
});
await page.waitForTimeout(300);
await page.screenshot({ path: "demo/doom-rescue.png" });
console.log(JSON.stringify({ ...wiped, rescued }, null, 2));
console.log("errors", errors);
if (!(wiped.wiped.plantWipe && wiped.wiped.plants === 0 && wiped.wiped.cooldown >= 14 && rescued.plantWipe === false && rescued.plants === 3 && rescued.cooldown === 0 && rescued.action === "favor")) {
  console.error("FAIL doom/mom rescue");
  process.exitCode = 1;
} else {
  console.log("PASS doom/mom rescue");
}
await browser.close();
