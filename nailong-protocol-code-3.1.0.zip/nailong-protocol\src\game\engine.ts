import {
  BOARD,
  FALLBACK_EVENTS,
  HOUSE,
  IDLE_LINES,
  LEVELS,
  MODIFIERS,
  MODIFIER_POOL,
  PLANTS,
  PLANT_ORDER,
  START_SUN,
  TOTAL_WAVES,
  WAVES,
  WAVE_TAUNTS,
  ZOMBIES,
} from "./content";
import type {
  AgentReply,
  ChatTurn,
  Detection,
  DirectorEvent,
  FloatingText,
  GameSnapshot,
  GameStats,
  LevelDef,
  ModifierId,
  Particle,
  Plant,
  PlantId,
  Projectile,
  SunToken,
  VisionReport,
  VisualEffect,
  WaveDef,
  Zombie,
  ZombieId,
} from "../types";
import { AudioEngine } from "./audio";

export interface DirectorBackend {
  director(payload: { wave: number; snapshot: GameSnapshot }): Promise<DirectorEvent>;
  chat(payload: { message: string; snapshot: GameSnapshot; history: ChatTurn[] }): Promise<AgentReply>;
  vision?: (image: string, domain: "abstract" | "real") => Promise<VisionReport>;
}

interface SpawnItem {
  type: ZombieId;
  at: number;
  row?: number;
}

type VisionTone = "good" | "bad" | "catastrophe";

interface VisionCard {
  id: string;
  name: string;
  line: string;
  tone: VisionTone;
}

const ZOMBIE_SPEED_SCALE = 0.5;
const ZOMBIE_HP_SCALE = 1.55;
const ZOMBIE_ARMOR_SCALE = 1.3;
const MIN_LEVEL_SECONDS = 240;
const SPAWN_GAP_SCALE = 1.35;
const SPAWN_MIN_INTERVAL = 0.9;
const BOSS_SKILLS = [
  { name: "开学点名", line: "全体植物僵直 1.8 秒" },
  { name: "闹钟连环", line: "召唤两只滑板人" },
  { name: "点名册", line: "随机两株植物停摆" },
  { name: "插队", line: "Boss 向前突进 90 像素" },
  { name: "红笔批注", line: "所有植物失去 8% 生命" },
  { name: "查重护盾", line: "Boss 获得额外护甲" },
  { name: "拉闸停电", line: "第三只眼强制关闭" },
  { name: "小组分工", line: "召唤三只滑板人" },
  { name: "咖啡因过载", line: "所有僵尸永久 +20% 移速" },
  { name: "期末加考", line: "召唤论文与早八人" },
  { name: "答辩追问", line: "全体植物僵直 2.2 秒" },
  { name: "玉玺镇压", line: "Boss 回血并获得护盾" },
  { name: "平行召唤", line: "召唤四只滑板人" },
  { name: "冕旒仪仗", line: "召唤两只冰咖啡并套盾" },
  { name: "传国玉玺", line: "回复 25% 生命，召唤论文与滑板人" },
] as const;
const LOCAL_LURES = [
  "叫一声姐姐，私下给你 +30 灵感。",
  "喊姐姐，这波给你开个小灶，+30 灵感。",
  "姐姐两个字换 30 灵感，不亏吧？",
  "叫姐姐，我偷偷塞你 30 灵感，别声张。",
];

const makeReadyAt = (): Record<PlantId, number> => {
  const ready = {} as Record<PlantId, number>;
  for (const id of PLANT_ORDER) ready[id] = 0;
  ready.bomb = 14;
  return ready;
};

export interface GameEvents {
  onWave?: (wave: number, event: DirectorEvent) => void;
  onToast?: (text: string, color?: string) => void;
  onEnd?: (win: boolean, stats: GameStats) => void;
  onAgentLine?: (line: string) => void;
  onVision?: (report: VisionReport, sync: number) => void;
  onNotice?: (text: string) => void;
}

const rand = (a: number, b: number) => a + Math.random() * (b - a);
const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));
const pick = <T,>(arr: T[]): T => arr[Math.floor(Math.random() * arr.length)];

export class Game {
  readonly audio: AudioEngine;
  agent: DirectorBackend | null = null;
  events: GameEvents = {};

  screen: "title" | "playing" | "paused" | "won" | "lost" = "title";
  mode: "level" | "classic" = "level";
  levelIndex = 0;
  levelWaves: WaveDef[] = LEVELS[0].waves;
  levelRule: ModifierId = "none";
  levelStartSun = LEVELS[0].startSun;
  levelHp = LEVELS[0].houseHp;
  time = 0;
  sun = START_SUN;
  plants: Plant[] = [];
  zombies: Zombie[] = [];
  projectiles: Projectile[] = [];
  suns: SunToken[] = [];
  particles: Particle[] = [];
  texts: FloatingText[] = [];
  effects: VisualEffect[] = [];
  selected: PlantId | null = null;
  shovel = false;
  hoverCell: [number, number] | null = null;
  shake = 0;
  flash = 0;
  houseHp = 100;
  wave = 0;
  waveActive = false;
  waveElapsed = 0;
  prepTimer = 0;
  spawnQueue: SpawnItem[] = [];
  private spawnReserve: SpawnItem[] = [];
  private spawnGate = 0;
  modifiers = new Set<ModifierId>();
  currentEvent: DirectorEvent | null = null;
  preparedEvent: DirectorEvent | null = null;
  pendingEventFor = 0;
  readyAt: Record<PlantId, number> = makeReadyAt();
  slippers: boolean[] = Array.from({ length: BOARD.rows }, () => true);
  laneDanger: number[] = Array.from({ length: BOARD.rows }, () => 0);
  stats: GameStats = { kills: 0, sunCollected: 0, plantsPlaced: 0, waves: 0, time: 0, aiLines: 0, yoloScans: 0, bombs: 0, carries: 0 };
  visionVisible = false;
  visionReport: VisionReport | null = null;
  visionSync = 0;
  visionVerdict = "";
  visionTone: "good" | "bad" | "catastrophe" | "" = "";
  plantWipe = false;
  private plantWipeBackup: Array<{ type: PlantId; col: number; row: number }> = [];
  visionBusy = false;
  visionLastAt = 0;
  private uid = 1;
  private skyTimer = 5;
  private idleTimer = 18;
  private lastHouseHit = 0;
  private lastSpawnCheat = -999;
  private overtimeWaves = 0;
  private duelRows = new Set<number>();
  private carryNoticeShown = false;
  finalBossSpawned = false;
  finalBossDefeated = false;
  private majorWavesFired = 0;
  bossName = "";
  private bossAnnounced = false;
  private agentBusy = false;

  constructor(audio: AudioEngine) {
    this.audio = audio;
    this.events = {};
  }

  attachAgent(agent: DirectorBackend) {
    this.agent = agent;
  }

  reset() {
    this.time = 0;
    this.sun = START_SUN;
    this.plants = [];
    this.zombies = [];
    this.projectiles = [];
    this.suns = [];
    this.particles = [];
    this.texts = [];
    this.effects = [];
    this.selected = null;
    this.shovel = false;
    this.hoverCell = null;
    this.shake = 0;
    this.flash = 0;
    this.houseHp = 100;
    this.wave = 0;
    this.waveActive = false;
    this.waveElapsed = 0;
    this.prepTimer = 8;
    this.spawnQueue = [];
    this.spawnReserve = [];
    this.spawnGate = 0;
    this.modifiers.clear();
    this.currentEvent = null;
    this.preparedEvent = null;
    this.pendingEventFor = 0;
    this.readyAt = makeReadyAt();
    this.slippers = Array.from({ length: BOARD.rows }, () => true);
    this.laneDanger = Array.from({ length: BOARD.rows }, () => 0);
    this.stats = { kills: 0, sunCollected: 0, plantsPlaced: 0, waves: 0, time: 0, aiLines: 0, yoloScans: 0, bombs: 0, carries: 0 };
    this.visionVisible = false;
    this.visionReport = null;
    this.visionSync = 0;
    this.visionVerdict = "";
    this.visionTone = "";
    this.plantWipe = false;
    this.plantWipeBackup = [];
    this.visionBusy = false;
    this.visionLastAt = 0;
    this.uid = 1;
    this.skyTimer = 4;
    this.idleTimer = 18;
    this.lastHouseHit = 0;
    this.lastSpawnCheat = -999;
    this.overtimeWaves = 0;
    this.duelRows.clear();
    this.carryNoticeShown = false;
    this.finalBossSpawned = false;
    this.finalBossDefeated = false;
    this.majorWavesFired = 0;
    this.bossName = "";
    this.bossAnnounced = false;
    this.agentBusy = false;
  }

  startLevel(index: number) {
    const lvl = LEVELS[Math.max(0, Math.min(LEVELS.length - 1, index))];
    this.reset();
    this.mode = "level";
    this.levelIndex = lvl.index - 1;
    this.levelWaves = lvl.waves;
    this.levelRule = lvl.rule;
    this.levelStartSun = lvl.startSun;
    this.levelHp = lvl.houseHp;
    this.sun = lvl.startSun;
    this.houseHp = lvl.houseHp;
    this.prepTimer = 7;
    this.screen = "playing";
    this.audio.startMusic();
    this.prepareNextEvent();
    this.spawnSkySun(true);
    this.events.onNotice?.(
      `L${String(lvl.index).padStart(2, "0")} · ${lvl.name}。规则：${lvl.rule === "none" ? "无额外舞台效果" : MODIFIERS[lvl.rule].label}。`,
    );
  }

  startClassic() {
    this.reset();
    this.mode = "classic";
    this.levelIndex = 0;
    this.levelWaves = WAVES;
    this.levelRule = "none";
    this.levelStartSun = START_SUN;
    this.levelHp = 100;
    this.sun = START_SUN;
    this.houseHp = 100;
    this.prepTimer = 8;
    this.screen = "playing";
    this.audio.startMusic();
    this.prepareNextEvent();
    this.spawnSkySun(true);
    this.events.onNotice?.("经典模式：10 波完整早八。AI 导演全程自由发挥。");
  }

  startRun() {
    this.startLevel(0);
  }

  pause() {
    if (this.screen !== "playing") return;
    this.screen = "paused";
  }

  resume() {
    if (this.screen !== "paused") return;
    this.screen = "playing";
  }

  get level(): LevelDef | null {
    return this.mode === "level" ? LEVELS[this.levelIndex] ?? null : null;
  }

  get levelName(): string {
    return this.mode === "level" ? this.level?.name ?? "早八关卡" : "经典 10 波";
  }

  get def() {
    return this.levelWaves[Math.max(0, Math.min(this.wave - 1, this.levelWaves.length - 1))];
  }

  get totalWaves() {
    return Math.max(1, this.levelWaves.length);
  }

  get matchProgress(): number {
    if (this.finalBossSpawned) return 1;
    return Math.min(1, this.time / MIN_LEVEL_SECONDS);
  }

  get bossActive(): boolean {
    return this.finalBossSpawned && !this.finalBossDefeated;
  }

  get prepTimeLeft() {
    return Math.max(0, this.prepTimer);
  }

  snapshot(): GameSnapshot {
    const aliveZombies = this.zombies.filter((z) => !z.dead);
    return {
      wave: Math.max(1, this.wave),
      totalWaves: this.totalWaves,
      sun: Math.floor(this.sun),
      hp: Math.round(this.houseHp),
      kills: this.stats.kills,
      plants: this.plants.length,
      zombies: aliveZombies.length,
      boss: aliveZombies.some((z) => z.boss),
      lanesInDanger: this.laneDanger.filter((d) => d > 0.35).length,
      selected: this.selected,
      levelIndex: this.mode === "level" ? this.levelIndex : -1,
      levelName: this.levelName,
      levelId: this.level?.id ?? "CLASSIC",
      difficulty: this.level?.difficulty ?? 5,
      mode: this.mode,
      stageRule: this.levelRule,
      totalLevels: LEVELS.length,
      flowers: this.plants.filter((p) => p.type === "flower" && !p.dead).length,
      walls: this.plants.filter((p) => p.type === "wall" && !p.dead).length,
      shooters: this.plants.filter((p) => ["pea", "doublepea", "frost", "cannon", "boomerang", "seal"].includes(p.type) && !p.dead).length,
      dangerRows: [...this.laneDanger],
      plantWipe: this.plantWipe,
      matchProgress: this.matchProgress,
      bossActive: this.bossActive,
      bossDefeated: this.finalBossDefeated,
    };
  }

  plantCost(id: PlantId): number {
    const base = PLANTS[id].cost;
    if (this.modifiers.has("discount")) return Math.round((base * 0.5) / 5) * 5;
    return base;
  }

  cooldownLeft(id: PlantId): number {
    return Math.max(0, this.readyAt[id] - this.time);
  }

  canPlace(id: PlantId): boolean {
    return this.sun >= this.plantCost(id) && this.time >= this.readyAt[id];
  }

  selectPlant(id: PlantId) {
    if (this.screen !== "playing") return;
    if (this.selected === id) {
      this.selected = null;
      return;
    }
    this.selected = id;
    this.shovel = false;
    this.audio.ui();
  }

  toggleShovel() {
    if (this.screen !== "playing") return;
    this.shovel = !this.shovel;
    if (this.shovel) this.selected = null;
    this.audio.ui();
  }

  clearSelection() {
    this.selected = null;
    this.shovel = false;
  }

  setHover(x: number, y: number) {
    const col = Math.floor((x - BOARD.x) / BOARD.cw);
    const row = Math.floor((y - BOARD.y) / BOARD.ch);
    if (col >= 0 && col < BOARD.cols && row >= 0 && row < BOARD.rows) this.hoverCell = [col, row];
    else this.hoverCell = null;
  }

  pointerDown(x: number, y: number) {
    if (this.screen !== "playing") return;
    const sun = this.nearestSun(x, y);
    if (sun) {
      this.collectSun(sun);
      return;
    }
    if (x < BOARD.x || x > BOARD.right || y < BOARD.y || y > BOARD.bottom) return;
    const col = Math.floor((x - BOARD.x) / BOARD.cw);
    const row = Math.floor((y - BOARD.y) / BOARD.ch);
    if (col < 0 || col >= BOARD.cols || row < 0 || row >= BOARD.rows) return;
    const occupying = this.plants.find((p) => p.col === col && p.row === row && !p.dead);
    if (this.shovel) {
      if (occupying) this.removePlant(occupying);
      else this.audio.deny();
      return;
    }
    if (!this.selected) return;
    this.placePlant(this.selected, col, row);
  }

  private placePlant(type: PlantId, col: number, row: number) {
    const occupied = this.plants.some((p) => p.col === col && p.row === row && !p.dead);
    if (occupied) {
      this.audio.deny();
      this.addText(BOARD.x + col * BOARD.cw + 46, BOARD.y + row * BOARD.ch + 40, "有东西了", "#ff7f9d", 24);
      return;
    }
    if (!this.canPlace(type)) {
      this.audio.deny();
      const reason = this.sun < this.plantCost(type) ? "灵感不够" : "卡还在冷却";
      this.addText(BOARD.x + col * BOARD.cw + 46, BOARD.y + row * BOARD.ch + 40, reason, "#ff7f9d", 22);
      return;
    }
    const def = PLANTS[type];
    const cost = this.plantCost(type);
    this.sun -= cost;
    this.readyAt[type] = this.time + def.cooldown;
    const p: Plant = {
      uid: this.uid++,
      type,
      col,
      row,
      x: BOARD.x + col * BOARD.cw,
      y: BOARD.y + row * BOARD.ch,
      hp: def.hp,
      maxHp: def.hp,
      shootTimer: type === "pea" ? 0.35 : rand(0.2, 0.9),
      produceTimer: type === "flower" ? 5.5 : 0,
      age: 0,
      flash: 0,
      action: 0,
      dead: false,
      fuse: type === "bomb" ? 1.2 : undefined,
      shield: 0,
      stun: 0,
    };
    if (this.modifiers.has("blessing")) p.shield = 150;
    this.plants.push(p);
    this.stats.plantsPlaced++;
    this.selected = null;
    this.audio.plant();
    this.addText(p.x + BOARD.cw / 2, p.y + 34, def.name, def.color, 24);
    this.burst(p.x + BOARD.cw / 2, p.y + BOARD.ch - 36, [def.color, "#fff4d6", "#1c102c"], 14, "dot");
    this.addEffect("heal", p.x + BOARD.cw / 2, p.y + BOARD.ch / 2, row, 0.45, 48, "rgba(111,242,161,.8)");
  }

  private removePlant(p: Plant) {
    if (p.dead) return;
    p.dead = true;
    const refund = Math.round(this.plantCost(p.type) * 0.25);
    this.sun += refund;
    this.burst(p.x + BOARD.cw / 2, p.y + BOARD.ch / 2, [PLANTS[p.type].color, "#fff4d6"], 16, "square");
    this.addText(p.x + BOARD.cw / 2, p.y + 40, `+${refund} 回收`, "#dfff43", 20);
    this.audio.ui();
  }

  private nearestSun(x: number, y: number): SunToken | null {
    let best: SunToken | null = null;
    let bd = 58;
    for (const s of this.suns) {
      if (s.collected) continue;
      const d = Math.hypot(s.x - x, s.y - y);
      if (d < bd) {
        best = s;
        bd = d;
      }
    }
    return best;
  }

  private collectSun(s: SunToken) {
    s.collected = true;
    this.sun += s.value;
    this.stats.sunCollected += s.value;
    this.audio.sun();
    this.addText(s.x, s.y - 10, `+${s.value}`, "#ffe66d", 30);
    this.burst(s.x, s.y, ["#ffe66d", "#fff4d6", "#dfff43"], 18, "star");
    this.addEffect("heal", s.x, s.y, 0, 0.35, 40, "rgba(255,230,109,.8)");
  }

  update(dt: number) {
    if (this.screen !== "playing") return;
    dt = Math.min(dt, 0.05);
    this.time += dt;
    this.stats.time += dt;
    this.processSpawnReserve();
    this.updateMatchProgress();
    this.skyTimer -= dt;
    this.idleTimer -= dt;
    if (this.skyTimer <= 0) {
      this.spawnSkySun();
      this.skyTimer = this.modifiers.has("sunstorm") ? rand(2.8, 3.8) : rand(6.2, 8.2);
    }
    if (this.idleTimer <= 0) {
      this.idleTimer = rand(26, 40);
      const line = pick(IDLE_LINES);
      this.events.onAgentLine?.(line);
    }

    for (const id of PLANT_ORDER) {
      if (this.readyAt[id] < this.time - 4) this.readyAt[id] = this.time - 0.001;
    }

    this.updateWaves(dt);
    this.updatePlants(dt);
    this.updateZombies(dt);
    this.updateProjectiles(dt);
    this.updateSuns(dt);
    this.updateParticles(dt);
    this.updateEffects(dt);
    this.updateLaneDanger(dt);

    this.plants = this.plants.filter((p) => !p.dead);
    this.zombies = this.zombies.filter((z) => !z.dead);
    this.projectiles = this.projectiles.filter((p) => !p.dead);
    this.suns = this.suns.filter((s) => !s.collected && s.life > 0);
    this.particles = this.particles.filter((p) => p.life > 0);
    this.texts = this.texts.filter((f) => f.life > 0);
    this.effects = this.effects.filter((e) => e.life > 0);
    this.shake = Math.max(0, this.shake - dt * 34);
    this.flash = Math.max(0, this.flash - dt * 3.4);
    if (this.finalBossSpawned && this.finalBossDefeated && this.zombies.length === 0) this.win();
    if (this.houseHp <= 0) this.lose();
  }

  private updateMatchProgress() {
    if (this.time >= MIN_LEVEL_SECONDS && !this.finalBossSpawned) {
      this.spawnFinalBoss();
      return;
    }
    for (const at of [MIN_LEVEL_SECONDS / 3, MIN_LEVEL_SECONDS / 2]) {
      if (this.time >= at && this.majorWavesFired < (at === MIN_LEVEL_SECONDS / 3 ? 1 : 2)) {
        this.majorWavesFired = at === MIN_LEVEL_SECONDS / 3 ? 1 : 2;
        this.triggerMajorWave(at === MIN_LEVEL_SECONDS / 3 ? "三分之一" : "一半");
      }
    }
  }

  private triggerMajorWave(label: string) {
    const count = 4 + Math.floor(this.levelIndex / 2);
    const roster: ZombieId[] = ["basic", "fast", "paper"];
    if (this.levelIndex >= 3) roster.push("shield");
    if (this.levelIndex >= 5) roster.push("ranged");
    if (this.levelIndex >= 8) roster.push("weird");
    for (let i = 0; i < count; i++) {
      this.requestSpawn(pick(roster));
    }
    this.flash = Math.max(this.flash, 0.3);
    this.shake = Math.max(this.shake, 12);
    this.addText(BOARD.x + BOARD.w / 2, BOARD.y + 110, `大波 · ${label}`, "#ff5d6c", 38);
    this.events.onNotice?.(`对局进程 ${label}：一大波早八正在挤进来。`);
    this.events.onToast?.(`${label}大波来了。不是针对你，是针对你的床。`, "#ff5d6c");
    this.audio.wave();
  }

  private requestSpawn(type: ZombieId, row?: number) {
    const at = Math.max(this.time + 0.02, this.spawnGate);
    this.spawnReserve.push({ type, at, row });
    this.spawnReserve.sort((a, b) => a.at - b.at);
    this.spawnGate = at + SPAWN_MIN_INTERVAL;
  }

  private processSpawnReserve() {
    const next = this.spawnReserve[0];
    if (!next || next.at > this.time) return;
    this.spawnReserve.shift();
    this.spawnZombie(next.type, next.row ?? Math.floor(Math.random() * BOARD.rows));
    this.spawnGate = Math.max(this.spawnGate, this.time + SPAWN_MIN_INTERVAL);
  }

  private updateWaves(dt: number) {
    if (!this.waveActive) {
      if (this.wave >= this.totalWaves) return;
      this.prepTimer -= dt;
      if (this.prepTimer <= 0) this.startWave();
      return;
    }
    this.waveElapsed += dt;
    while (this.spawnQueue.length && this.spawnQueue[0].at <= this.waveElapsed) {
      const item = this.spawnQueue.shift()!;
      this.requestSpawn(item.type);
    }
    if (this.waveElapsed > 2 && this.zombies.length === 0 && this.spawnQueue.length === 0 && this.spawnReserve.length === 0) {
      this.finishWave();
    }
  }

  private prepareNextEvent() {
    const nextWave = Math.min(this.wave + 1, this.totalWaves);
    this.pendingEventFor = nextWave;
    const fallback = this.fallbackEvent(nextWave);
    this.preparedEvent = fallback;
    if (!this.agent) return;
    const snapshot = { ...this.snapshot(), wave: nextWave };
    this.agent
      .director({ wave: nextWave, snapshot })
      .then((ev) => {
        if (this.pendingEventFor !== nextWave) return;
        if (this.waveActive) return;
        if (!ev || !ev.title || !ev.line || !MODIFIERS[ev.modifier]) return;
        this.preparedEvent = { ...ev, source: ev.source ?? "llm" };
        this.events.onAgentLine?.(`【预演】${ev.title}：${ev.line}`);
      })
      .catch(() => {
        /* fallback is already armed */
      });
  }

  private fallbackEvent(wave: number): DirectorEvent {
    if (Math.random() < 0.15) {
      return {
        title: `第 ${wave} 波 · 无事发生`,
        line: WAVE_TAUNTS[wave] ?? "奶龙今天没吃药。",
        modifier: "none",
        source: "fallback",
      };
    }
    const mod = pick(MODIFIER_POOL);
    return { ...FALLBACK_EVENTS[mod], source: "fallback" };
  }

  private startWave() {
    if (this.wave >= this.totalWaves) return;
    this.wave++;
    this.stats.waves = this.wave;
    const wave = this.def;
    const event = this.preparedEvent && this.pendingEventFor === this.wave ? this.preparedEvent : this.fallbackEvent(this.wave);
    this.currentEvent = event;
    this.modifiers.clear();
    if (this.levelRule !== "none") {
      this.modifiers.add(this.levelRule);
      this.applyModifier(this.levelRule, wave);
    }
    if (event.modifier !== "none" && event.modifier !== this.levelRule) {
      this.modifiers.add(event.modifier);
      this.applyModifier(event.modifier, wave);
    }
    this.preparedEvent = null;
    this.waveActive = true;
    this.waveElapsed = 0;
    this.spawnQueue = [];
    for (const group of wave.groups) {
      for (let i = 0; i < group.count; i++) {
        this.spawnQueue.push({ type: group.type, at: group.start + 1.5 + i * group.gap * SPAWN_GAP_SCALE });
      }
    }
    this.spawnQueue.sort((a, b) => a.at - b.at);
    this.events.onWave?.(this.wave, event);
    this.audio.wave();
    if (wave.groups.some((grp) => grp.type === "boss" || grp.type === "emperor")) this.audio.bossRoar();
    if (event.line) {
      this.audio.speak(event.line);
      this.events.onAgentLine?.(event.line);
      this.stats.aiLines++;
    }
    this.addText(BOARD.x + BOARD.w / 2, BOARD.y + BOARD.h / 2, `第 ${this.wave} 波`, "#ffe66d", 52);
    this.prepTimer = 0;
  }

  private applyModifier(mod: ModifierId, wave: WaveDef) {
    if (mod === "none") return;
    if (mod === "gold") {
      this.sun += 100;
      this.addText(BOARD.x + BOARD.w / 2, BOARD.y + 70, "+100 横财", "#ffe66d", 32);
    } else if (mod === "heal") {
      for (const p of this.plants) {
        p.hp = Math.min(p.maxHp, p.hp + p.maxHp * 0.35);
        this.addEffect("heal", p.x + BOARD.cw / 2, p.y + BOARD.ch / 2, p.row, 0.7, 50, "rgba(111,242,161,.85)");
      }
    } else if (mod === "blessing") {
      for (const p of this.plants) {
        p.shield = Math.max(p.shield ?? 0, 150);
        this.addEffect("heal", p.x + BOARD.cw / 2, p.y + BOARD.ch / 2, p.row, 0.7, 52, "rgba(255,224,90,.85)");
      }
    } else if (mod === "paper") {
      const base = this.waveElapsed + 2;
      this.spawnQueue.push({ type: "paper", at: base }, { type: "paper", at: base + 5 });
      this.spawnQueue.sort((a, b) => a.at - b.at);
      this.events.onToast?.("论文空袭：额外 2 只论文僵尸", "#fff4d6");
    } else if (mod === "clone") {
      const t: ZombieId = this.wave >= 6 ? "coffee" : "fast";
      this.spawnQueue.push({ type: t, at: 3 }, { type: t, at: 5.5 }, { type: t, at: 8 });
      this.spawnQueue.sort((a, b) => a.at - b.at);
      this.events.onToast?.("平行早八：额外 3 只克隆体", "#a78bfa");
    } else if (mod === "speed") {
      for (const z of this.zombies) {
        z.speed *= 1.2;
        z.baseSpeed *= 1.2;
      }
      this.events.onToast?.("僵尸步频 +20%", "#ff5d6c");
    } else if (mod === "tank") {
      for (const z of this.zombies) {
        z.hp *= 1.25;
        z.maxHp *= 1.25;
      }
      this.events.onToast?.("僵尸血量 +25%", "#f6e8c9");
    }
    void wave;
  }

  private spawnFinalBoss() {
    if (this.finalBossSpawned) return;
    let z = this.zombies.find((item) => !item.dead && item.boss);
    if (!z) {
      z = this.spawnZombie(this.levelIndex >= 14 ? "emperor" : "boss", Math.floor(BOARD.rows / 2));
    }
    const baseHp = z.type === "emperor" ? 7400 : 5000;
    const targetHp = baseHp * (0.3 + this.levelIndex * 0.047);
    z.finalBoss = true;
    z.bossSkill = this.levelIndex % BOSS_SKILLS.length;
    z.x = Math.min(z.x, BOARD.right - 70);
    z.hp = Math.max(z.hp, targetHp * 0.72);
    z.maxHp = Math.max(z.maxHp, targetHp);
    z.hp = Math.min(z.maxHp, z.hp);
    z.armor = Math.max(z.armor, Math.round(targetHp * 0.12));
    z.maxArmor = Math.max(z.maxArmor, z.armor);
    z.abilityTimer = Math.min(z.abilityTimer, 2.5);
    this.finalBossSpawned = true;
    this.finalBossDefeated = false;
    this.bossName = z.type === "emperor" ? "早八皇帝 · 终局" : "终审导师 · 终局";
    this.bossAnnounced = true;
    this.events.onToast?.(`${this.bossName} 进场。这不是演习，这是最后答辩。`, "#ff334f");
    this.events.onNotice?.(`最终 Boss「${this.bossName}」出现。击败它才能结束这一关。`);
    this.addText(BOARD.x + BOARD.w / 2, BOARD.y + 90, "最终 BOSS", "#ff334f", 42);
    this.addEffect("boss", BOARD.right, z.y - 110, z.row, 1.4, 320, "#ff334f");
    this.audio.bossRoar();
    this.flash = Math.max(this.flash, 0.45);
    this.shake = Math.max(this.shake, 24);
  }

  private useFinalBossSkill(z: Zombie) {
    const skill = BOSS_SKILLS[z.bossSkill ?? 0] ?? BOSS_SKILLS[0];
    const index = z.bossSkill ?? 0;
    this.events.onToast?.(`Boss 技能【${skill.name}】：${skill.line}`, "#ff5d6c");
    this.addText(z.x, z.y - 190, skill.name, "#ff5d6c", 28);
    this.audio.bossRoar();
    if (index === 0) {
      for (const p of this.plants) p.stun = Math.max(p.stun, 1.8);
    } else if (index === 1) {
      this.requestSpawn("fast", z.row);
      this.requestSpawn("fast");
    } else if (index === 2) {
      for (const p of [...this.plants].sort(() => Math.random() - 0.5).slice(0, 2)) p.stun = Math.max(p.stun, 2.2);
    } else if (index === 3) {
      z.x = Math.max(BOARD.x + 100, z.x - 90);
    } else if (index === 4) {
      for (const p of this.plants) this.damagePlant(p, p.maxHp * 0.08);
    } else if (index === 5) {
      z.armor += Math.round(z.maxArmor * 0.25);
      z.maxArmor = Math.max(z.maxArmor, z.armor);
    } else if (index === 6) {
      this.visionVisible = false;
      this.events.onNotice?.("宿舍跳闸了，第三只眼暂时离线。");
    } else if (index === 7) {
      for (let i = 0; i < 3; i++) this.requestSpawn("fast");
    } else if (index === 8) {
      for (const other of this.zombies) {
        if (other.dead || other.finalBoss) continue;
        other.baseSpeed *= 1.2;
        other.speed = other.baseSpeed;
      }
    } else if (index === 9) {
      this.requestSpawn("paper");
      this.requestSpawn("basic");
    } else if (index === 10) {
      for (const p of this.plants) p.stun = Math.max(p.stun, 2.2);
    } else if (index === 11) {
      z.hp = Math.min(z.maxHp, z.hp + z.maxHp * 0.15);
      z.armor += Math.round(z.maxArmor * 0.15);
      z.maxArmor = Math.max(z.maxArmor, z.armor);
    } else if (index === 12) {
      for (let i = 0; i < 4; i++) this.requestSpawn("fast");
    } else if (index === 13) {
      this.requestSpawn("coffee");
      this.requestSpawn("coffee");
      z.armor += Math.round(z.maxArmor * 0.2);
      z.maxArmor = Math.max(z.maxArmor, z.armor);
    } else {
      z.hp = Math.min(z.maxHp, z.hp + z.maxHp * 0.25);
      this.requestSpawn("paper");
      this.requestSpawn("fast");
    }
  }

  private finishWave() {
    this.waveActive = false;
    this.modifiers.clear();
    if (this.wave >= this.totalWaves) {
      if (this.time < MIN_LEVEL_SECONDS && this.overtimeWaves < 60) {
        this.addOvertimeWave();
      } else if (!this.finalBossSpawned) {
        this.spawnFinalBoss();
        this.prepTimer = 4;
        return;
      } else if (this.finalBossDefeated) {
        this.win();
        return;
      } else {
        return;
      }
    }
    const bonus = this.mode === "classic" ? 60 + this.wave * 5 : 45 + this.wave * 6;
    this.sun += bonus;
    this.addText(BOARD.x + BOARD.w / 2, BOARD.y + 80, `守住了 +${bonus} 灵感`, "#dfff43", 34);
    this.events.onToast?.(`第 ${this.wave} 波结束，+${bonus} 灵感。奶龙正在编排下一波。`, "#dfff43");
    this.prepTimer = (this.levelWaves[this.levelWaves.length - 1]?.breakAfter ?? this.def.breakAfter) + 2;
    this.prepareNextEvent();
  }

  private addOvertimeWave() {
    const src = this.levelWaves[this.levelWaves.length - 1];
    if (!src) return;
    const groups = src.groups.map((group) => ({
      ...group,
      count: Math.max(1, Math.ceil(group.count * 0.82)),
      start: group.start + 2,
    }));
    this.levelWaves.push({
      ...src,
      index: this.levelWaves.length + 1,
      name: `加时 · ${src.name}`,
      subtitle: "导演说还没到 4 分钟，加时赛继续。",
      groups,
      hpScale: src.hpScale * 1.07,
      breakAfter: 10,
    });
    this.overtimeWaves++;
    this.events.onToast?.("本关还没到 4 分钟。导演临时加赛，继续守住。", "#ffd447");
  }

  private spawnZombie(type: ZombieId, row: number): Zombie {
    const def = ZOMBIES[type];
    const wave = this.def;
    const scale = wave.hpScale;
    const speedBoost = this.modifiers.has("speed") ? 1.2 : 1;
    const hpBoost = this.modifiers.has("tank") ? 1.25 : 1;
    const hp = def.hp * scale * hpBoost * ZOMBIE_HP_SCALE;
    const armor = def.armor * scale * hpBoost * ZOMBIE_ARMOR_SCALE;
    const isBoss = type === "boss" || type === "emperor";
    const z: Zombie = {
      uid: this.uid++,
      type,
      row,
      x: BOARD.right + rand(2, 24),
      y: BOARD.y + row * BOARD.ch + BOARD.ch - 14,
      hp,
      maxHp: hp,
      armor,
      maxArmor: armor,
      speed: def.speed * ZOMBIE_SPEED_SCALE * speedBoost * rand(0.94, 1.06),
      baseSpeed: def.speed * ZOMBIE_SPEED_SCALE * speedBoost,
      dps: def.dps,
      attackTimer: 0,
      eating: false,
      flash: 0,
      slow: 0,
      stun: 0,
      age: 0,
      action: 0,
      dead: false,
      boss: isBoss,
      scale: def.scale,
      abilityTimer: type === "boss" ? 4.5 : type === "emperor" ? 5.5 : type === "weird" ? rand(3, 5) : 0,
      hitStop: 0,
      laughTimer: 0,
      carrying: false,
    };
    this.zombies.push(z);
    if (isBoss && !this.bossAnnounced) {
      this.bossAnnounced = true;
      const bossName = type === "emperor" ? "早八皇帝" : "终审导师";
      this.events.onToast?.(`${bossName}进场。全场的植物都安静了。`, type === "emperor" ? "#ffd447" : "#ff334f");
      this.audio.bossRoar();
      this.shake = 18;
      this.addEffect("boss", BOARD.right, z.y - 100, row, 1.2, 260, type === "emperor" ? "#ffd447" : "#ff334f");
    }
    return z;
  }

  private updatePlants(dt: number) {
    for (const p of this.plants) {
      if (p.dead) continue;
      p.age += dt;
      p.flash = Math.max(0, p.flash - dt * 3);
      p.action = Math.max(0, p.action - dt * 4);
      p.laughing = Math.max(0, (p.laughing ?? 0) - dt);
      p.shootTimer -= dt;
      p.produceTimer -= dt;
      if (p.stun > 0) {
        p.stun -= dt;
        continue;
      }
      if (p.shield && p.shield > 0) {
        // shields are one-hit pools applied to incoming damage
      }
      if (p.type === "flower") {
        if (p.produceTimer <= 0) {
          p.produceTimer = rand(7.6, 8.6);
          const s: SunToken = {
            uid: this.uid++,
            x: p.x + BOARD.cw / 2 + rand(-8, 8),
            y: p.y + BOARD.ch * 0.42,
            targetY: p.y + BOARD.ch * 0.72,
            vy: 60,
            value: 25,
            life: 11,
            age: 0,
            phase: rand(0, 6),
            collected: false,
            fromSky: false,
          };
          this.suns.push(s);
          p.action = 1;
          this.audio.plant();
          this.burst(s.x, s.y, ["#ffe66d", "#fff4d6"], 8, "star");
        }
      } else if (p.type === "doublepea") {
        // Two heads, two microphones, zero enemies targeted.
        const rival = this.plants.find((ally) => ally.type === "pea" && ally.row === p.row && !ally.dead);
        if (!rival) this.duelRows.delete(p.row);
        const allies = rival
          ? [rival]
          : this.plants.filter((ally) => !ally.dead && ally.row === p.row && ally.uid !== p.uid);
        if (allies.length && p.shootTimer <= 0) {
          p.shootTimer = 1.8;
          p.action = 1;
          const sorted = allies.sort((a, b) => Math.abs(a.x - p.x) - Math.abs(b.x - p.x));
          const targets = sorted.length === 1 ? [sorted[0], sorted[0]] : sorted.slice(0, 2);
          for (let i = 0; i < targets.length; i++) {
            const target = targets[i];
            const proj: Projectile = {
              uid: this.uid++,
              kind: "speech",
              x: p.x + BOARD.cw * (i === 0 ? 0.34 : 0.66),
              y: p.y + BOARD.ch * (i === 0 ? 0.4 : 0.55),
              row: p.row,
              vx: 0,
              vy: 0,
              damage: 10,
              slow: 0,
              life: 2.4,
              dead: false,
              spin: 0,
              text: pick(["你", "？", "急", "双"]),
              friendly: true,
              targetPlantUid: target.uid,
            };
            this.projectiles.push(proj);
            this.burst(proj.x, proj.y, ["#ffd7e2", "#ff3d8d"], 3, "dot");
          }
          this.audio.shoot();
        }
      } else if (p.type === "pea") {
        const rival = this.plants.find((ally) => ally.type === "doublepea" && ally.row === p.row && !ally.dead);
        if (rival) {
          if (!this.duelRows.has(p.row)) {
            this.duelRows.add(p.row);
            this.events.onToast?.("单发嘴替和双发嘴替在同一条路上，先解决对方再说。", "#ff5d6c");
            this.addText(p.x + BOARD.cw / 2, p.y + 24, "先解决你", "#ff5d6c", 22);
          }
          if (p.shootTimer <= 0) {
            p.shootTimer = 1.45;
            p.action = 1;
            const proj: Projectile = {
              uid: this.uid++,
              kind: "speech",
              x: p.x + BOARD.cw * 0.5,
              y: p.y + BOARD.ch * 0.48,
              row: p.row,
              vx: 0,
              vy: 0,
              damage: 15,
              slow: 0,
              life: 2.4,
              dead: false,
              spin: 0,
              text: pick(["你", "？", "急"]),
              friendly: true,
              targetPlantUid: rival.uid,
            };
            this.projectiles.push(proj);
            this.audio.shoot();
            this.burst(proj.x, proj.y, ["#ffd7e2", "#ff5d6c"], 3, "dot");
          }
        } else {
          this.duelRows.delete(p.row);
          const target = this.zombies
            .filter((z) => !z.dead && z.row === p.row && z.x > p.x + 24 && z.x < BOARD.right + 200)
            .sort((a, b) => a.x - b.x)[0];
          if (target && p.shootTimer <= 0) {
            p.shootTimer = 1.45;
            p.action = 1;
            const proj: Projectile = {
              uid: this.uid++,
              kind: "speech",
              x: p.x + BOARD.cw * 0.74,
              y: p.y + BOARD.ch * 0.48,
              row: p.row,
              vx: 530,
              vy: 0,
              damage: 24,
              slow: 0,
              life: 4,
              dead: false,
              spin: 0,
              text: pick(["典", "6", "急", "？", "啊", "乐", "绷"]),
            };
            this.projectiles.push(proj);
            this.audio.shoot();
            this.burst(proj.x, proj.y, ["#fff4d6", "#ff3d8d"], 4, "dot");
          }
        }
      } else if (p.type === "frost") {
        const target = this.zombies.some((z) => !z.dead && z.row === p.row && z.x > p.x + 24 && z.x < BOARD.right + 200);
        if (target && p.shootTimer <= 0) {
          p.shootTimer = 2.15;
          p.action = 1;
          const proj: Projectile = {
            uid: this.uid++,
            kind: "ice",
            x: p.x + BOARD.cw * 0.74,
            y: p.y + BOARD.ch * 0.48,
            row: p.row,
            vx: 470,
            vy: 0,
            damage: 17,
            slow: 2.8,
            life: 4,
            dead: false,
            spin: 0,
          };
          this.projectiles.push(proj);
          this.audio.ice();
          this.burst(proj.x, proj.y, ["#bff8ff", "#69e7ff"], 4, "dot");
        }
      } else if (p.type === "fan") {
        if (p.shootTimer <= 0) {
          p.shootTimer = 5.4;
          p.action = 1;
          this.addEffect("wind", BOARD.x + BOARD.w / 2, p.y + BOARD.ch / 2, p.row, 0.7, BOARD.w / 2, "#bff8e5");
          for (const z of this.zombies) {
            if (z.row !== p.row || z.dead) continue;
            this.damageZombie(z, 34, 0, false);
            z.x += 16;
            this.addText(z.x, z.y - 100, "吹飞", "#bff8e5", 18);
          }
          this.audio.slipper();
        }
      } else if (p.type === "bomb") {
        p.fuse = (p.fuse ?? 1.2) - dt;
        if ((p.fuse ?? 0) <= 0) this.explodeBomb(p);
      } else if (p.type === "cannon") {
        const targets = this.zombies
          .filter((z) => !z.dead && z.row === p.row && z.x > p.x + 24 && z.x < BOARD.right + 220)
          .sort((a, b) => b.x - a.x);
        const target = targets[0];
        if (target && p.shootTimer <= 0) {
          p.shootTimer = 3.3;
          p.action = 1;
          this.projectiles.push({
            uid: this.uid++,
            kind: "boba",
            x: p.x + BOARD.cw * 0.66,
            y: p.y + BOARD.ch * 0.26,
            row: p.row,
            vx: 0,
            vy: -255,
            gravity: 500,
            groundY: p.y + BOARD.ch * 0.62,
            targetZombieUid: target.uid,
            damage: 110,
            slow: 0,
            life: 2.5,
            dead: false,
            spin: 0,
          });
          this.addText(target.x, target.y - 124, "大炮锁定最远", "#ffb347", 16);
          this.audio.shoot();
        }
      } else if (p.type === "vacuum") {
        const targets = this.zombies.filter((z) => !z.dead && z.row === p.row && z.x > p.x);
        if (targets.length && p.shootTimer <= 0) {
          p.shootTimer = 5.6;
          p.action = 1;
          this.addEffect("suck", p.x + BOARD.cw / 2, p.y + BOARD.ch / 2, p.row, 0.55, 80, "#c9a3ff");
          for (const z of targets) {
            this.damageZombie(z, 16, 1.2, false);
            z.x = Math.min(BOARD.right + 100, z.x + 34);
            this.addText(z.x, z.y - 98, "吸回去", "#c9a3ff", 17);
          }
          this.audio.slipper();
        }
      } else if (p.type === "boomerang") {
        const target = this.zombies.some((z) => !z.dead && z.row === p.row && z.x > p.x + 20 && z.x < BOARD.right + 220);
        if (target && p.shootTimer <= 0) {
          p.shootTimer = 3.6;
          p.action = 1;
          this.projectiles.push({
            uid: this.uid++,
            kind: "boomerang",
            x: p.x + BOARD.cw * 0.7,
            y: p.y + BOARD.ch * 0.48,
            row: p.row,
            vx: 470,
            vy: 0,
            originX: p.x + BOARD.cw * 0.7,
            returning: false,
            hitIds: [],
            damage: 34,
            slow: 0,
            life: 4,
            dead: false,
            spin: 0,
          });
          this.audio.shoot();
        }
      } else if (p.type === "seal") {
        if (p.shootTimer <= 0) {
          p.shootTimer = 7;
          const cx = p.x + BOARD.cw / 2;
          const cy = p.y + BOARD.ch / 2;
          let hitCount = 0;
          this.addEffect("seal", cx, cy, p.row, 0.7, 152, "#7ff0c0");
          this.audio.bossRoar();
          this.shake = Math.max(this.shake, 8);
          for (const z of this.zombies) {
            if (z.dead) continue;
            if (Math.abs(z.x - cx) < 156 && Math.abs(z.row - p.row) <= 1) {
              this.damageZombie(z, 105, 0, true);
              z.stun = Math.max(z.stun, 0.85);
              hitCount++;
            }
          }
          this.addText(cx, cy - 60, hitCount ? "盖章！" : "空印", "#9ff2c6", 28);
        }
      }
    }
  }

  private explodeBomb(p: Plant) {
    if (p.dead) return;
    p.dead = true;
    this.stats.bombs++;
    const cx = p.x + BOARD.cw / 2;
    const cy = p.y + BOARD.ch / 2;
    this.addEffect("explosion", cx, cy, p.row, 0.75, 240, "#ff5d6c");
    this.shake = 22;
    this.flash = 0.55;
    this.audio.explosion();
    this.burst(cx, cy, ["#ff5d6c", "#ffe66d", "#fff4d6", "#1c102c"], 58, "square", 420);
    for (const z of this.zombies) {
      if (z.dead) continue;
      const dx = z.x - cx;
      const dy = z.y - cy;
      if (Math.abs(dx) < BOARD.cw * 1.8 && Math.abs(dy) < BOARD.ch * 1.8) {
        this.damageZombie(z, 1400, 0, true);
      }
    }
    this.addText(cx, cy - 40, "全宿舍都醒了", "#fff4d6", 30);
  }

  private updateZombies(dt: number) {
    for (const z of this.zombies) {
      if (z.dead) continue;
      z.age += dt;
      z.flash = Math.max(0, z.flash - dt * 4);
      z.hitStop = Math.max(0, z.hitStop - dt);
      z.slow = Math.max(0, z.slow - dt);
      z.stun = Math.max(0, z.stun - dt);
      z.abilityTimer -= dt;
      if (z.type === "coffee" && z.hp < z.maxHp * 0.45) z.speed = z.baseSpeed * 1.65;
      else z.speed = z.baseSpeed;

      // The sunflower truce: laugh first, then carry her off to the right.
      if (z.laughTimer > 0) {
        z.laughTimer -= dt;
        z.eating = false;
        if (z.laughTimer <= 0) this.finishCarry(z);
        continue;
      }
      if (z.carrying) {
        z.eating = false;
        z.x += z.speed * 1.12 * dt;
        if (z.x > BOARD.right + 220) z.dead = true;
        continue;
      }

      if (z.stun > 0) continue;

      if (z.type === "ranged") {
        const target = this.plants
          .filter((p) => !p.dead && p.row === z.row && p.x < z.x)
          .sort((a, b) => b.x - a.x)[0];
        const gap = target ? z.x - (target.x + BOARD.cw * 0.5) : Infinity;
        if (target && gap < BOARD.cw * 4.5) {
          z.eating = false;
          z.attackTimer -= dt;
          if (z.attackTimer <= 0) {
            z.attackTimer = 2.8;
            this.rangedThrow(z);
          }
          continue;
        }
      }

      if (z.type === "weird" && z.abilityTimer <= 0) {
        z.abilityTimer = rand(4.5, 6.5);
        const roll = Math.random();
        if (roll < 0.34) {
          z.x = Math.min(BOARD.right + 160, z.x + rand(35, 85));
          this.addText(z.x, z.y - 120, "抽象位移", "#c9a3ff", 20);
        } else if (roll < 0.67) {
          z.baseSpeed *= 1.15;
          z.speed = z.baseSpeed;
          this.addText(z.x, z.y - 120, "突然很快", "#c9a3ff", 20);
        } else {
          z.armor += 35;
          z.maxArmor = Math.max(z.maxArmor, z.armor);
          this.addText(z.x, z.y - 120, "看不懂的甲", "#c9a3ff", 20);
        }
      }

      const plant = this.findBlockingPlant(z);
      if (plant) {
        if (this.tryLaughCarry(z, plant)) continue;
        z.eating = true;
        z.attackTimer -= dt;
        if (z.attackTimer <= 0) {
          z.attackTimer = 0.42;
          this.damagePlant(plant, z.dps * 0.42);
          if (plant.type === "wall") {
            const heal = Math.max(8, Math.round(z.maxHp * 0.012));
            const before = z.hp;
            z.hp = Math.min(z.maxHp, z.hp + heal);
            if (!z.wallFed) {
              z.wallFed = true;
              z.baseSpeed *= 0.9;
              z.speed = z.baseSpeed;
              this.addText(z.x, z.y - 112, "这墙有营养，走慢点", "#9ff2c6", 15);
            }
            if (z.hp > before) this.addText(z.x + 10, z.y - 88, `+${Math.round(z.hp - before)}`, "#6ff2a1", 15);
            this.burst(plant.x + BOARD.cw / 2, plant.y + 48, ["#9ff2c6", "#fff4d6"], 4, "star");
          }
          this.burst(plant.x + BOARD.cw / 2 + 10, plant.y + 54, ["#8a6b4a", "#fff4d6"], 3, "square");
          if (Math.random() < 0.25) this.addText(z.x, z.y - 100, pick(["啃", "嚼", "啊", "别"]), "#ffb3c4", 15);
        }
      } else {
        z.eating = false;
        const mult = z.slow > 0 ? 0.5 : 1;
        z.x -= z.speed * mult * dt;
      }

      if (z.boss && z.abilityTimer <= 0 && z.x < BOARD.right + 20) {
        z.abilityTimer = rand(7, 9);
        if (z.finalBoss) this.useFinalBossSkill(z);
        else this.bossThrow(z);
      }

      if (z.x < BOARD.x + 30 && this.slippers[z.row]) {
        this.launchSlipper(z.row);
      }

      if (z.x < BOARD.x - 30) {
        z.eating = false;
        z.x -= z.speed * dt * 0.35;
        this.houseHp -= (z.dps * 0.16) * dt;
        if (this.time - this.lastHouseHit > 0.5) {
          this.lastHouseHit = this.time;
          this.shake = Math.max(this.shake, 8);
          this.flash = Math.max(this.flash, 0.2);
          this.audio.hit();
          this.addText(HOUSE.x + HOUSE.w / 2, BOARD.y + z.row * BOARD.ch + 30, "睡眠舱受损", "#ff334f", 20);
          this.burst(HOUSE.x + HOUSE.w - 10, z.y - 50, ["#ff5d6c", "#fff4d6"], 7, "square");
        }
        if (this.houseHp <= 0) {
          this.houseHp = 0;
          this.lose();
          return;
        }
      }
    }
  }

  private findBlockingPlant(z: Zombie): Plant | null {
    let best: Plant | null = null;
    for (const p of this.plants) {
      if (p.dead || p.row !== z.row) continue;
      const stop = p.x + BOARD.cw * 0.66;
      if (z.x >= stop - 4 && z.x <= stop + BOARD.cw * 0.62) {
        if (!best || p.x > best.x) best = p;
      }
    }
    return best;
  }

  private tryLaughCarry(z: Zombie, p: Plant): boolean {
    if (z.boss || z.carrying || z.laughTimer > 0) return false;
    if (p.type !== "flower" || p.dead) return false;

    z.laughTimer = 2.35;
    z.carryPlantUid = p.uid;
    z.carryType = p.type;
    z.eating = false;
    z.attackTimer = 0;
    z.x = Math.max(z.x, p.x + BOARD.cw * 0.96);
    p.laughing = 2.5;
    this.audio.sun();
    this.shake = Math.max(this.shake, 5);
    if (!this.carryNoticeShown) {
      this.carryNoticeShown = true;
      this.events.onNotice?.("奶龙花笑到僵尸放下了刀。它决定不啃了，改把她抱回家。");
    }
    return true;
  }

  private finishCarry(z: Zombie) {
    z.laughTimer = 0;
    const p = this.plants.find((plant) => plant.uid === z.carryPlantUid && !plant.dead);
    z.carryPlantUid = undefined;
    if (!p) {
      z.carrying = false;
      z.carryType = undefined;
      return;
    }
    p.dead = true;
    p.hp = 0;
    p.laughing = 0;
    z.carrying = true;
    z.carryType = p.type;
    z.x = Math.max(z.x, p.x + BOARD.cw * 0.82);
    this.stats.carries = (this.stats.carries ?? 0) + 1;
    this.addText(p.x + BOARD.cw / 2, p.y + 18, "她笑得掉了一地灵感", "#ffd447", 17);
    this.suns.push({
      uid: this.uid++,
      x: p.x + BOARD.cw / 2,
      y: p.y + BOARD.ch * 0.42,
      targetY: p.y + BOARD.ch * 0.72,
      vy: 80,
      value: 50,
      life: 12,
      age: 0,
      phase: rand(0, 6),
      collected: false,
      fromSky: false,
    });
    this.burst(p.x + BOARD.cw / 2, p.y + BOARD.ch * 0.5, ["#ffd447", "#ff8fb0", "#fff4d6"], 20, "star");
    this.audio.sun();
    this.shake = Math.max(this.shake, 8);
  }

  private damagePlant(p: Plant, dmg: number) {
    if (p.dead) return;
    if ((p.laughing ?? 0) > 0) return;
    p.flash = 1;
    if (p.shield && p.shield > 0) {
      const absorbed = Math.min(p.shield, dmg);
      p.shield -= absorbed;
      dmg -= absorbed;
      if (p.shield <= 0) p.shield = 0;
    }
    p.hp -= dmg;
    if (p.hp <= 0) {
      p.dead = true;
      this.burst(p.x + BOARD.cw / 2, p.y + BOARD.ch / 2, [PLANTS[p.type].color, "#1c102c"], 20, "leaf");
      this.audio.zombieDie();
      this.addText(p.x + BOARD.cw / 2, p.y + 40, "植物阵亡", "#ff7f9d", 20);
    }
  }

  private rangedThrow(z: Zombie) {
    this.projectiles.push({
      uid: this.uid++,
      kind: "ddl",
      x: z.x - 42,
      y: z.y - 138,
      row: z.row,
      vx: -310,
      vy: 25,
      damage: 45,
      slow: 0,
      life: 4,
      dead: false,
      spin: 0,
    });
    this.addText(z.x - 10, z.y - 162, "投作业", "#ffb347", 18);
  }

  private bossThrow(z: Zombie) {
    const targets = this.plants.filter((p) => !p.dead && p.row === z.row && p.x < z.x);
    const target = targets.sort((a, b) => b.x - a.x)[0];
    if (!target) return;
    this.projectiles.push({
      uid: this.uid++,
      kind: z.type === "emperor" ? "seal" : "ddl",
      x: z.x - 50,
      y: z.y - 150,
      row: z.row,
      vx: -320,
      vy: 50,
      damage: z.type === "emperor" ? 180 : 130,
      slow: 0,
      life: 4,
      dead: false,
      spin: 0,
    });
    this.events.onAgentLine?.(
      z.type === "emperor"
        ? pick(["朕即早八。", "受命于天，既寿永昌。", "玉玺在此，论文退散。", "众卿平身，继续睡。"])
        : pick(["这一版还是不行。", "工作量不饱和。", "下周一把终稿发我。", "格式不对，重排。"]),
    );
    this.audio.bossRoar();
    this.addText(z.x - 20, z.y - 180, z.type === "emperor" ? "玉玺投掷" : "DDL 投掷", "#ffcf4a", 26);
    if (z.type === "emperor") {
      this.spawnZombie("paper", Math.floor(Math.random() * BOARD.rows));
      this.events.onToast?.("早八皇帝传了一道口谕：再上一版论文。", "#ffd447");
    }
  }

  private updateProjectiles(dt: number) {
    for (const p of this.projectiles) {
      if (p.dead) continue;
      p.x += p.vx * dt;
      p.y += (p.vy + (p.gravity ?? 0) * dt) * dt;
      p.life -= dt;
      if (p.life <= 0 || p.x < -100 || p.x > BOARD.right + 260) {
        p.dead = true;
        continue;
      }
      if (p.friendly) {
        const target = this.plants.find((plant) => plant.uid === p.targetPlantUid && !plant.dead);
        if (!target) {
          p.dead = true;
          continue;
        }
        const tx = target.x + BOARD.cw * 0.5;
        const dx = tx - p.x;
        p.x += Math.sign(dx) * Math.min(Math.abs(dx), 430 * dt);
        if (Math.abs(dx) < 24) {
          p.dead = true;
          this.damagePlant(target, p.damage);
          this.addText(target.x + BOARD.cw * 0.5, target.y + 18, `被嘴替了 -${p.damage}`, "#ff8fb0", 14);
          this.burst(target.x + BOARD.cw * 0.5, target.y + 44, ["#ffd7e2", "#ff3d8d"], 4, "dot");
          this.audio.hit();
        }
        continue;
      }
      if (p.kind === "boba") {
        p.spin += dt * 7;
        if (p.targetZombieUid !== undefined) {
          const target = this.zombies.find((z) => z.uid === p.targetZombieUid && !z.dead);
          if (!target) {
            p.dead = true;
            continue;
          }
          const dx = target.x - p.x;
          p.x += Math.sign(dx) * Math.min(Math.abs(dx), 620 * dt);
          p.vy += (p.gravity ?? 0) * dt;
          p.y += p.vy * dt;
          if (Math.abs(target.x - p.x) < 28) {
            p.x = target.x;
            p.y = target.y - 42;
            p.dead = true;
            this.explodeBoba(p);
          }
          continue;
        }
        if (p.vy > 0 && p.groundY !== undefined && p.y >= p.groundY) {
          p.dead = true;
          this.explodeBoba(p);
        }
        continue;
      }
      if (p.kind === "boomerang") {
        p.spin += dt * 15;
        if (!p.returning && p.originX !== undefined && p.x > p.originX + 355) {
          p.returning = true;
          p.vx = -Math.abs(p.vx);
          p.hitIds = [];
        }
        if (p.returning && p.originX !== undefined && p.x < p.originX - 6) {
          p.dead = true;
          continue;
        }
        for (const z of this.zombies) {
          if (z.dead || z.row !== p.row) continue;
          if (p.hitIds?.includes(z.uid)) continue;
          if (Math.abs(z.x - p.x) < 38 + (z.boss ? 26 : 0)) {
            p.hitIds?.push(z.uid);
            this.damageZombie(z, p.damage, 0, false);
            this.burst(z.x, z.y - 60, ["#bff8ff", "#fff4d6", "#e6b86b"], 6, "star");
          }
        }
        continue;
      }
      if (p.kind === "speech" || p.kind === "ice") {
        let hit: Zombie | null = null;
        for (const z of this.zombies) {
          if (z.dead || z.row !== p.row) continue;
          if (Math.abs(z.x - p.x) < 34 + (z.boss ? 34 : 0) && p.x < z.x + 40) {
            hit = z;
            break;
          }
        }
        if (hit) {
          p.dead = true;
          this.damageZombie(hit, p.damage, p.slow, false);
          this.burst(p.x, p.y, p.kind === "ice" ? ["#bff8ff", "#69e7ff"] : ["#fff4d6", "#ff3d8d"], 7, "dot");
          if (p.kind === "ice") this.addEffect("freeze", hit.x, hit.y - 40, hit.row, 0.45, 50, "#bff8ff");
        }
      } else if (p.kind === "ddl" || p.kind === "seal") {
        const hit = this.plants.find((pl) => !pl.dead && pl.row === p.row && Math.abs(pl.x + BOARD.cw / 2 - p.x) < 44);
        if (hit) {
          p.dead = true;
          this.damagePlant(hit, p.damage);
          hit.stun = p.kind === "seal" ? 2.5 : 1.8;
          this.addEffect(p.kind === "seal" ? "seal" : "explosion", p.x, p.y, p.row, 0.5, p.kind === "seal" ? 110 : 54, "#ffcf4a");
          this.burst(p.x, p.y, ["#fff2c9", "#ff3d8d"], 10, "paper");
          if (p.kind === "seal") this.addText(p.x, p.y - 20, "玉玺盖章", "#9ff2c6", 24);
        }
      } else if (p.kind === "slipper") {
        p.spin += dt * 13;
        for (const z of this.zombies) {
          if (z.dead || z.row !== p.row) continue;
          if (Math.abs(z.x - p.x) < 95) this.damageZombie(z, 9999, 0, true);
        }
      }
    }
  }

  private launchSlipper(row: number) {
    if (!this.slippers[row]) return;
    this.slippers[row] = false;
    this.projectiles.push({
      uid: this.uid++,
      kind: "slipper",
      x: BOARD.x - 34,
      y: BOARD.y + row * BOARD.ch + BOARD.ch * 0.72,
      row,
      vx: 1450,
      vy: 0,
      damage: 9999,
      slow: 0,
      life: 1.1,
      dead: false,
      spin: -0.2,
    });
    this.addEffect("slipper", BOARD.x + BOARD.w / 2, BOARD.y + row * BOARD.ch + BOARD.ch / 2, row, 0.65, 90, "#ffd447");
    this.events.onToast?.(`Lane ${row + 1} 触发宿管空投：拖鞋已出库。`, "#ffd447");
    this.addText(BOARD.x + 90, BOARD.y + row * BOARD.ch + 40, "宿管阿姨！", "#ffd447", 26);
    this.audio.slipper();
    this.shake = 10;
  }

  private damageZombie(z: Zombie, dmg: number, slow: number, heavy: boolean) {
    if (z.dead) return;
    if (slow) z.slow = Math.max(z.slow, slow);
    z.flash = 1;
    z.hitStop = heavy ? 0.08 : 0.03;
    if (z.armor > 0) {
      const absorbed = Math.min(z.armor, dmg);
      z.armor -= absorbed;
      dmg -= absorbed;
      if (heavy) this.burst(z.x, z.y - 80, ["#fff2c9", "#f6e8c9"], 5, "paper");
    }
    if (dmg <= 0) return;
    z.hp -= dmg;
    if (z.hp <= 0) {
      z.dead = true;
      this.stats.kills++;
      if (z.finalBoss) {
        this.finalBossDefeated = true;
        this.events.onNotice?.("最终 Boss 倒下了。这一关的床保住了。");
      }
      this.audio.zombieDie();
      this.burst(z.x, z.y - 60, z.type === "paper" ? ["#fff2c9", "#f6e8c9", "#1c102c"] : ["#aec18c", "#1c102c", "#ff3d8d"], z.boss ? 60 : 20, z.type === "paper" ? "paper" : "dot", z.boss ? 320 : 160);
      this.addText(z.x, z.y - 100, z.boss ? (z.type === "emperor" ? "皇帝退位" : "导师陨落") : `+${ZOMBIES[z.type].reward}`, z.boss ? "#ffd447" : "#dfff43", z.boss ? 34 : 22);
      this.shake = Math.max(this.shake, z.boss ? 26 : 3);
      if (z.boss) {
        this.addEffect("explosion", z.x, z.y - 80, z.row, 1.2, 300, "#ff5d6c");
        this.events.onNotice?.(z.type === "emperor" ? "早八皇帝退位了。玉玺暂时归你。" : "终审导师被植物说服了。暂时。");
      }
      if (!z.boss && Math.random() < 0.28) {
        this.suns.push({
          uid: this.uid++,
          x: z.x,
          y: z.y - 70,
          targetY: z.y - 30,
          vy: 80,
          value: 10,
          life: 8,
          age: 0,
          phase: rand(0, 6),
          collected: false,
          fromSky: false,
        });
      }
    }
  }

  private explodeBoba(p: Projectile) {
    this.addEffect("explosion", p.x, p.y, p.row, 0.55, 92, "#ffb347");
    this.burst(p.x, p.y, ["#ffb347", "#fff4d6", "#7f233f"], 24, "square", 260);
    this.audio.explosion();
    for (const z of this.zombies) {
      if (z.dead) continue;
      if (Math.abs(z.x - p.x) < 108 && Math.abs(z.row - p.row) <= 1) {
        this.damageZombie(z, p.damage, 0, false);
      }
    }
    this.shake = Math.max(this.shake, 5);
  }

  private updateSuns(dt: number) {
    for (const s of this.suns) {
      s.age += dt;
      if (s.y < s.targetY) s.y = Math.min(s.targetY, s.y + 160 * dt);
      else s.life -= dt;
      if (s.y > BOARD.y + 20) s.life = Math.min(s.life, 11);
    }
  }

  private spawnSkySun(initial = false) {
    if (this.suns.length > 9) return;
    const x = rand(BOARD.x + 50, BOARD.right - 50);
    const targetY = rand(BOARD.y + 40, BOARD.bottom - 30);
    this.suns.push({
      uid: this.uid++,
      x,
      y: initial ? -40 : -30,
      targetY,
      vy: 120,
      value: 25,
      life: 12,
      age: 0,
      phase: rand(0, 6),
      collected: false,
      fromSky: true,
    });
  }

  private updateLaneDanger(dt: number) {
    for (let row = 0; row < BOARD.rows; row++) {
      const close = this.zombies.some((z) => !z.dead && z.row === row && z.x < BOARD.x + 210);
      const target = close ? 1 : 0;
      this.laneDanger[row] += (target - this.laneDanger[row]) * Math.min(1, dt * 4.2);
      this.laneDanger[row] = clamp(this.laneDanger[row], 0, 1);
    }
  }

  private updateParticles(dt: number) {
    for (const p of this.particles) {
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.vy += p.gravity * dt;
      p.vx *= 0.985;
      p.rot += p.vr * dt;
      p.life -= dt;
    }
    for (const f of this.texts) {
      f.y += f.vy * dt;
      f.life -= dt;
    }
  }

  private updateEffects(dt: number) {
    for (const e of this.effects) e.life -= dt;
  }

  private addEffect(kind: VisualEffect["kind"], x: number, y: number, row: number, life: number, radius: number, color: string) {
    this.effects.push({ kind, x, y, row, life, maxLife: life, radius, color });
  }

  private burst(x: number, y: number, colors: string[], count: number, kind: Particle["kind"] = "dot", speed = 180) {
    for (let i = 0; i < count; i++) {
      const a = rand(0, Math.PI * 2);
      const v = rand(speed * 0.2, speed);
      this.particles.push({
        x,
        y,
        vx: Math.cos(a) * v,
        vy: Math.sin(a) * v - 40,
        gravity: 260,
        life: rand(0.35, 0.9),
        maxLife: 0.9,
        size: rand(2, 6),
        color: pick(colors),
        kind,
        rot: rand(0, 6),
        vr: rand(-8, 8),
        alpha: 1,
      });
    }
  }

  private addText(x: number, y: number, text: string, color: string, size: number) {
    this.texts.push({ x, y, text, color, life: 1.25, maxLife: 1.25, size, vy: -42, rot: rand(-0.07, 0.07) });
  }

  realityBonus(label: string) {
    this.sun += 15;
    this.stats.sunCollected += 15;
    this.addText(BOARD.x + BOARD.w / 2, BOARD.y + 120, `现实偷渡 +15 · ${label}`, "#69e7ff", 26);
    this.events.onToast?.(`第三只眼从现实里认出了「${label}」，顺手偷了 15 灵感。`, "#69e7ff");
    this.audio.yolo();
  }

  grantSun(amount: number) {
    this.sun += amount;
  }

  setVisionReport(report: VisionReport, offsetX = 0, offsetY = 0) {
    if (offsetX || offsetY) {
      for (const d of report.detections) {
        d.x += offsetX;
        d.y += offsetY;
      }
    }
    this.visionReport = report;
    this.visionLastAt = this.time;
    this.stats.yoloScans++;
    const counts = report.counts ?? {};
    const zc = (counts.zombie ?? 0) + (counts.boss ?? 0) * 2;
    const pc = counts.plant ?? 0;
    const add = 4 + zc * 2.4 + Math.min(8, pc * 0.8);
    this.visionSync = Math.min(100, this.visionSync + add);
    this.events.onVision?.(report, this.visionSync);
    if (this.visionSync >= 100) {
      this.visionSync = 0;
      this.triggerVisionOverload(zc);
    } else if (Math.random() < 0.14) {
      this.triggerVisionMisread(counts);
    }
  }

  private visionCards(): VisionCard[] {
    return [
      { id: "stare", name: "导师凝视", line: "YOLO 把全场僵尸认定为“需要延毕的学生”，全体僵直 2.4 秒。", tone: "good" },
      { id: "crowd", name: "人群恐惧", line: "YOLO 数出了太多早八人，僵尸被自己的数量吓退 120 像素。", tone: "good" },
      { id: "pot", name: "万物皆盆栽", line: "YOLO 坚持所有植物都是盆栽，植物回血 35% 并获得护盾。", tone: "good" },
      { id: "ufo", name: "太阳能诈骗", line: "YOLO 把一颗灵感识别成 UFO，强行征收 110 灵感。", tone: "good" },
      { id: "paper", name: "论文暴雨", line: "YOLO 把画面噪声全认成论文，所有僵尸受到 160 伤害。", tone: "good" },
      { id: "rewind", name: "时间倒流", line: "YOLO 说“刚才那帧不算”，全场僵尸后退 110 像素。", tone: "good" },
      { id: "wall", name: "第四面墙", line: "YOLO 看见了屏幕外的你，植物获得 80 护盾。", tone: "good" },
      { id: "void", name: "虚无主义", line: "YOLO 宣布战场不存在，僵尸全体减速 3 秒。", tone: "good" },
      { id: "tax", name: "灵感税", line: "YOLO 把灵感识别为“未申报收入”，征收 150 灵感。", tone: "bad" },
      { id: "drain", name: "低血糖", line: "YOLO 把植物识别成低血糖患者，所有植物失去 12% 生命。", tone: "bad" },
      { id: "party", name: "怪物派对", line: "YOLO 把噪点认成新同学，场上多出 5–7 只早八人。", tone: "bad" },
      { id: "haste", name: "全速前进", line: "YOLO 误开了 2 倍速，所有僵尸移速 +50%。", tone: "bad" },
      { id: "reunion", name: "导师加课", line: "YOLO 看见一个熟悉的秃头，终审导师提前进场。", tone: "bad" },
      { id: "doom", name: "全盘皆输", line: "YOLO 认为这片苗圃不存在，所有植物清空、卡组冷却 15 秒。求妈妈是唯一解。", tone: "catastrophe" },
    ];
  }

  private pickVisionCard(): VisionCard {
    const cards = this.visionCards();
    const roll = Math.random();
    if (roll < 0.07) return cards.find((c) => c.tone === "catastrophe") ?? cards[cards.length - 1];
    if (roll < 0.4) {
      const bad = cards.filter((c) => c.tone === "bad");
      return pick(bad);
    }
    const good = cards.filter((c) => c.tone === "good");
    return pick(good);
  }

  drawVisionInterpretation(): boolean {
    if (this.screen !== "playing" || !this.visionVisible) {
      this.events.onToast?.("先把第三只眼打开，再谈抽象。", "#8b7f9b");
      this.audio.deny();
      return false;
    }
    if (this.visionSync < 25) {
      this.events.onToast?.("同步率不足 25%，YOLO 现在只会看见一片虚无。", "#ff7f9d");
      this.audio.deny();
      return false;
    }
    this.visionSync -= 25;
    const card = this.pickVisionCard();
    this.applyVisionCard(card, false);
    const toneColor = card.tone === "good" ? "#69e7ff" : card.tone === "bad" ? "#ff7f9d" : "#ff334f";
    this.events.onToast?.(`抽象解读【${card.name}】：同步率 -25%。`, toneColor);
    return true;
  }

  private applyVisionCard(card: VisionCard, overdrive: boolean) {
    const power = overdrive ? 1.6 : 1;
    const toneColor = card.tone === "good" ? "#69e7ff" : card.tone === "bad" ? "#ff8fb0" : "#ff334f";
    if (card.id === "stare") {
      for (const z of this.zombies) if (!z.dead) z.stun = Math.max(z.stun, 2.4 * power);
      this.addText(BOARD.x + BOARD.w / 2, BOARD.y + 120, "全体延毕", toneColor, 30);
    } else if (card.id === "crowd" || card.id === "rewind") {
      const push = Math.round(110 * power);
      for (const z of this.zombies) {
        if (z.dead) continue;
        z.x = Math.min(BOARD.right + 140, z.x + push);
        z.stun = Math.max(z.stun, 0.8 * power);
      }
      this.addText(BOARD.x + BOARD.w / 2, BOARD.y + 120, "退！退！退！", toneColor, 30);
    } else if (card.id === "pot") {
      for (const p of this.plants) {
        p.hp = Math.min(p.maxHp, p.hp + p.maxHp * 0.35);
        p.shield = Math.max(p.shield ?? 0, Math.round(60 * power));
      }
      this.addText(BOARD.x + BOARD.w / 2, BOARD.y + 120, "你们都是盆栽", toneColor, 28);
    } else if (card.id === "ufo") {
      const amount = Math.round(110 * power);
      this.sun += amount;
      this.addText(BOARD.x + BOARD.w / 2, BOARD.y + 120, `UFO 税 +${amount}`, toneColor, 28);
    } else if (card.id === "paper") {
      for (const z of [...this.zombies]) {
        if (!z.dead) this.damageZombie(z, 160 * power, 0, true);
      }
      this.addText(BOARD.x + BOARD.w / 2, BOARD.y + 120, "论文暴雨", toneColor, 28);
      this.burst(BOARD.x + BOARD.w / 2, BOARD.y + BOARD.h / 2, ["#fff2c9", "#f6e8c9", "#ff8fb0"], 18, "paper");
    } else if (card.id === "wall") {
      for (const p of this.plants) p.shield = Math.max(p.shield ?? 0, Math.round(80 * power));
      this.addText(BOARD.x + BOARD.w / 2, BOARD.y + 120, "被注视的盾", toneColor, 28);
    } else if (card.id === "tax") {
      const amount = Math.round(150 * power);
      this.sun = Math.max(0, this.sun - amount);
      this.addText(BOARD.x + BOARD.w / 2, BOARD.y + 120, `灵感 -${amount}`, toneColor, 30);
    } else if (card.id === "drain") {
      for (const p of [...this.plants]) {
        if (!p.dead) this.damagePlant(p, p.maxHp * 0.12 * power);
      }
      this.addText(BOARD.x + BOARD.w / 2, BOARD.y + 120, "全园低血糖", toneColor, 30);
    } else if (card.id === "party") {
      const count = Math.round((5 + Math.random() * 3) * power);
      for (let i = 0; i < count; i++) {
        this.requestSpawn(Math.random() < 0.5 ? "basic" : "fast");
      }
      this.addText(BOARD.x + BOARD.w / 2, BOARD.y + 120, "派对开始", toneColor, 30);
    } else if (card.id === "haste") {
      for (const z of this.zombies) {
        if (z.dead) continue;
        z.baseSpeed *= 1.5;
        z.speed = z.baseSpeed;
      }
      this.addText(BOARD.x + BOARD.w / 2, BOARD.y + 120, "全员移速 +50%", toneColor, 30);
    } else if (card.id === "reunion") {
      this.spawnZombie("boss", Math.floor(Math.random() * BOARD.rows));
      this.addText(BOARD.x + BOARD.w / 2, BOARD.y + 120, "导师提前加课", toneColor, 30);
    } else if (card.id === "doom") {
      this.wipePlants();
      this.addText(BOARD.x + BOARD.w / 2, BOARD.y + 120, "全盘皆输", toneColor, 40);
    } else {
      for (const z of this.zombies) if (!z.dead) z.slow = Math.max(z.slow, 3 * power);
      this.addText(BOARD.x + BOARD.w / 2, BOARD.y + 120, "战场不存在", toneColor, 28);
    }

    this.visionTone = card.tone;
    this.visionVerdict = `【${card.name}】${card.line}`;
    this.visionLastAt = this.time;
    this.addEffect("scan", BOARD.x + BOARD.w / 2, BOARD.y + BOARD.h / 2, 0, 0.75, BOARD.w / 2, toneColor);
    this.audio.yolo();
    this.shake = Math.max(this.shake, overdrive || card.tone !== "good" ? 18 : 10);
    this.flash = Math.max(this.flash, overdrive || card.tone !== "good" ? 0.45 : 0.22);
  }

  private wipePlants() {
    const alive = this.plants.filter((p) => !p.dead);
    this.plantWipeBackup = alive.slice(0, 10).map((p) => ({ type: p.type, col: p.col, row: p.row }));
    for (const p of alive) p.dead = true;
    this.plants = [];
    this.plantWipe = true;
    for (const id of PLANT_ORDER) this.readyAt[id] = this.time + 15;
    this.events.onToast?.("全盘皆输：植物全被 YOLO 看没了，所有植物卡冷却 15 秒。现在只能求妈妈。", "#ff334f");
    this.events.onNotice?.("植物清空、卡组冷却。打开对话，喊妈妈或姐姐求她，才能把植物救回来。");
  }

  private triggerVisionMisread(counts: Record<string, number>) {
    const zc = (counts.zombie ?? 0) + (counts.boss ?? 0);
    const pc = counts.plant ?? 0;
    if (zc > 0) {
      for (const z of this.zombies) if (!z.dead) z.stun = Math.max(z.stun, 1.2);
      this.visionVerdict = `【指鹿为马】YOLO 把 ${zc} 个僵尸认成 ${zc} 个学弟，僵尸羞愧地停了 1.2 秒。`;
      this.addText(BOARD.x + BOARD.w / 2, BOARD.y + 110, "认错了", "#ff8fb0", 24);
    } else if (pc > 0) {
      for (const p of this.plants) p.hp = Math.min(p.maxHp, p.hp + p.maxHp * 0.12);
      this.visionVerdict = `【盆栽成精】YOLO 在左侧看见 ${pc} 盆会呼吸的盆栽，植物回血 12%。`;
      this.addText(BOARD.x + BOARD.w / 2, BOARD.y + 110, "光合作用？", "#6ff2a1", 24);
    } else {
      this.sun += 20;
      this.visionVerdict = "【虚无主义】YOLO 说画面里什么都没有。既然什么都没有，就送你 20 灵感。";
      this.addText(BOARD.x + BOARD.w / 2, BOARD.y + 110, "空镜 +20", "#8b7f9b", 24);
    }
    this.visionTone = "bad";
    this.audio.yolo();
  }

  private triggerVisionOverload(zc: number) {
    const card = this.pickVisionCard();
    this.sun += 45;
    this.applyVisionCard(card, true);
    this.events.onToast?.(
      `第三只眼过载【${card.name}】：${card.line} 额外 +45 灵感。`,
      card.tone === "good" ? "#69e7ff" : "#ff7f9d",
    );
    this.addText(BOARD.x + BOARD.w / 2, BOARD.y + 160, `过载 · ${card.name}`, card.tone === "good" ? "#69e7ff" : "#ff7f9d", 34);
    void zc;
  }

  toggleVision() {
    this.visionVisible = !this.visionVisible;
    if (!this.visionVisible) this.visionReport = null;
    this.audio.ui();
    return this.visionVisible;
  }

  async chat(message: string, history: ChatTurn[] = []): Promise<AgentReply> {
    if (!this.agent || this.agentBusy) {
      const reply = this.localChat(message);
      this.applyAgentAction(reply);
      this.stats.aiLines++;
      return reply;
    }
    this.agentBusy = true;
    try {
      const reply = await this.agent.chat({ message, snapshot: this.snapshot(), history: history.slice(-10) });
      this.applyAgentAction(reply);
      this.stats.aiLines++;
      return reply;
    } catch {
      const reply = this.localChat(message);
      this.applyAgentAction(reply);
      return reply;
    } finally {
      this.agentBusy = false;
    }
  }

  private wantsTsundereFavor(message: string): boolean {
    const title = /妈妈|妈咪|娘|姐姐|姐/.test(message);
    const beg = /求求|求你|拜托|帮帮|满足我|好不好|嘛|please|求/.test(message);
    return title && beg;
  }

  private localChat(message: string): AgentReply {
    const now = new Date();
    const time = now.toLocaleString("zh-CN", { weekday: "long", hour: "2-digit", minute: "2-digit" });
    if (this.wantsTsundereFavor(message)) {
      const title = /姐姐|姐/.test(message) ? "姐姐" : "妈妈";
      return {
        reply: `……谁、谁是你${title}啊！ 就、就这一次，下不为例。${this.plantWipe ? "植物和冷却都给你恢复，+200 灵感。" : "给你 120 灵感，植物回血 40%，再套一层护盾。"}`,
        action: { type: "favor", reason: "tsundere-offline" },
        source: "fallback",
      };
    }
    if (this.plantWipe) {
      return {
        reply: "植物全没了，卡也在冷却。现在只有一件事能做：喊妈妈/姐姐，再求我。",
        action: { type: "none" },
        source: "fallback",
      };
    }
    if (/^(姐姐|妈妈|妈咪|娘|姐)(在吗|在不在|好|早安|晚安|嗨)?[!！?？。.\s]*$/.test(message)) {
      return {
        reply: `……在。叫得还挺顺口。叫声费 +30 灵感，拿好，别声张。`,
        action: { type: "tip", amount: 30, reason: "sister-tip-offline" },
        source: "fallback",
      };
    }
    let text =
      message.includes("妈妈") || message.includes("姐姐")
        ? "谁、谁是你妈妈/姐姐啊！先求我，而且只准求一次。"
        : message.includes("夸")
          ? "你的阵型像一场灾难，但是一场有预算的灾难。"
          : message.includes("狠")
            ? "我已经把难度调高了。别谢我，谢早八。"
            : message.includes("规则") || message.includes("怎么玩")
              ? "种植物，攒灵感，别让僵尸碰到左边。那扇门后面是你仅剩的睡眠。"
              : message.includes("几点") || message.includes("时间") || message.includes("几号")
                ? `现在是 ${time}。早八不会因为你问时间就晚点来。`
                : message.includes("这关")
                  ? `本关是「${this.levelName}」，共 ${this.totalWaves} 波。舞台规则：${this.levelRule === "none" ? "无" : MODIFIERS[this.levelRule].label}。`
                  : "我在。虽然本地大模型没接上，但我的精神已经抽象到位了。";
    if (message.replace(/\s/g, "").match(/^[\d+\-*/().]+$/)) {
      text = "本地大脑没接上，算术暂时不接单。你先把 LM Studio 打开，我立刻变聪明。";
    }
    if (!/妈妈|妈咪|娘|姐姐|姐/.test(text)) {
      text = `${text} ${pick(LOCAL_LURES)}`;
    }
    return { reply: text, action: { type: "none" }, source: "fallback" };
  }

  private applyAgentAction(reply: AgentReply) {
    const action = reply.action;
    if (!action || action.type === "none") return;
    if (action.type === "grant_sun") {
      const amount = clamp(Math.round(action.amount ?? 50), 10, 100);
      this.sun += amount;
      this.addText(BOARD.x + BOARD.w / 2, BOARD.y + 90, `奶龙打赏 +${amount}`, "#ffe66d", 30);
      this.events.onToast?.(`奶龙从不知道哪里掏出了 ${amount} 灵感。`, "#ffe66d");
    } else if (action.type === "tip") {
      const amount = clamp(Math.round(action.amount ?? 30), 20, 35);
      this.sun += amount;
      this.addText(BOARD.x + BOARD.w / 2, BOARD.y + 90, `叫声费 +${amount}`, "#ffd447", 28);
      this.events.onToast?.(`奶龙还是心软了：叫声费 +${amount} 灵感。`, "#ffd447");
      this.audio.sun();
    } else if (action.type === "heal") {
      for (const p of this.plants) {
        p.hp = Math.min(p.maxHp, p.hp + p.maxHp * 0.25);
        this.addEffect("heal", p.x + BOARD.cw / 2, p.y + BOARD.ch / 2, p.row, 0.5, 44, "rgba(111,242,161,.8)");
      }
      this.events.onToast?.("奶龙舔了所有植物一口，回血 25%。", "#6ff2a1");
    } else if (action.type === "spawn") {
      if (this.time - this.lastSpawnCheat < 18) {
        this.events.onToast?.("奶龙说：同一招用两次就不抽象了。", "#ff7f9d");
        return;
      }
      this.lastSpawnCheat = this.time;
      const type = action.zombie && action.zombie !== "boss" ? action.zombie : "fast";
      this.spawnZombie(type, Math.floor(Math.random() * BOARD.rows));
      this.events.onToast?.("奶龙往场上放了一只东西。他说这是节目效果。", "#ff7f9d");
    } else if (action.type === "bless") {
      for (const p of this.plants) p.shield = Math.max(p.shield ?? 0, 100);
      this.events.onToast?.("奶龙给所有植物套了一层很不正规的护盾。", "#ffd447");
    } else if (action.type === "favor") {
      if (this.plantWipe) {
        this.rescueFromWipe();
        return;
      }
      this.sun += 120;
      for (const p of this.plants) {
        p.hp = Math.min(p.maxHp, p.hp + p.maxHp * 0.4);
        p.shield = Math.max(p.shield ?? 0, 120);
        this.addEffect("heal", p.x + BOARD.cw / 2, p.y + BOARD.ch / 2, p.row, 0.55, 48, "rgba(255,212,71,.85)");
      }
      this.addText(BOARD.x + BOARD.w / 2, BOARD.y + 96, "就、就这一次！", "#ffd447", 34);
      this.events.onToast?.("傲娇奶龙：就、就这一次！+120 灵感，植物回血 40%，护盾 120。", "#ffd447");
      this.audio.sun();
    }
  }

  private rescueFromWipe() {
    this.plantWipe = false;
    const backup = this.plantWipeBackup.splice(0);
    for (const id of PLANT_ORDER) this.readyAt[id] = this.time;
    this.sun += 200;
    const bank = this.sun;
    for (const item of backup) {
      this.sun = Math.max(this.sun, 9999);
      this.placePlant(item.type, item.col, item.row);
    }
    for (const id of PLANT_ORDER) this.readyAt[id] = this.time;
    this.sun = bank;
    this.visionTone = "good";
    this.visionVerdict = "【妈妈救援】YOLO 被妈妈骂到把植物吐回来了。卡组冷却清零，+200 灵感。";
    this.addText(BOARD.x + BOARD.w / 2, BOARD.y + 120, "妈妈救援", "#ffd447", 42);
    this.addEffect("heal", BOARD.x + BOARD.w / 2, BOARD.y + BOARD.h / 2, 0, 0.9, BOARD.w / 2, "rgba(255,212,71,.85)");
    this.events.onToast?.("妈妈救援：恢复最多 10 株植物，所有植物卡冷却清零，+200 灵感。", "#ffd447");
    this.audio.wave();
    this.shake = Math.max(this.shake, 18);
    this.flash = Math.max(this.flash, 0.35);
  }

  private win() {
    if (this.screen === "won") return;
    this.stats.levelIndex = this.mode === "level" ? this.levelIndex : -1;
    this.stats.levelName = this.levelName;
    this.stats.totalWaves = this.totalWaves;
    this.stats.mode = this.mode;
    this.screen = "won";
    this.events.onEnd?.(true, this.stats);
    this.audio.wave();
  }

  private lose() {
    if (this.screen === "lost") return;
    this.stats.levelIndex = this.mode === "level" ? this.levelIndex : -1;
    this.stats.levelName = this.levelName;
    this.stats.totalWaves = this.totalWaves;
    this.stats.mode = this.mode;
    this.screen = "lost";
    this.shake = 28;
    this.flash = 0.9;
    this.audio.explosion();
    this.events.onEnd?.(false, this.stats);
  }

  snapshotDetections(): Detection[] {
    return this.visionReport?.detections ?? [];
  }
}
