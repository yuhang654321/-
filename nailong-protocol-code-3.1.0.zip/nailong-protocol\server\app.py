from __future__ import annotations

import asyncio
import threading
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from starlette.concurrency import run_in_threadpool

from .agent import AgentService
from .llm import LMStudioClient
from .settings import ALLOW_ORIGINS, APP_VERSION, DIST, MODELS
from .vision import VisionService

llm = LMStudioClient()
agent = AgentService(llm)
vision = VisionService()


@asynccontextmanager
async def lifespan(_: FastAPI):
    # Loading torch/YOLO is deliberately off the event loop. The game remains
    # playable while the eye is still waking up.
    threading.Thread(target=vision.warm_abstract, name="yolo-warmup", daemon=True).start()

    async def _probe_llm() -> None:
        try:
            await llm.models(force=True)
        except Exception:
            pass

    asyncio.create_task(_probe_llm())
    yield
    await llm.close()


app = FastAPI(title="NAILONG PROTOCOL", version=APP_VERSION, lifespan=lifespan)
app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOW_ORIGINS,
    allow_origin_regex=r"http://(127\.0\.0\.1|localhost)(:\d+)?",
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)


class DirectorRequest(BaseModel):
    wave: int = Field(default=1, ge=1, le=99)
    snapshot: dict[str, Any] = Field(default_factory=dict)


class ChatTurnModel(BaseModel):
    role: str = Field(pattern="^(user|assistant)$")
    content: str = Field(max_length=300)


class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=160)
    snapshot: dict[str, Any] = Field(default_factory=dict)
    history: list[ChatTurnModel] = Field(default_factory=list, max_length=12)


class VisionRequest(BaseModel):
    image: str = Field(min_length=32)
    domain: str = Field(default="abstract", pattern="^(abstract|real)$")
    conf: float = Field(default=0.25, ge=0.05, le=0.9)


@app.get("/api/health")
async def health() -> dict[str, Any]:
    llm_info, vision_info = await asyncio.gather(llm.health(), run_in_threadpool(vision.status))
    return {
        "ok": True,
        "version": APP_VERSION,
        "llm": llm_info,
        "vision": vision_info,
    }


@app.post("/api/director")
async def director(req: DirectorRequest) -> dict[str, Any]:
    try:
        return await agent.director(req.wave, req.snapshot)
    except Exception as exc:  # noqa: BLE001
        fallback = agent.fallback_director_for(req.wave)
        fallback["error"] = str(exc)[:200]
        return fallback


@app.post("/api/chat")
async def chat(req: ChatRequest) -> dict[str, Any]:
    try:
        return await agent.chat(req.message, req.snapshot, [h.model_dump() for h in req.history])
    except Exception as exc:  # noqa: BLE001
        fallback = AgentService._fallback_chat(req.message, str(exc))
        return fallback


@app.post("/api/vision/detect")
async def detect(req: VisionRequest) -> dict[str, Any]:
    try:
        return await run_in_threadpool(vision.detect, req.image, req.domain, req.conf)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(status_code=500, detail=f"vision inference failed: {str(exc)[:200]}") from exc


@app.get("/api/models")
async def models() -> dict[str, Any]:
    names = await llm.models(force=True)
    return {"models": names, "selected": llm.model, "vision": vision.status()}


# Serve the built Vite app when `pnpm build` has run. During development the
# Vite dev server proxies /api here instead.
if (DIST / "assets").exists():
    app.mount("/assets", StaticFiles(directory=DIST / "assets"), name="assets")
if (DIST / "static").exists():
    app.mount("/static", StaticFiles(directory=DIST / "static"), name="static")
if (MODELS / "yolo11n.pt").exists():
    app.mount("/models", StaticFiles(directory=MODELS), name="models")


@app.get("/")
async def root():
    index = DIST / "index.html"
    if index.exists():
        return FileResponse(index)
    return JSONResponse(
        {
            "app": "NAILONG PROTOCOL",
            "status": "API only",
            "hint": "Run `pnpm build` or open the Vite dev server at http://127.0.0.1:5173",
            "health": "/api/health",
        }
    )


@app.get("/{full_path:path}")
async def spa(full_path: str):
    if full_path.startswith("api/"):
        raise HTTPException(status_code=404, detail="API route not found")
    if full_path.startswith("assets/") or full_path.startswith("static/"):
        raise HTTPException(status_code=404, detail="asset not found")
    index = DIST / "index.html"
    if index.exists():
        return FileResponse(index)
    raise HTTPException(status_code=404, detail="build not found; run `pnpm build`")
