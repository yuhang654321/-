import { chromium } from "playwright-core";
const browser = await chromium.launch({ executablePath: "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe", headless: true, args: ["--disable-gpu"] });
const page = await browser.newPage({ viewport: { width: 1600, height: 900 } });
const errs = [];
page.on("pageerror", (e) => errs.push(e.message));
await page.goto("http://127.0.0.1:8000/?debug", { waitUntil: "networkidle" });
await page.waitForTimeout(2400);
for (const [index, name] of [[0, "scene-l01"], [10, "scene-l11"], [14, "scene-l15"]]) {
  await page.evaluate((i) => {
    const { game: g, ui } = window.__nailong;
    g.events.onToast = () => {};
    g.events.onNotice = () => {};
    ui.showGame();
    g.startLevel(i);
    g.screen = "playing";
    g.prepTimer = 60;
    g.waveActive = false;
    const lvl = g.level;
    ui.setDialogue(`${lvl.subtitle} 规则：${lvl.rule === "none" ? "无额外舞台效果" : lvl.rule.toUpperCase()}。`);
  }, index);
  await page.waitForTimeout(500);
  await page.screenshot({ path: `demo/${name}.png` });
}
console.log("errs", errs);
console.log("scene", await page.evaluate(() => ({ level: window.__nailong.game.levelName, wave: window.__nailong.game.wave })));
await browser.close();
