const { chromium } = require("playwright-core");
(async () => {
  const browser = await chromium.launch({ executablePath: "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe", headless: true, args: ["--disable-gpu"] });
  const page = await browser.newPage({ viewport: { width: 1600, height: 900 } });
  const errs=[]; page.on("pageerror",e=>errs.push(e.message));
  await page.goto("http://127.0.0.1:8000/?debug", { waitUntil: "networkidle" });
  await page.waitForTimeout(2400);
  await page.click("#start-btn"); await page.waitForTimeout(250);
  await page.locator(".level-card").first().click(); await page.waitForTimeout(500);
  await page.evaluate(()=>{ const g=window.__nailong.game; g.visionVisible=true; g.visionSync=70; g.visionReport={detections:[],counts:{plant:2,zombie:3,boss:0,sun:1},ms:31,source:"debug"}; g.visionVerdict="【导师凝视】YOLO 把全场僵尸认定为需要延毕的学生。"; });
  await page.waitForTimeout(300);
  console.log("draw visible", await page.locator("#vision-draw").isVisible(), "disabled", await page.locator("#vision-draw").isDisabled());
  await page.click("#vision-draw");
  await page.waitForTimeout(350);
  const draw = await page.evaluate(() => ({ sync: window.__nailong.game.visionSync, verdict: window.__nailong.game.visionVerdict }));
  console.log("draw", draw);
  await page.screenshot({ path: "demo/third-eye-draw.png" });
  const overload = await page.evaluate(() => {
    const g = window.__nailong.game;
    g.visionSync = 99;
    g.setVisionReport({ detections: [], counts: { plant: 2, zombie: 3, boss: 1, sun: 1 }, ms: 12, source: "test" });
    return { sync: g.visionSync, verdict: g.visionVerdict };
  });
  console.log("overload", overload);
  console.log("card", await page.locator(".vision-card").boundingBox());
  console.log("chat", await page.locator(".chat-open").boundingBox());
  console.log("errs", errs);
  if (!(draw.sync === 45 && draw.verdict.length > 8 && overload.sync === 0 && overload.verdict.length > 8)) {
    console.error("FAIL abstract interpretation / overload");
    process.exitCode = 1;
  } else {
    console.log("PASS abstract interpretation + overload");
  }
  await browser.close();
})();
