import { chromium } from "playwright-core";
const browser = await chromium.launch({ executablePath: "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe", headless: true, args: ["--disable-gpu"] });
const page = await browser.newPage({ viewport: { width: 1600, height: 900 } });
const errs = [];
page.on("pageerror", (e) => errs.push(e.message));
page.on("console", (m) => { if (m.type() === "error") errs.push(m.text()); });
await page.goto("http://127.0.0.1:8000/?debug", { waitUntil: "networkidle" });
await page.waitForTimeout(2400);
await page.click("#start-btn");
await page.waitForTimeout(200);
await page.locator(".level-card").first().click();
await page.waitForTimeout(700);
const before = await page.evaluate(() => window.__nailong.game.sun);
await page.locator(".chat-open").click();
await page.waitForTimeout(250);
console.log("opening", await page.locator(".chat-log .msg.ai .bubble").first().innerText());
await page.locator("#chat-input").fill("姐姐在吗");
await page.locator("#chat-form button").click();
await page.waitForTimeout(1800);
const tip = await page.locator(".chat-log .msg.ai .bubble").last().innerText();
const sun = await page.evaluate(() => window.__nailong.game.sun);
console.log("tip last", tip);
console.log("sun", before, sun);
await page.locator("#chat-input").fill("为什么天空是蓝色的？");
await page.locator("#chat-form button").click();
await page.waitForTimeout(12000);
const research = await page.locator(".chat-log .msg.ai .bubble").last().innerText();
const sources = await page.locator(".chat-log .chat-sources a").count();
const notes = await page.locator(".chat-loading").allInnerTexts();
console.log("research last", research);
console.log("sources", sources);
console.log("notes", notes);
console.log("errs", errs);
await page.screenshot({ path: "demo/smart-chat.png" });
const ok =
  tip.includes("30") &&
  sun === before + 30 &&
  research.length > 30 &&
  sources >= 1 &&
  notes.some((note) => note.includes("联网")) &&
  errs.length === 0;
if (!ok) {
  console.error("FAIL smart chat / tip / web sources");
  process.exitCode = 1;
} else {
  console.log("PASS smart chat + tip + web sources");
}
await browser.close();
