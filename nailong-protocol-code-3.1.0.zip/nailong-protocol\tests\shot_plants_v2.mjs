import { chromium } from "playwright-core";
import { resolve } from "node:path";
const root = resolve(import.meta.dirname, "..");
const browser = await chromium.launch({ executablePath: "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe", headless: true, args: ["--disable-gpu"] });
const page = await browser.newPage({ viewport: { width: 1600, height: 900 } });
const errors = [];
page.on("pageerror", (e) => errors.push(e.message));
await page.goto("http://127.0.0.1:8000/?debug", { waitUntil: "networkidle" });
await page.waitForTimeout(2400);
await page.click("#start-btn");
await page.waitForTimeout(300);
await page.locator(".level-card").first().click();
await page.waitForTimeout(900);
await page.evaluate(() => {
  const { game: g, ui } = window.__nailong;
  g.sun = 9999;
  g.events.onToast = () => {};
  const spots = [
    ["flower", 0, 0], ["pea", 1, 0], ["wall", 2, 0], ["frost", 3, 0], ["fan", 4, 0],
    ["cannon", 0, 2], ["vacuum", 1, 2], ["boomerang", 2, 2], ["seal", 3, 2], ["bomb", 4, 2],
  ];
  for (const [type, col, row] of spots) {
    g.readyAt[type] = 0;
    g.placePlant(type, col, row);
  }
  const bomb = g.plants.find((p) => p.type === "bomb");
  if (bomb) bomb.fuse = 999;
  for (let row = 0; row < 5; row++) g.spawnZombie(row === 4 ? "coffee" : row % 2 ? "fast" : "basic", row);
  for (const z of g.zombies) z.x = 980 + Math.random() * 50;
  g.sun = 425;
  g.stats.plantsPlaced = 10;
  g.texts = [];
  ui.setDialogue("十只奶龙科植物，十种职业。它们长得像一家人，但工作内容完全不同。");
});
await page.waitForTimeout(1800);
await page.evaluate(() => {
  const g = window.__nailong.game;
  g.pause();
  g.texts = [];
  for (const id of ["flower", "pea", "wall", "frost", "fan", "bomb", "cannon", "vacuum", "boomerang", "seal"]) g.readyAt[id] = 0;
  document.querySelector("#toast-layer").innerHTML = "";
});
await page.waitForTimeout(250);
await page.screenshot({ path: resolve(root, "demo", "plants-v2.png") });
console.log("errors", errors, "plants", await page.evaluate(() => window.__nailong.game.plants.length));
await browser.close();
