"""Generate the base in-game cast and props from hand-authored SVG.

This is the first-generation generator.  The 2.0 plants live in
``gen_plants_v2.py`` and the redesigned enemies live in ``gen_zombies_v2.py``;
run those after this file (in that order) and then ``rasterize.mjs``.

The game intentionally ships zero third-party art.  Each character is built
from rounded primitives, thick ink lines and a small set of spot colours so the
whole cast feels like it came from the same very tired sketchbook.
"""
from __future__ import annotations

import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "assets", "svg")
os.makedirs(OUT, exist_ok=True)

INK = "#24142f"
CREAM = "#fff6df"
YELLOW = "#ffd447"
YELLOW_DARK = "#f5a623"
MAGENTA = "#ff3d8d"
MINT = "#6ff2b3"
CYAN = "#69e7ff"
PURPLE = "#5d3b8e"


def svg(body: str, defs: str = "", size: int = 512) -> str:
    return f"""<svg xmlns="http://www.w3.org/2000/svg" width="{size}" height="{size}" viewBox="0 0 512 512">
<defs>
  <filter id="soft" x="-20%" y="-20%" width="140%" height="140%">
    <feGaussianBlur stdDeviation="7"/>
  </filter>
  <pattern id="dots" width="18" height="18" patternUnits="userSpaceOnUse">
    <circle cx="4" cy="4" r="2.6" fill="{INK}" opacity=".15"/>
  </pattern>
  <linearGradient id="cream" x1="0" y1="0" x2="0" y2="1">
    <stop offset="0" stop-color="#fffdf0"/><stop offset="1" stop-color="#ffe9b8"/>
  </linearGradient>
  <linearGradient id="yellow" x1="0" y1="0" x2="0" y2="1">
    <stop offset="0" stop-color="#ffe36b"/><stop offset=".65" stop-color="{YELLOW}"/><stop offset="1" stop-color="#ffae34"/>
  </linearGradient>
  <linearGradient id="green" x1="0" y1="0" x2="0" y2="1">
    <stop offset="0" stop-color="#9bf7a4"/><stop offset="1" stop-color="#3dce62"/>
  </linearGradient>
  <linearGradient id="ice" x1="0" y1="0" x2="0" y2="1">
    <stop offset="0" stop-color="#d9fdff"/><stop offset="1" stop-color="#4fc9ee"/>
  </linearGradient>
  <linearGradient id="skin" x1="0" y1="0" x2="0" y2="1">
    <stop offset="0" stop-color="#c8d8a7"/><stop offset="1" stop-color="#829b70"/>
  </linearGradient>
  <linearGradient id="coffee" x1="0" y1="0" x2="0" y2="1">
    <stop offset="0" stop-color="#c78651"/><stop offset="1" stop-color="#7a3e22"/>
  </linearGradient>
  {defs}
</defs>
{body}
</svg>"""


def eye(cx: float, cy: float, rx: float = 13, ry: float = 17, look: float = 0) -> str:
    return f"""<g>
      <ellipse cx="{cx}" cy="{cy}" rx="{rx}" ry="{ry}" fill="{INK}"/>
      <circle cx="{cx - 4 + look}" cy="{cy - 6}" r="4.5" fill="#fff"/>
      <circle cx="{cx + 4 + look}" cy="{cy + 7}" r="2" fill="#fff" opacity=".65"/>
    </g>"""


def blush(cx: float, cy: float, r: float = 22, color: str = "#ff708b") -> str:
    return f'<ellipse cx="{cx}" cy="{cy}" rx="{r}" ry="{r*.45}" fill="{color}" opacity=".72"/>'


def sparkle(cx: float, cy: float, r: float, color: str = CREAM, opacity: float = 1) -> str:
    return f"""<path d="M {cx} {cy-r} C {cx+r*.18} {cy-r*.18} {cx+r*.18} {cy-r*.18} {cx+r} {cy}
    C {cx+r*.18} {cy+r*.18} {cx+r*.18} {cy+r*.18} {cx} {cy+r}
    C {cx-r*.18} {cy+r*.18} {cx-r*.18} {cy+r*.18} {cx-r} {cy}
    C {cx-r*.18} {cy-r*.18} {cx-r*.18} {cy-r*.18} {cx} {cy-r} Z"
    fill="{color}" opacity="{opacity}"/>"""


# --------------------------------------------------------------------------
# Plants
# --------------------------------------------------------------------------
def nylon_flower() -> str:
    petals = []
    import math
    for i in range(10):
        a = -90 + i * 36
        petals.append(
            f'<ellipse cx="256" cy="112" rx="40" ry="74" fill="url(#yellow)" stroke="{INK}" stroke-width="9" '
            f'transform="rotate({a} 256 210)"/>'
        )
    body = f"""
    <ellipse cx="256" cy="470" rx="112" ry="20" fill="{INK}" opacity=".22"/>
    <g stroke="{INK}" stroke-width="12" stroke-linecap="round">
      <path d="M256 360 C250 408 260 430 252 458" fill="none"/>
      <path d="M252 399 C216 380 191 384 171 407 C205 424 231 422 252 409" fill="url(#green)"/>
      <path d="M258 426 C294 407 319 411 339 434 C305 451 279 449 258 436" fill="url(#green)"/>
    </g>
    <path d="M175 382 C188 370 204 369 218 379" fill="none" stroke="#1f8d4b" stroke-width="5" stroke-linecap="round"/>
    {''.join(petals)}
    <path d="M149 244 C139 166 183 115 256 112 C330 109 377 164 365 246
             C355 324 312 354 256 356 C198 354 158 319 149 244 Z"
          fill="url(#yellow)" stroke="{INK}" stroke-width="13"/>
    <path d="M189 167 C211 143 238 136 256 136 C281 136 304 147 320 166"
          fill="none" stroke="#fff4b0" stroke-width="13" stroke-linecap="round" opacity=".85"/>
    <path d="M166 166 C148 142 154 120 170 110 C180 130 191 143 201 151 Z" fill="#ff9b45" stroke="{INK}" stroke-width="9"/>
    <path d="M346 166 C364 142 358 120 342 110 C332 130 321 143 311 151 Z" fill="#ff9b45" stroke="{INK}" stroke-width="9"/>
    <path d="M204 142 C212 124 226 116 238 120" fill="none" stroke="{INK}" stroke-width="7" stroke-linecap="round"/>
    <path d="M308 142 C300 124 286 116 274 120" fill="none" stroke="{INK}" stroke-width="7" stroke-linecap="round"/>
    <ellipse cx="256" cy="269" rx="92" ry="70" fill="url(#cream)" stroke="{INK}" stroke-width="8"/>
    {eye(218, 250, 12, 17)}
    {eye(294, 250, 12, 17)}
    {blush(194, 291, 20)}
    {blush(318, 291, 20)}
    <path d="M237 294 C247 305 265 305 275 294" fill="none" stroke="{INK}" stroke-width="8" stroke-linecap="round"/>
    <path d="M247 285 L247 299 M265 285 L265 299" stroke="{INK}" stroke-width="6"/>
    <path d="M180 282 C171 299 171 319 183 330" fill="none" stroke="{INK}" stroke-width="8" stroke-linecap="round"/>
    <path d="M332 282 C341 299 341 319 329 330" fill="none" stroke="{INK}" stroke-width="8" stroke-linecap="round"/>
    <path d="M226 322 C242 331 270 331 286 322" fill="none" stroke="#eb9c2c" stroke-width="6" stroke-linecap="round"/>
    <path d="M363 385 L408 367 L414 380 L372 401 Z" fill="{MAGENTA}" stroke="{INK}" stroke-width="6"/>
    <text x="391" y="391" transform="rotate(-9 391 391)" font-family="Arial Black, sans-serif" font-size="14" fill="{CREAM}" text-anchor="middle">07</text>
    {sparkle(116, 206, 18, "#fff8b0", .9)}
    {sparkle(395, 231, 12, "#fff8b0", .75)}
    """
    return svg(body)


def mouthpea() -> str:
    body = f"""
    <ellipse cx="254" cy="472" rx="115" ry="19" fill="{INK}" opacity=".22"/>
    <g stroke="{INK}" stroke-width="12" stroke-linecap="round">
      <path d="M261 352 C250 397 252 429 256 456" fill="none"/>
      <path d="M252 408 C217 382 190 386 169 407 C194 430 226 431 254 417" fill="url(#green)"/>
      <path d="M263 437 C291 418 316 419 337 439 C315 459 287 459 261 448" fill="url(#green)"/>
    </g>
    <path d="M140 248 C125 189 158 138 214 124 C284 107 353 146 370 214 C384 271 355 327 301 351
             C242 377 174 345 151 294 C143 276 139 262 140 248 Z"
          fill="url(#green)" stroke="{INK}" stroke-width="14"/>
    <path d="M178 178 C201 148 232 136 262 135" fill="none" stroke="#c6ffc4" stroke-width="14" stroke-linecap="round" opacity=".8"/>
    <path d="M235 217 C267 190 323 192 355 228 C366 241 364 264 351 278 L234 300 C208 281 207 242 235 217 Z"
          fill="#5a174c" stroke="{INK}" stroke-width="11"/>
    <path d="M245 231 L268 245 L288 226 L309 246 L332 229" fill="none" stroke="{CREAM}" stroke-width="10" stroke-linejoin="round"/>
    <path d="M242 281 L258 267 L276 284 L294 267 L310 282" fill="none" stroke="{CREAM}" stroke-width="9" stroke-linejoin="round"/>
    <path d="M205 324 C222 335 237 336 248 328" fill="none" stroke="#1b7e45" stroke-width="7" stroke-linecap="round"/>
    <g>
      <path d="M233 166 C229 136 216 119 196 109" fill="none" stroke="{INK}" stroke-width="10" stroke-linecap="round"/>
      <ellipse cx="190" cy="102" rx="30" ry="34" fill="{CREAM}" stroke="{INK}" stroke-width="9"/>
      {eye(185, 101, 9, 14)}
    </g>
    <g>
      <path d="M310 174 C319 147 336 135 356 133" fill="none" stroke="{INK}" stroke-width="10" stroke-linecap="round"/>
      <ellipse cx="364" cy="127" rx="29" ry="33" fill="{CREAM}" stroke="{INK}" stroke-width="9"/>
      {eye(370, 125, 9, 14)}
    </g>
    <path d="M352 279 C383 271 399 250 393 230" fill="none" stroke="{INK}" stroke-width="9" stroke-linecap="round"/>
    <path d="M175 294 C150 306 144 327 157 344" fill="none" stroke="{INK}" stroke-width="9" stroke-linecap="round"/>
    <path d="M391 344 L437 326 L445 342 L398 361 Z" fill="#ffe75a" stroke="{INK}" stroke-width="6"/>
    <text x="419" y="351" transform="rotate(-9 419 351)" font-family="Arial Black, sans-serif" font-size="15" fill="{INK}" text-anchor="middle">典</text>
    {sparkle(129, 188, 13, MINT, .85)}
    """
    return svg(body)


def wall_dragon() -> str:
    body = f"""
    <ellipse cx="256" cy="473" rx="135" ry="19" fill="{INK}" opacity=".22"/>
    <path d="M130 409 C109 341 135 292 196 276 C253 262 312 281 342 329 C371 376 348 433 302 455
             C250 479 160 471 130 409 Z" fill="url(#yellow)" stroke="{INK}" stroke-width="14"/>
    <path d="M170 391 C158 346 177 313 218 303" fill="none" stroke="#fff2a6" stroke-width="16" stroke-linecap="round" opacity=".8"/>
    <g stroke="{INK}" stroke-width="10" stroke-linejoin="round">
      <path d="M136 333 L86 300 L104 276 L151 305 Z" fill="#ff9b45"/>
      <path d="M357 333 L407 300 L389 276 L342 305 Z" fill="#ff9b45"/>
    </g>
    <path d="M194 222 C181 178 197 148 222 142 C231 168 243 185 257 195" fill="#ff9b45" stroke="{INK}" stroke-width="9"/>
    <path d="M321 222 C334 178 318 148 293 142 C284 168 272 185 258 195" fill="#ff9b45" stroke="{INK}" stroke-width="9"/>
    {eye(210, 338, 12, 18)}
    {eye(302, 338, 12, 18)}
    {blush(169, 376, 22)}
    {blush(343, 376, 22)}
    <path d="M226 385 C244 375 268 375 286 385 C282 415 257 426 239 415 C230 410 226 399 226 385 Z" fill="#6b243c" stroke="{INK}" stroke-width="7"/>
    <path d="M239 388 L241 401 L253 392 M272 391 L269 401 L260 394" fill="none" stroke="{CREAM}" stroke-width="5" stroke-linejoin="round"/>
    <path d="M132 415 C122 435 132 451 149 455" fill="none" stroke="{INK}" stroke-width="9" stroke-linecap="round"/>
    <path d="M380 415 C390 435 380 451 363 455" fill="none" stroke="{INK}" stroke-width="9" stroke-linecap="round"/>
    <path d="M206 456 L196 487 M305 456 L315 487" stroke="{INK}" stroke-width="12" stroke-linecap="round"/>
    <path d="M169 299 C188 286 208 280 227 282 M342 314 C326 297 307 287 287 283" fill="none" stroke="#d9871d" stroke-width="7" stroke-linecap="round"/>
    <path d="M167 237 L209 219 L218 239 L176 256 Z" fill="{CREAM}" stroke="{INK}" stroke-width="6"/>
    <text x="193" y="243" transform="rotate(-11 193 243)" font-family="Arial Black, sans-serif" font-size="16" fill="{INK}" text-anchor="middle">勿扰</text>
    """
    return svg(body)


def frost_cup() -> str:
    ice_blocks = "".join(
        f'<rect x="{x}" y="{y}" width="34" height="30" rx="9" fill="#d7fbff" stroke="{INK}" stroke-width="6" transform="rotate({r} {x+17} {y+15})"/>'
        for x, y, r in [(184, 306, -10), (225, 287, 8), (276, 303, -6), (309, 331, 14)]
    )
    body = f"""
    <ellipse cx="256" cy="474" rx="118" ry="18" fill="{INK}" opacity=".22"/>
    <path d="M189 207 L323 207 L309 438 C307 454 293 465 277 465 L235 465 C218 465 205 454 203 438 Z"
          fill="url(#ice)" stroke="{INK}" stroke-width="14"/>
    <path d="M210 236 L222 422" fill="none" stroke="#fff" stroke-width="12" stroke-linecap="round" opacity=".8"/>
    <path d="M209 283 C226 297 238 298 253 285 C270 271 283 273 299 288 C312 301 324 301 336 294" fill="none" stroke="#2c98bd" stroke-width="7" stroke-linecap="round" opacity=".65"/>
    {ice_blocks}
    <path d="M215 207 C216 169 235 147 256 147 C277 147 296 169 297 207" fill="#f9ffff" stroke="{INK}" stroke-width="13"/>
    <path d="M226 202 L230 167 M256 202 L256 159 M286 202 L282 167" stroke="{INK}" stroke-width="6" stroke-linecap="round"/>
    <path d="M196 174 L214 139 L234 160 L256 119 L278 160 L299 139 L316 174 Z" fill="#ffcf3f" stroke="{INK}" stroke-width="10" stroke-linejoin="round"/>
    <circle cx="214" cy="150" r="5" fill="{MAGENTA}"/><circle cx="256" cy="139" r="6" fill="{MAGENTA}"/><circle cx="299" cy="150" r="5" fill="{MAGENTA}"/>
    {eye(228, 334, 11, 16)}
    {eye(285, 334, 11, 16)}
    {blush(205, 366, 18, "#7cdcf3")}
    {blush(309, 366, 18, "#7cdcf3")}
    <path d="M238 373 C247 384 265 384 274 373" fill="none" stroke="{INK}" stroke-width="8" stroke-linecap="round"/>
    <path d="M252 238 L261 260 L270 238" fill="none" stroke="#2f836b" stroke-width="10" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M171 430 L135 411 L127 430 L161 449 Z" fill="#b8f5ff" stroke="{INK}" stroke-width="7"/>
    <path d="M341 430 L377 411 L385 430 L351 449 Z" fill="#b8f5ff" stroke="{INK}" stroke-width="7"/>
    {sparkle(135, 192, 18, "#e9feff", .95)}
    {sparkle(391, 300, 13, "#e9feff", .9)}
    {sparkle(364, 228, 8, "#e9feff", .8)}
    """
    return svg(body)


def electric_fan() -> str:
    blades = []
    for i in range(3):
        blades.append(
            f'<path d="M256 240 C217 226 204 195 219 170 C250 174 271 195 274 223 Z" '
            f'fill="#a9ffe1" stroke="{INK}" stroke-width="8" transform="rotate({i*120} 256 240)"/>'
        )
    body = f"""
    <ellipse cx="256" cy="472" rx="122" ry="18" fill="{INK}" opacity=".22"/>
    <g stroke="{INK}" stroke-width="11" stroke-linecap="round">
      <path d="M206 396 L176 463"/>
      <path d="M306 396 L336 463"/>
      <path d="M256 401 L256 459"/>
    </g>
    <path d="M156 454 C190 440 322 440 356 454 C346 474 166 474 156 454 Z" fill="#ffb84d" stroke="{INK}" stroke-width="10"/>
    <circle cx="256" cy="242" r="132" fill="#a4ffe3" stroke="{INK}" stroke-width="16"/>
    <circle cx="256" cy="242" r="106" fill="#4ed5b8" stroke="{INK}" stroke-width="5" opacity=".65"/>
    {''.join(blades)}
    <circle cx="256" cy="242" r="35" fill="url(#cream)" stroke="{INK}" stroke-width="10"/>
    {eye(245, 238, 7, 11)}
    {eye(270, 238, 7, 11)}
    <path d="M249 256 C255 262 263 262 269 256" fill="none" stroke="{INK}" stroke-width="6" stroke-linecap="round"/>
    <path d="M324 334 C376 335 397 357 391 383" fill="none" stroke="{INK}" stroke-width="10" stroke-linecap="round"/>
    <path d="M390 380 C392 399 378 409 365 401" fill="none" stroke="{INK}" stroke-width="9" stroke-linecap="round"/>
    <path d="M188 139 C270 116 349 158 373 220" fill="none" stroke="{MAGENTA}" stroke-width="5" stroke-dasharray="3 15" stroke-linecap="round" opacity=".9"/>
    <text x="409" y="416" font-family="Arial Black, sans-serif" font-size="18" fill="{INK}" transform="rotate(8 409 416)">3档</text>
    """
    return svg(body)


def alarm_bomb() -> str:
    body = f"""
    <ellipse cx="256" cy="474" rx="126" ry="19" fill="{INK}" opacity=".22"/>
    <path d="M157 300 C157 215 200 166 256 166 C312 166 355 215 355 300 C355 394 319 446 256 446
             C193 446 157 394 157 300 Z" fill="#ff5d6c" stroke="{INK}" stroke-width="14"/>
    <path d="M190 251 C195 216 219 196 249 193" fill="none" stroke="#ffc5c2" stroke-width="15" stroke-linecap="round" opacity=".8"/>
    <circle cx="256" cy="295" r="82" fill="url(#cream)" stroke="{INK}" stroke-width="10"/>
    <circle cx="256" cy="295" r="68" fill="#fffdf4" stroke="#d9b34a" stroke-width="4"/>
    <g stroke="{INK}" stroke-width="7" stroke-linecap="round">
      <path d="M256 240 L256 252"/><path d="M256 338 L256 350"/><path d="M201 295 L213 295"/><path d="M299 295 L311 295"/>
    </g>
    <path d="M256 295 L256 252 M256 295 L286 309" stroke="{INK}" stroke-width="8" stroke-linecap="round"/>
    <circle cx="256" cy="295" r="6" fill="{MAGENTA}"/>
    <text x="256" y="379" font-family="Arial Black, sans-serif" font-size="26" fill="{INK}" text-anchor="middle" letter-spacing="2">08:00</text>
    {eye(221, 245, 9, 12)}
    {eye(291, 245, 9, 12)}
    <path d="M228 319 C244 334 268 334 284 319" fill="none" stroke="{INK}" stroke-width="7" stroke-linecap="round"/>
    <path d="M188 169 C180 137 192 112 214 101" fill="none" stroke="{INK}" stroke-width="9" stroke-linecap="round"/>
    <path d="M211 104 C229 74 258 70 276 90 C250 110 231 117 211 104 Z" fill="#ffe35a" stroke="{INK}" stroke-width="8"/>
    <path d="M276 90 C300 78 318 85 323 102 C306 113 287 109 276 90 Z" fill="#ff9a3d" stroke="{INK}" stroke-width="7"/>
    <path d="M336 158 C361 131 380 134 391 151 C368 174 350 179 336 158 Z" fill="#ffe35a" stroke="{INK}" stroke-width="8"/>
    <path d="M155 355 C132 368 126 388 138 404" fill="none" stroke="{INK}" stroke-width="10" stroke-linecap="round"/>
    <path d="M357 355 C380 368 386 388 374 404" fill="none" stroke="{INK}" stroke-width="10" stroke-linecap="round"/>
    <path d="M194 442 L181 475 M318 442 L331 475" stroke="{INK}" stroke-width="12" stroke-linecap="round"/>
    <path d="M110 220 L94 198 M100 242 L74 237 M402 220 L418 198 M412 242 L438 237" stroke="{MAGENTA}" stroke-width="8" stroke-linecap="round"/>
    <path d="M145 199 L170 184 L180 202 L154 217 Z" fill="{CREAM}" stroke="{INK}" stroke-width="5"/>
    <text x="162" y="206" font-family="Arial Black, sans-serif" font-size="13" fill="{INK}" text-anchor="middle" transform="rotate(-12 162 206)">危</text>
    """
    return svg(body)


# --------------------------------------------------------------------------
# Zombies
# --------------------------------------------------------------------------
def zombie_base(skin: str = "url(#skin)", body_color: str = "#e9e2d0", tie: str = "#6b3b89") -> str:
    return f"""
    <path d="M153 471 C165 446 193 434 228 432 L284 432 C319 434 347 446 359 471 Z" fill="{INK}" opacity=".2"/>
    <path d="M177 273 C179 243 204 225 238 226 L274 226 C310 227 334 248 334 277 L328 382 C325 407 304 421 278 420
             L230 420 C203 421 184 406 181 382 Z" fill="{body_color}" stroke="{INK}" stroke-width="12"/>
    <path d="M238 230 L256 265 L274 230" fill="none" stroke="{INK}" stroke-width="6"/>
    <path d="M256 263 L256 340" stroke="{tie}" stroke-width="13"/>
    <path d="M256 280 L234 299 L256 316 L278 299 Z" fill="{tie}" stroke="{INK}" stroke-width="6"/>
    <path d="M237 337 L231 372 M275 337 L281 372" stroke="{INK}" stroke-width="4" opacity=".55"/>
    <path d="M192 313 C196 290 212 278 232 280 C228 303 214 316 192 319" fill="#d9cfb7" stroke="{INK}" stroke-width="6"/>
    <path d="M198 300 C210 294 218 296 223 302" fill="none" stroke="{INK}" stroke-width="4"/>
    <path d="M328 306 C354 318 360 345 344 362 C328 347 321 330 328 306 Z" fill="{skin}" stroke="{INK}" stroke-width="9"/>
    <path d="M345 347 C369 343 381 358 373 375" fill="none" stroke="{INK}" stroke-width="7" stroke-linecap="round"/>
    <path d="M195 382 C180 399 174 425 185 444" fill="none" stroke="{INK}" stroke-width="11" stroke-linecap="round"/>
    <path d="M318 382 C333 399 339 425 328 444" fill="none" stroke="{INK}" stroke-width="11" stroke-linecap="round"/>
    <path d="M210 418 L202 464 M299 418 L307 464" stroke="{INK}" stroke-width="13" stroke-linecap="round"/>
    <path d="M177 460 C197 453 217 463 219 474 L165 474 C165 467 169 463 177 460 Z" fill="#3c2e4d" stroke="{INK}" stroke-width="6"/>
    <path d="M327 460 C307 453 289 463 287 474 L341 474 C341 467 337 463 327 460 Z" fill="#3c2e4d" stroke="{INK}" stroke-width="6"/>
    """


def head(cx: float = 250, cy: float = 178, skin: str = "url(#skin)", hair: str = "#332640") -> str:
    return f"""
    <path d="M174 178 C174 115 208 78 256 78 C307 78 338 117 336 181 C334 241 301 278 254 278 C206 278 174 240 174 178 Z"
          fill="{skin}" stroke="{INK}" stroke-width="12"/>
    <path d="M174 168 C162 133 182 94 211 83 C220 111 205 134 188 146 C212 150 229 141 241 119
             C249 145 268 158 297 155 C301 131 292 108 274 92 C317 101 342 128 336 177
             C320 162 305 158 291 164 C280 145 263 139 246 148 C230 157 220 172 217 194
             C204 186 190 179 174 168 Z" fill="{hair}" stroke="{INK}" stroke-width="9"/>
    <path d="M215 175 C223 162 239 160 248 172" fill="none" stroke="{INK}" stroke-width="8" stroke-linecap="round"/>
    <path d="M274 172 C284 160 298 162 305 175" fill="none" stroke="{INK}" stroke-width="8" stroke-linecap="round"/>
    <circle cx="232" cy="189" r="9" fill="{INK}"/>
    <circle cx="286" cy="189" r="9" fill="{INK}"/>
    <circle cx="229" cy="186" r="3" fill="#fff"/>
    <circle cx="283" cy="186" r="3" fill="#fff"/>
    <path d="M211 210 C220 219 231 218 238 211" fill="none" stroke="#475448" stroke-width="4" opacity=".8"/>
    <path d="M271 211 C280 219 291 218 298 211" fill="none" stroke="#475448" stroke-width="4" opacity=".8"/>
    <path d="M248 210 L240 227 L252 230" fill="none" stroke="{INK}" stroke-width="5" stroke-linecap="round"/>
    <path d="M229 244 C243 254 269 254 283 242 C274 264 245 268 229 244 Z" fill="#4a2b3f" stroke="{INK}" stroke-width="6"/>
    <path d="M241 247 L244 256 M259 249 L258 258" stroke="{CREAM}" stroke-width="4"/>
    <path d="M188 236 C177 245 176 259 184 267" fill="none" stroke="{INK}" stroke-width="6" stroke-linecap="round"/>
    <path d="M321 236 C332 245 333 259 325 267" fill="none" stroke="{INK}" stroke-width="6" stroke-linecap="round"/>
    """


def zombie_basic() -> str:
    body = f"""
    <ellipse cx="253" cy="473" rx="120" ry="17" fill="{INK}" opacity=".2"/>
    <path d="M173 270 C176 244 198 228 228 228 L282 228 C314 229 334 247 336 275 L330 383 C328 409 303 423 276 422
             L232 422 C204 423 182 408 179 382 Z" fill="#e8dfca" stroke="{INK}" stroke-width="12"/>
    <path d="M228 232 L256 266 L284 232" fill="none" stroke="{INK}" stroke-width="6"/>
    <path d="M256 265 L256 345" stroke="#6b3b89" stroke-width="13"/>
    <path d="M256 283 L232 302 L256 322 L280 302 Z" fill="#6b3b89" stroke="{INK}" stroke-width="6"/>
    <path d="M206 338 L201 379 M303 338 L309 379" stroke="{INK}" stroke-width="4" opacity=".5"/>
    <path d="M191 313 C196 290 213 278 234 280 C228 304 213 318 191 320 Z" fill="#d7cbb2" stroke="{INK}" stroke-width="6"/>
    <path d="M200 300 C212 294 221 296 226 302" fill="none" stroke="{INK}" stroke-width="4"/>
    <path d="M339 310 C368 322 373 350 355 367 C339 350 333 333 339 310 Z" fill="url(#skin)" stroke="{INK}" stroke-width="9"/>
    <path d="M351 352 C374 349 384 364 377 380" fill="none" stroke="{INK}" stroke-width="7" stroke-linecap="round"/>
    <rect x="366" y="376" width="27" height="44" rx="5" fill="#5e8b9e" stroke="{INK}" stroke-width="6" transform="rotate(12 379 398)"/>
    <path d="M190 383 C175 400 169 426 180 445" fill="none" stroke="{INK}" stroke-width="11" stroke-linecap="round"/>
    <path d="M322 383 C337 400 343 426 332 445" fill="none" stroke="{INK}" stroke-width="11" stroke-linecap="round"/>
    <path d="M207 420 L199 465 M303 420 L311 465" stroke="{INK}" stroke-width="13" stroke-linecap="round"/>
    <path d="M175 462 C196 455 216 464 218 475 L163 475 C163 468 167 465 175 462 Z" fill="#3c2e4d" stroke="{INK}" stroke-width="6"/>
    <path d="M329 462 C308 455 288 464 286 475 L341 475 C341 468 337 465 329 462 Z" fill="#3c2e4d" stroke="{INK}" stroke-width="6"/>
    <path d="M158 248 C136 278 138 327 163 349 C177 361 191 366 206 363 C184 338 174 303 178 263 Z" fill="#6d5d88" stroke="{INK}" stroke-width="10"/>
    <path d="M165 275 C150 290 148 314 158 331" fill="none" stroke="#9b8db4" stroke-width="7" stroke-linecap="round"/>
    {head()}
    <path d="M300 143 C326 125 347 130 356 146 C334 163 316 160 300 143 Z" fill="#f6e8c9" stroke="{INK}" stroke-width="6"/>
    <text x="328" y="150" transform="rotate(8 328 150)" font-family="Arial Black, sans-serif" font-size="12" fill="{INK}" text-anchor="middle">早八</text>
    <path d="M154 204 C134 198 124 208 127 222 C143 228 155 220 154 204 Z" fill="#d8cfb8" stroke="{INK}" stroke-width="6"/>
    """
    return svg(body)


def zombie_fast() -> str:
    body = f"""
    <ellipse cx="253" cy="473" rx="128" ry="17" fill="{INK}" opacity=".2"/>
    <path d="M173 270 C176 244 198 228 228 228 L282 228 C314 229 334 247 336 275 L330 383 C328 409 303 423 276 422
             L232 422 C204 423 182 408 179 382 Z" fill="#e8dfca" stroke="{INK}" stroke-width="12"/>
    <path d="M228 232 L256 266 L284 232" fill="none" stroke="{INK}" stroke-width="6"/>
    <path d="M256 265 L256 345" stroke="#ff5e78" stroke-width="13"/>
    <path d="M256 283 L232 302 L256 322 L280 302 Z" fill="#ff5e78" stroke="{INK}" stroke-width="6"/>
    <path d="M339 310 C368 322 373 350 355 367 C339 350 333 333 339 310 Z" fill="url(#skin)" stroke="{INK}" stroke-width="9"/>
    <path d="M190 383 C175 400 169 426 180 445" fill="none" stroke="{INK}" stroke-width="11" stroke-linecap="round"/>
    <path d="M322 383 C337 400 343 426 332 445" fill="none" stroke="{INK}" stroke-width="11" stroke-linecap="round"/>
    <path d="M207 420 L199 465 M303 420 L311 465" stroke="{INK}" stroke-width="13" stroke-linecap="round"/>
    {head()}
    <path d="M173 160 C145 157 125 174 124 198 C151 207 173 191 173 160 Z" fill="#ff5577" stroke="{INK}" stroke-width="8"/>
    <path d="M329 160 C357 157 377 174 378 198 C351 207 329 191 329 160 Z" fill="#ff5577" stroke="{INK}" stroke-width="8"/>
    <path d="M124 184 C102 184 88 200 94 218 C115 222 128 207 124 184 Z" fill="#3d2c4c" stroke="{INK}" stroke-width="8"/>
    <path d="M378 184 C400 184 414 200 408 218 C387 222 374 207 378 184 Z" fill="#3d2c4c" stroke="{INK}" stroke-width="8"/>
    <g transform="translate(-8 434)">
      <path d="M137 0 C187 -15 292 -12 346 8 C358 12 354 29 340 31 C277 40 190 38 139 27 C126 25 124 5 137 0 Z"
            fill="#ff3d8d" stroke="{INK}" stroke-width="9"/>
      <circle cx="160" cy="27" r="14" fill="#ffe66d" stroke="{INK}" stroke-width="5"/>
      <circle cx="312" cy="28" r="14" fill="#ffe66d" stroke="{INK}" stroke-width="5"/>
    </g>
    <path d="M145 239 C131 229 117 235 114 251" fill="none" stroke="{INK}" stroke-width="8" stroke-linecap="round"/>
    <path d="M373 337 C393 332 403 344 398 359" fill="none" stroke="{INK}" stroke-width="7" stroke-linecap="round"/>
    <path d="M101 124 L79 104 M93 143 L67 140 M391 118 L413 98 M400 138 L426 135" stroke="{MAGENTA}" stroke-width="7" stroke-linecap="round"/>
    """
    return svg(body)


def zombie_paper() -> str:
    papers = []
    import random
    rng = random.Random(17)
    for i in range(9):
        x = 155 + rng.randint(0, 190)
        y = 230 + rng.randint(0, 180)
        r = rng.randint(-22, 22)
        papers.append(
            f'<g transform="rotate({r} {x} {y})"><rect x="{x}" y="{y}" width="{rng.randint(58,86)}" height="{rng.randint(72,100)}" '
            f'fill="#f7f1da" stroke="{INK}" stroke-width="5"/><path d="M{x+10} {y+18} H{x+55} M{x+10} {y+31} H{x+48} '
            f'M{x+10} {y+44} H{x+58}" stroke="#7d7287" stroke-width="4"/></g>'
        )
    body = f"""
    <ellipse cx="253" cy="474" rx="130" ry="17" fill="{INK}" opacity=".2"/>
    <path d="M173 270 C176 244 198 228 228 228 L282 228 C314 229 334 247 336 275 L330 383 C328 409 303 423 276 422
             L232 422 C204 423 182 408 179 382 Z" fill="#e8dfca" stroke="{INK}" stroke-width="12"/>
    <path d="M190 383 C175 400 169 426 180 445" fill="none" stroke="{INK}" stroke-width="11" stroke-linecap="round"/>
    <path d="M322 383 C337 400 343 426 332 445" fill="none" stroke="{INK}" stroke-width="11" stroke-linecap="round"/>
    <path d="M207 420 L199 465 M303 420 L311 465" stroke="{INK}" stroke-width="13" stroke-linecap="round"/>
    {head()}
    {''.join(papers)}
    <path d="M166 218 C222 196 317 200 351 234" fill="none" stroke="#efb84e" stroke-width="14" opacity=".85"/>
    <path d="M167 214 L349 238" stroke="{INK}" stroke-width="4" stroke-dasharray="5 9" opacity=".6"/>
    <g transform="rotate(-7 248 246)">
      <rect x="197" y="226" width="104" height="36" rx="6" fill="#ffde59" stroke="{INK}" stroke-width="6"/>
      <text x="249" y="251" font-family="Arial Black, sans-serif" font-size="18" fill="{INK}" text-anchor="middle">DRAFT 17</text>
    </g>
    <path d="M351 352 C374 349 384 364 377 380" fill="none" stroke="{INK}" stroke-width="7" stroke-linecap="round"/>
    """
    return svg(body)


def zombie_coffee() -> str:
    body = f"""
    <ellipse cx="253" cy="474" rx="122" ry="17" fill="{INK}" opacity=".2"/>
    <path d="M173 270 C176 244 198 228 228 228 L282 228 C314 229 334 247 336 275 L330 383 C328 409 303 423 276 422
             L232 422 C204 423 182 408 179 382 Z" fill="#e8dfca" stroke="{INK}" stroke-width="12"/>
    <path d="M228 232 L256 266 L284 232" fill="none" stroke="{INK}" stroke-width="6"/>
    <path d="M256 265 L256 345" stroke="#3f7b56" stroke-width="13"/>
    <path d="M256 283 L232 302 L256 322 L280 302 Z" fill="#3f7b56" stroke="{INK}" stroke-width="6"/>
    <path d="M190 383 C175 400 169 426 180 445" fill="none" stroke="{INK}" stroke-width="11" stroke-linecap="round"/>
    <path d="M322 383 C337 400 343 426 332 445" fill="none" stroke="{INK}" stroke-width="11" stroke-linecap="round"/>
    <path d="M207 420 L199 465 M303 420 L311 465" stroke="{INK}" stroke-width="13" stroke-linecap="round"/>
    {head()}
    <path d="M310 248 C344 237 370 260 368 291 L365 353 C364 372 348 381 332 372 L302 349 Z"
          fill="#cdeff5" stroke="{INK}" stroke-width="9"/>
    <path d="M318 267 L320 353" stroke="#fff" stroke-width="7" opacity=".7"/>
    <path d="M309 249 L370 249 L365 290 L314 286 Z" fill="url(#coffee)" stroke="{INK}" stroke-width="7"/>
    <path d="M376 268 C404 264 414 288 397 304 C387 313 374 307 371 294" fill="none" stroke="{INK}" stroke-width="10" stroke-linecap="round"/>
    <path d="M340 243 L356 186" stroke="#ff5b82" stroke-width="12" stroke-linecap="round"/>
    <path d="M329 230 C308 214 294 218 285 230 C300 243 317 242 329 230 Z" fill="#ffcf4a" stroke="{INK}" stroke-width="6"/>
    <path d="M138 224 C118 222 107 238 115 254 C132 258 144 243 138 224 Z" fill="#d8cfb8" stroke="{INK}" stroke-width="6"/>
    <path d="M140 270 C116 276 108 296 121 312" fill="none" stroke="{INK}" stroke-width="8" stroke-linecap="round"/>
    <path d="M366 140 L385 113 M378 159 L406 147 M342 130 L339 100" stroke="{MAGENTA}" stroke-width="7" stroke-linecap="round"/>
    <path d="M160 346 C136 360 130 383 145 400" fill="none" stroke="{INK}" stroke-width="8" stroke-linecap="round"/>
    <path d="M360 414 C381 424 389 443 378 458" fill="none" stroke="#5b3622" stroke-width="10" stroke-linecap="round" opacity=".7"/>
    """
    return svg(body)


def boss_professor() -> str:
    papers = "".join(
        f'<g transform="rotate({r} {x} {y})"><rect x="{x}" y="{y}" width="34" height="48" fill="#fff3cf" stroke="{INK}" stroke-width="4"/>'
        f'<path d="M{x+6} {y+12} H{x+27} M{x+6} {y+22} H{x+23}" stroke="#8f866f" stroke-width="3"/></g>'
        for x, y, r in [(59, 293, -18), (72, 355, 9), (394, 310, 19), (420, 385, -8)]
    )
    body = f"""
    <ellipse cx="256" cy="485" rx="170" ry="17" fill="{INK}" opacity=".25"/>
    {papers}
    <path d="M167 344 C139 382 129 438 140 480 L372 480 C383 438 373 382 345 344 Z" fill="#312046" stroke="{INK}" stroke-width="13"/>
    <path d="M167 344 L215 480 M345 344 L297 480" stroke="#6b458f" stroke-width="7"/>
    <path d="M181 365 C179 328 203 303 229 300 L283 300 C311 303 333 326 331 364 L323 425 C319 454 293 470 266 468
             L236 468 C207 470 187 452 184 425 Z" fill="#221734" stroke="{INK}" stroke-width="13"/>
    <path d="M231 302 L256 344 L281 302" fill="none" stroke="#ffd76a" stroke-width="7"/>
    <path d="M256 342 L256 420" stroke="#ff4d6d" stroke-width="10"/>
    <path d="M256 360 L232 380 L256 401 L280 380 Z" fill="#ff4d6d" stroke="{INK}" stroke-width="6"/>
    <path d="M198 389 C181 371 174 345 186 322" fill="none" stroke="{INK}" stroke-width="12" stroke-linecap="round"/>
    <path d="M314 389 C331 371 338 345 326 322" fill="none" stroke="{INK}" stroke-width="12" stroke-linecap="round"/>
    <path d="M159 217 C156 137 196 90 256 90 C318 90 358 137 354 218 C352 280 319 320 256 322
             C192 320 161 280 159 217 Z" fill="url(#cream)" stroke="{INK}" stroke-width="14"/>
    <path d="M159 199 C169 142 202 111 248 104 C278 100 309 113 330 140 C303 126 280 131 267 151
             C249 135 228 140 221 166 C206 157 184 169 176 197 Z" fill="#e9dfc8" stroke="{INK}" stroke-width="9"/>
    <path d="M166 204 C149 190 139 194 137 209 C147 227 165 226 175 216 Z" fill="#f6efd8" stroke="{INK}" stroke-width="7"/>
    <path d="M346 204 C363 190 373 194 375 209 C365 227 347 226 337 216 Z" fill="#f6efd8" stroke="{INK}" stroke-width="7"/>
    <path d="M189 219 C206 201 232 200 248 218" fill="none" stroke="{INK}" stroke-width="8" stroke-linecap="round"/>
    <path d="M264 218 C281 200 307 201 323 219" fill="none" stroke="{INK}" stroke-width="8" stroke-linecap="round"/>
    <circle cx="222" cy="230" r="17" fill="#ff334f" stroke="{INK}" stroke-width="6"/>
    <circle cx="291" cy="230" r="17" fill="#ff334f" stroke="{INK}" stroke-width="6"/>
    <circle cx="218" cy="225" r="4" fill="#fff"/><circle cx="287" cy="225" r="4" fill="#fff"/>
    <path d="M242 242 L242 268 M270 242 L270 268" stroke="#7f6c62" stroke-width="4" opacity=".6"/>
    <path d="M207 272 C231 262 282 262 306 272 C300 301 273 315 256 314 C238 315 213 301 207 272 Z"
          fill="#4c2742" stroke="{INK}" stroke-width="7"/>
    <path d="M219 272 L224 287 L236 274 M247 271 L250 289 L263 272 M276 272 L278 288 L290 274"
          stroke="{CREAM}" stroke-width="5" stroke-linejoin="round" fill="none"/>
    <path d="M232 300 C247 309 268 309 282 299" fill="none" stroke="{MAGENTA}" stroke-width="5" stroke-linecap="round"/>
    <path d="M199 129 C211 109 232 101 246 107" fill="none" stroke="#fff" stroke-width="7" stroke-linecap="round" opacity=".8"/>
    <path d="M188 98 L208 67 L236 91 L256 54 L277 92 L305 66 L323 99 Z" fill="#ffd447" stroke="{INK}" stroke-width="8" stroke-linejoin="round"/>
    <text x="256" y="91" font-family="ZCOOL KuaiLe, Microsoft YaHei, sans-serif" font-size="19" fill="{INK}" text-anchor="middle">终身教职</text>
    <path d="M346 327 L414 376" stroke="{INK}" stroke-width="9" stroke-linecap="round"/>
    <path d="M407 370 C423 369 431 380 422 392 C410 392 402 383 407 370 Z" fill="{MAGENTA}" stroke="{INK}" stroke-width="5"/>
    <path d="M389 398 L460 424 L452 443 L382 417 Z" fill="#ffde59" stroke="{INK}" stroke-width="6"/>
    <text x="420" y="429" transform="rotate(22 420 429)" font-family="Arial Black, sans-serif" font-size="14" fill="{INK}" text-anchor="middle">DDL</text>
    <path d="M148 440 C133 419 137 394 159 380" fill="none" stroke="{INK}" stroke-width="12" stroke-linecap="round"/>
    <path d="M364 440 C379 419 375 394 353 380" fill="none" stroke="{INK}" stroke-width="12" stroke-linecap="round"/>
    <path d="M213 490 L205 505 M299 490 L307 505" stroke="{INK}" stroke-width="12" stroke-linecap="round"/>
    <path d="M149 172 L122 151 M142 195 L112 190 M362 172 L389 151 M370 195 L400 190" stroke="#ffcf4a" stroke-width="7" stroke-linecap="round"/>
    """
    return svg(body)


def mascot_nailong() -> str:
    body = f"""
    <ellipse cx="258" cy="480" rx="159" ry="21" fill="{INK}" opacity=".2"/>
    <path d="M196 306 C162 278 128 283 124 308 C142 336 176 336 200 318 Z" fill="#bff8ff" stroke="{INK}" stroke-width="9"/>
    <path d="M320 306 C354 278 388 283 392 308 C374 336 340 336 316 318 Z" fill="#bff8ff" stroke="{INK}" stroke-width="9"/>
    <path d="M158 302 C175 299 186 305 193 314 M360 302 C343 299 332 305 325 314" fill="none" stroke="#69c8e8" stroke-width="4" stroke-linecap="round"/>
    <path d="M330 414 C384 420 419 447 404 481 C395 500 374 501 363 486 C382 474 380 456 354 449"
          fill="url(#yellow)" stroke="{INK}" stroke-width="11" stroke-linecap="round"/>
    <path d="M401 481 C414 474 425 482 421 495 C412 506 397 501 393 490 Z" fill="#ff9b45" stroke="{INK}" stroke-width="7"/>
    <path d="M190 320 C169 365 172 434 203 462 L313 462 C344 434 347 365 326 320 Z" fill="url(#yellow)" stroke="{INK}" stroke-width="13"/>
    <ellipse cx="258" cy="414" rx="56" ry="43" fill="#ffe89a" stroke="{INK}" stroke-width="7"/>
    <path d="M224 399 C236 389 250 386 262 388" fill="none" stroke="#fff3bd" stroke-width="7" stroke-linecap="round" opacity=".8"/>
    <path d="M327 249 C390 203 423 219 413 287 C406 334 375 341 343 319 C367 297 368 270 346 254 Z"
          fill="#ffe06a" stroke="{INK}" stroke-width="12"/>
    <path d="M334 257 C376 233 398 242 397 278" fill="none" stroke="#fff4ae" stroke-width="9" stroke-linecap="round" opacity=".9"/>
    <path d="M168 246 C114 204 83 230 101 290 C113 328 144 332 171 311 C147 291 147 267 168 246 Z"
          fill="#ffe06a" stroke="{INK}" stroke-width="12"/>
    <path d="M188 296 C146 288 118 314 128 356 C150 390 193 390 213 355 C198 335 196 316 188 296 Z"
          fill="#ff9b45" stroke="{INK}" stroke-width="11"/>
    <path d="M330 308 C371 301 396 333 383 371 C359 401 323 393 307 361 C320 344 327 326 330 308 Z"
          fill="#ff9b45" stroke="{INK}" stroke-width="11"/>
    <path d="M160 432 C140 459 145 483 168 488 C190 492 203 472 198 445 Z" fill="#ffca3d" stroke="{INK}" stroke-width="11"/>
    <path d="M354 432 C374 459 369 483 346 488 C324 492 311 472 316 445 Z" fill="#ffca3d" stroke="{INK}" stroke-width="11"/>
    <path d="M147 251 C133 180 178 121 256 117 C335 112 386 167 372 250 C360 327 321 366 258 368
             C193 367 158 325 147 251 Z" fill="url(#yellow)" stroke="{INK}" stroke-width="14"/>
    <path d="M188 174 C206 148 234 137 259 137 C288 137 312 150 326 175" fill="none" stroke="#fff7ba" stroke-width="15" stroke-linecap="round" opacity=".85"/>
    <path d="M151 163 C128 135 139 105 160 99 C171 125 188 143 204 151 Z" fill="#ff9b45" stroke="{INK}" stroke-width="10"/>
    <path d="M361 163 C384 135 373 105 352 99 C341 125 324 143 308 151 Z" fill="#ff9b45" stroke="{INK}" stroke-width="10"/>
    <path d="M164 233 C143 230 133 243 140 259 C155 264 167 251 164 233 Z" fill="#ffe48e" stroke="{INK}" stroke-width="6" opacity=".8"/>
    <path d="M354 233 C375 230 385 243 378 259 C363 264 351 251 354 233 Z" fill="#ffe48e" stroke="{INK}" stroke-width="6" opacity=".8"/>
    {eye(211, 230, 14, 20)}
    {eye(303, 230, 14, 20)}
    {blush(176, 277, 24, "#ff6f86")}
    {blush(339, 277, 24, "#ff6f86")}
    <path d="M220 282 C245 269 276 269 300 283 C296 331 266 351 242 339 C224 330 217 306 220 282 Z"
          fill="#7f233f" stroke="{INK}" stroke-width="8"/>
    <path d="M234 291 L237 309 L253 294 M269 294 L267 311 L280 296" fill="none" stroke="{CREAM}" stroke-width="6" stroke-linejoin="round"/>
    <path d="M238 323 C250 332 267 332 279 323" fill="none" stroke="#ff97a8" stroke-width="6" stroke-linecap="round"/>
    <path d="M137 368 C104 388 96 421 121 440" fill="none" stroke="{INK}" stroke-width="12" stroke-linecap="round"/>
    <path d="M379 368 C412 388 420 421 395 440" fill="none" stroke="{INK}" stroke-width="12" stroke-linecap="round"/>
    <path d="M203 459 L192 499 M313 459 L324 499" stroke="{INK}" stroke-width="13" stroke-linecap="round"/>
    <path d="M158 497 C177 485 215 492 219 505 L135 505 C135 498 145 501 158 497 Z" fill="#ff7f9d" stroke="{INK}" stroke-width="7"/>
    <path d="M358 497 C339 485 301 492 297 505 L381 505 C381 498 371 501 358 497 Z" fill="#ff7f9d" stroke="{INK}" stroke-width="7"/>
    <path d="M150 344 C169 357 205 359 228 348" fill="none" stroke="{MAGENTA}" stroke-width="15" stroke-linecap="round"/>
    <path d="M150 344 L128 377 L159 384 L176 355" fill="{MAGENTA}" stroke="{INK}" stroke-width="7"/>
    <path d="M300 349 L330 388 L356 373 L330 341" fill="{MAGENTA}" stroke="{INK}" stroke-width="7"/>
    <path d="M361 361 L411 340 L421 358 L371 378 Z" fill="{CREAM}" stroke="{INK}" stroke-width="6"/>
    <text x="392" y="362" transform="rotate(-11 392 362)" font-family="ZCOOL KuaiLe, Microsoft YaHei, sans-serif" font-size="19" fill="{INK}" text-anchor="middle">早八？</text>
    {sparkle(110, 188, 18, "#fff7a8", .95)}
    {sparkle(410, 210, 11, "#fff7a8", .8)}
    <path d="M419 274 L436 249 M428 292 L454 282" stroke="{MAGENTA}" stroke-width="7" stroke-linecap="round"/>
    <circle cx="256" cy="505" r="3" fill="{INK}" opacity=".3"/>
    """
    return svg(body)


def mascot_face() -> str:
    body = f"""
    <circle cx="256" cy="256" r="211" fill="#ffd447" stroke="{INK}" stroke-width="6" opacity=".2"/>
    <path d="M75 245 C68 139 143 67 256 64 C371 61 448 138 437 249 C426 359 352 426 256 430
             C158 432 83 358 75 245 Z" fill="url(#yellow)" stroke="{INK}" stroke-width="16"/>
    <path d="M126 172 C152 119 198 96 253 99 C306 102 350 130 373 176" fill="none" stroke="#fff8b9" stroke-width="18" stroke-linecap="round" opacity=".75"/>
    <path d="M65 180 C30 136 52 87 85 84 C99 125 121 150 151 165 Z" fill="#ff9b45" stroke="{INK}" stroke-width="11"/>
    <path d="M447 180 C482 136 460 87 427 84 C413 125 391 150 361 165 Z" fill="#ff9b45" stroke="{INK}" stroke-width="11"/>
    <path d="M84 302 C50 310 43 337 60 357 C84 362 99 340 94 316 Z" fill="#ffe48e" stroke="{INK}" stroke-width="7" opacity=".8"/>
    <path d="M428 302 C462 310 469 337 452 357 C428 362 413 340 418 316 Z" fill="#ffe48e" stroke="{INK}" stroke-width="7" opacity=".8"/>
    {eye(185, 230, 19, 28)}
    {eye(327, 230, 19, 28)}
    {blush(127, 302, 34, "#ff7188")}
    {blush(385, 302, 34, "#ff7188")}
    <path d="M196 305 C230 286 282 286 316 306 C310 379 270 407 238 390 C213 377 200 342 196 305 Z"
          fill="#7f233f" stroke="{INK}" stroke-width="9"/>
    <path d="M216 319 L220 345 L240 323 M272 323 L270 348 L287 325" fill="none" stroke="{CREAM}" stroke-width="7" stroke-linejoin="round"/>
    <path d="M225 364 C244 376 270 376 289 362" fill="none" stroke="#ff9aae" stroke-width="7" stroke-linecap="round"/>
    <path d="M117 382 C83 407 79 443 105 462" fill="none" stroke="{INK}" stroke-width="13" stroke-linecap="round"/>
    <path d="M395 382 C429 407 433 443 407 462" fill="none" stroke="{INK}" stroke-width="13" stroke-linecap="round"/>
    <path d="M364 365 L411 342 L422 361 L374 384 Z" fill="{CREAM}" stroke="{INK}" stroke-width="6"/>
    <text x="393" y="366" transform="rotate(-11 393 366)" font-family="ZCOOL KuaiLe, Microsoft YaHei, sans-serif" font-size="18" fill="{INK}" text-anchor="middle">？</text>
    {sparkle(462, 218, 15, "#fff7a8", .9)}
    """
    return svg(body)


def zombie_base(skin: str = "url(#skin)", body_color: str = "#e9e2d0", tie: str = "#6b3b89") -> str:
    return f"""
    <path d="M153 471 C165 446 193 434 228 432 L284 432 C319 434 347 446 359 471 Z" fill="{INK}" opacity=".2"/>
    <path d="M177 273 C179 243 204 225 238 226 L274 226 C310 227 334 248 334 277 L328 382 C325 407 304 421 278 420
             L230 420 C203 421 184 406 181 382 Z" fill="{body_color}" stroke="{INK}" stroke-width="12"/>
    <path d="M238 230 L256 265 L274 230" fill="none" stroke="{INK}" stroke-width="6"/>
    <path d="M256 263 L256 340" stroke="{tie}" stroke-width="13"/>
    <path d="M256 280 L234 299 L256 316 L278 299 Z" fill="{tie}" stroke="{INK}" stroke-width="6"/>
    <path d="M237 337 L231 372 M275 337 L281 372" stroke="{INK}" stroke-width="4" opacity=".55"/>
    <path d="M192 313 C196 290 212 278 232 280 C228 303 214 316 192 319" fill="#d9cfb7" stroke="{INK}" stroke-width="6"/>
    <path d="M198 300 C210 294 218 296 223 302" fill="none" stroke="{INK}" stroke-width="4"/>
    <path d="M328 306 C354 318 360 345 344 362 C328 347 321 330 328 306 Z" fill="{skin}" stroke="{INK}" stroke-width="9"/>
    <path d="M345 347 C369 343 381 358 373 375" fill="none" stroke="{INK}" stroke-width="7" stroke-linecap="round"/>
    <path d="M195 382 C180 399 174 425 185 444" fill="none" stroke="{INK}" stroke-width="11" stroke-linecap="round"/>
    <path d="M318 382 C333 399 339 425 328 444" fill="none" stroke="{INK}" stroke-width="11" stroke-linecap="round"/>
    <path d="M210 418 L202 464 M299 418 L307 464" stroke="{INK}" stroke-width="13" stroke-linecap="round"/>
    <path d="M177 460 C197 453 217 463 219 474 L165 474 C165 467 169 463 177 460 Z" fill="#3c2e4d" stroke="{INK}" stroke-width="6"/>
    <path d="M327 460 C307 453 289 463 287 474 L341 474 C341 467 337 463 327 460 Z" fill="#3c2e4d" stroke="{INK}" stroke-width="6"/>
    """


# --------------------------------------------------------------------------
# Props / FX
# --------------------------------------------------------------------------
def inspiration_sun() -> str:
    body = f"""
    <circle cx="256" cy="259" r="124" fill="#ffe66a" opacity=".18" filter="url(#soft)"/>
    <g stroke="#ffcf3f" stroke-width="9" stroke-linecap="round">
      <path d="M256 87 L256 122"/><path d="M256 397 L256 432"/><path d="M84 259 L119 259"/><path d="M393 259 L428 259"/>
      <path d="M133 136 L158 161"/><path d="M379 136 L354 161"/><path d="M133 383 L158 358"/><path d="M379 383 L354 358"/>
    </g>
    <path d="M207 305 C193 256 209 209 256 197 C304 185 342 220 340 264 C338 294 323 314 306 326
             L309 350 L207 350 L209 329 C208 319 207 314 207 305 Z" fill="#fff39c" stroke="{INK}" stroke-width="12"/>
    <path d="M211 355 L306 355 C313 373 305 390 284 393 L234 393 C215 390 204 374 211 355 Z" fill="#ffd34a" stroke="{INK}" stroke-width="9"/>
    <path d="M231 303 C239 294 250 295 256 305 C264 294 276 294 283 303" fill="none" stroke="{INK}" stroke-width="7" stroke-linecap="round"/>
    {eye(236, 272, 7, 11)}
    {eye(278, 272, 7, 11)}
    {blush(215, 293, 14, "#ff9a85")}
    {blush(302, 293, 14, "#ff9a85")}
    <path d="M243 291 C251 299 264 299 271 291" fill="none" stroke="{INK}" stroke-width="5" stroke-linecap="round"/>
    <path d="M256 197 L256 222" stroke="{INK}" stroke-width="8"/>
    <path d="M256 222 C239 211 226 216 221 228 C237 240 250 235 256 222 Z" fill="#7ae56e" stroke="{INK}" stroke-width="6"/>
    <text x="256" y="432" font-family="Arial Black, sans-serif" font-size="20" fill="{INK}" text-anchor="middle" opacity=".8">25</text>
    """
    return svg(body)


def speech_bubble() -> str:
    body = f"""
    <path d="M104 141 C104 98 146 75 226 75 C318 75 376 105 376 154 C376 202 323 230 233 230
             C216 230 205 229 193 226 L143 272 L151 216 C120 200 104 176 104 141 Z"
          fill="{CREAM}" stroke="{INK}" stroke-width="12"/>
    <path d="M121 128 C129 100 159 88 197 86" fill="none" stroke="#fff" stroke-width="8" stroke-linecap="round" opacity=".7"/>
    <text x="241" y="181" font-family="ZCOOL KuaiLe, Microsoft YaHei, sans-serif" font-size="82" fill="{INK}" text-anchor="middle">典</text>
    <path d="M305 108 L331 92" stroke="{MAGENTA}" stroke-width="8" stroke-linecap="round"/>
    <path d="M319 134 L344 138" stroke="{MAGENTA}" stroke-width="7" stroke-linecap="round"/>
    """
    return svg(body)


def ddl_plane() -> str:
    body = f"""
    <path d="M86 266 L426 137 L316 373 L246 306 Z" fill="#fff2c9" stroke="{INK}" stroke-width="12" stroke-linejoin="round"/>
    <path d="M246 306 L426 137 L216 254 Z" fill="#ffcf4a" stroke="{INK}" stroke-width="8" stroke-linejoin="round"/>
    <path d="M246 306 L253 386 L292 326" fill="#ff8a9d" stroke="{INK}" stroke-width="8" stroke-linejoin="round"/>
    <text x="304" y="247" transform="rotate(-24 304 247)" font-family="Arial Black, sans-serif" font-size="34" fill="#e02348" text-anchor="middle">DDL</text>
    <path d="M120 336 C98 358 99 383 117 397" fill="none" stroke="{MAGENTA}" stroke-width="7" stroke-dasharray="3 11" stroke-linecap="round"/>
    """
    return svg(body)


def slipper_launcher() -> str:
    body = f"""
    <path d="M95 345 C137 303 230 294 302 325 C347 344 361 383 331 409 C289 446 172 438 115 409 C86 394 76 367 95 345 Z"
          fill="#ff7e9e" stroke="{INK}" stroke-width="12"/>
    <path d="M154 333 C194 313 273 321 299 350" fill="none" stroke="#ffd0db" stroke-width="12" stroke-linecap="round"/>
    <path d="M188 379 C216 367 250 371 268 389 C243 402 213 399 188 379 Z" fill="#ffd447" stroke="{INK}" stroke-width="6"/>
    <path d="M293 301 C316 282 344 288 351 310 C329 325 306 318 293 301 Z" fill="#ffe66d" stroke="{INK}" stroke-width="8"/>
    <path d="M121 286 C110 260 124 238 147 235" fill="none" stroke="#8d5cff" stroke-width="9" stroke-linecap="round"/>
    {sparkle(111, 209, 17, MINT, .9)}
    <text x="239" y="443" font-family="ZCOOL KuaiLe, Microsoft YaHei, sans-serif" font-size="28" fill="{INK}" text-anchor="middle">宿管空投</text>
    """
    return svg(body)


def house() -> str:
    body = f"""
    <ellipse cx="256" cy="491" rx="208" ry="18" fill="{INK}" opacity=".25"/>
    <path d="M46 477 L46 193 C46 120 103 67 174 67 L352 67 C417 67 466 117 466 183 L466 477 Z"
          fill="#5a3d83" stroke="{INK}" stroke-width="14"/>
    <path d="M75 468 L75 201 C75 139 120 98 179 98 L345 98 C399 98 438 139 438 197 L438 468 Z"
          fill="#ffbccd" stroke="{INK}" stroke-width="10"/>
    <path d="M96 450 L96 215 C96 164 130 127 180 127 L341 127 C389 127 417 164 417 211 L417 450 Z"
          fill="#f19ab8" stroke="{INK}" stroke-width="7"/>
    <rect x="133" y="165" width="244" height="192" rx="62" fill="#2b1d41" stroke="{INK}" stroke-width="12"/>
    <path d="M160 319 L160 265 C160 215 200 189 250 189 C300 189 345 217 345 267 L345 319 Z" fill="#7ce7ff" opacity=".9"/>
    <path d="M174 306 C199 274 224 268 251 281 C281 296 305 289 333 270 L333 307 L174 307 Z" fill="#5cc3d8" opacity=".9"/>
    <circle cx="211" cy="248" r="7" fill="#fff"/><circle cx="295" cy="238" r="5" fill="#fff"/>
    <path d="M178 195 C229 169 289 174 324 198" fill="none" stroke="#fff" stroke-width="9" opacity=".55" stroke-linecap="round"/>
    <rect x="115" y="366" width="280" height="88" rx="20" fill="#f7eccf" stroke="{INK}" stroke-width="9"/>
    <text x="256" y="412" font-family="ZCOOL KuaiLe, Microsoft YaHei, sans-serif" font-size="45" fill="{INK}" text-anchor="middle">请勿叫醒</text>
    <rect x="385" y="389" width="36" height="46" rx="7" fill="#ffd447" stroke="{INK}" stroke-width="6"/>
    <circle cx="392" cy="412" r="4" fill="{INK}"/>
    <path d="M213 66 L213 26 L299 26 L299 66" fill="none" stroke="{INK}" stroke-width="10" stroke-linecap="round"/>
    <path d="M189 146 L323 146" stroke="#ff477e" stroke-width="14" stroke-linecap="round" opacity=".7"/>
    <path d="M77 220 C55 246 50 292 64 330" fill="none" stroke="#8b65bb" stroke-width="8" opacity=".65"/>
    <path d="M430 284 C450 301 453 330 444 350" fill="none" stroke="#8b65bb" stroke-width="8" opacity=".65"/>
    <path d="M140 471 C164 454 196 453 216 470" fill="#66448e" stroke="{INK}" stroke-width="6"/>
    """
    return svg(body)


def daisy() -> str:
    petals = "".join(
        f'<ellipse cx="256" cy="190" rx="28" ry="52" fill="#fff7e8" stroke="{INK}" stroke-width="6" transform="rotate({a} 256 256)"/>'
        for a in range(0, 360, 45)
    )
    body = f"""
    {petals}
    <circle cx="256" cy="256" r="48" fill="#ffd447" stroke="{INK}" stroke-width="7"/>
    {eye(239, 250, 5, 8)}
    {eye(273, 250, 5, 8)}
    <path d="M244 271 C252 278 262 278 269 271" fill="none" stroke="{INK}" stroke-width="5" stroke-linecap="round"/>
    """
    return svg(body)


def mushroom() -> str:
    body = f"""
    <path d="M186 336 L326 336 L316 451 C315 468 301 477 284 477 L228 477 C211 477 197 468 196 451 Z"
          fill="#fff3d7" stroke="{INK}" stroke-width="10"/>
    <path d="M93 337 C99 243 163 190 256 190 C351 190 413 242 419 337 Z" fill="#ff4f7b" stroke="{INK}" stroke-width="12"/>
    <circle cx="167" cy="271" r="31" fill="#fff2d7" stroke="{INK}" stroke-width="6"/>
    <circle cx="292" cy="245" r="24" fill="#fff2d7" stroke="{INK}" stroke-width="6"/>
    <circle cx="359" cy="303" r="18" fill="#fff2d7" stroke="{INK}" stroke-width="6"/>
    {eye(225, 369, 8, 12)}
    {eye(281, 369, 8, 12)}
    <path d="M238 401 C250 411 264 411 276 401" fill="none" stroke="{INK}" stroke-width="6" stroke-linecap="round"/>
    """
    return svg(body)


def tape() -> str:
    body = f"""
    <g transform="rotate(-18 256 256)">
      <path d="M95 205 L404 197 L408 315 L99 323 Z" fill="#ffe66d" stroke="{INK}" stroke-width="9"/>
      <path d="M121 220 L390 213" stroke="#fff8b8" stroke-width="9" opacity=".7"/>
      <path d="M112 202 L89 177 L123 178 L138 198 M391 198 L417 173 L381 177 L368 196" fill="#ffe66d" stroke="{INK}" stroke-width="5"/>
      <text x="253" y="286" font-family="ZCOOL KuaiLe, Microsoft YaHei, sans-serif" font-size="50" fill="{INK}" text-anchor="middle">已阅</text>
    </g>
    """
    return svg(body)


SPRITES = {
    "plant_flower": nylon_flower,
    "plant_pea": mouthpea,
    "plant_wall": wall_dragon,
    "plant_frost": frost_cup,
    "plant_fan": electric_fan,
    "plant_bomb": alarm_bomb,
    "zombie_basic": zombie_basic,
    "zombie_fast": zombie_fast,
    "zombie_paper": zombie_paper,
    "zombie_coffee": zombie_coffee,
    "zombie_boss": boss_professor,
    "mascot_nailong": mascot_nailong,
    "mascot_face": mascot_face,
    "sun": inspiration_sun,
    "projectile_speech": speech_bubble,
    "projectile_ddl": ddl_plane,
    "slipper": slipper_launcher,
    "house": house,
    "daisy": daisy,
    "mushroom": mushroom,
    "tape": tape,
}


def main() -> None:
    for name, builder in SPRITES.items():
        path = os.path.join(OUT, name + ".svg")
        with open(path, "w", encoding="utf-8") as fh:
            fh.write(builder())
        print("generated", path)


if __name__ == "__main__":
    main()
