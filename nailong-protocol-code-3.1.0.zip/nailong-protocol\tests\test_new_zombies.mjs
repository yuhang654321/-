import { chromium } from "playwright-core";
const browser = await chromium.launch({ executablePath: "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe", headless: true, args: ["--disable-gpu"] });
const page = await browser.newPage({ viewport: { width: 1600, height: 900 } });
const errs=[]; page.on("pageerror",e=>errs.push(e.message));
await page.goto("http://127.0.0.1:8000/?debug", { waitUntil: "networkidle" });
await page.waitForTimeout(2400);
const result=await page.evaluate(()=>{
  const {game:g,ui}=window.__nailong; ui.showGame(); g.startLevel(0); g.screen="playing"; g.waveActive=false; g.waveElapsed=0; g.prepTimer=60;
  g.events.onToast=()=>{}; g.events.onNotice=()=>{};
  g.sun=9999; for (const id of ["flower","pea","doublepea","wall","frost","fan","bomb","cannon","vacuum","boomerang","seal"]) g.readyAt[id]=0;
  g.placePlant("flower",2,0);
  const shield=g.spawnZombie("shield",1);
  const ranged=g.spawnZombie("ranged",0);
  const weird=g.spawnZombie("weird",0);
  ranged.x=800; ranged.attackTimer=0; ranged.baseSpeed=0; ranged.speed=0;
  weird.x=900; weird.abilityTimer=0;
  const flower=g.plants.find(p=>p.type==="flower");
  const hp=flower.hp;
  for(let i=0;i<60;i++) g.update(0.05);
  g.spawnReserve=[]; g.spawnGate=0;
  for(let i=0;i<6;i++) g.requestSpawn("basic");
  const before=g.zombies.length;
  g.update(0.01);
  const afterOne=g.zombies.length;
  for(let i=0;i<40;i++) g.update(0.05);
  return {shieldArmor:shield.armor, basicArmor:g.zombies.find(z=>z.type==="basic")?.armor, rangedArmor:ranged.armor, weirdArmor:weird.armor, flowerHpBefore:hp, flowerHpAfter:flower.hp, beforeSpawn:before, afterOneSpawn:afterOne, afterReserve:g.zombies.length, errs:[]};
});
console.log(JSON.stringify(result,null,2)); console.log("errs",errs);
await page.screenshot({path:"demo/new-enemies.png"});
const ok = result.shieldArmor > 100 && result.flowerHpAfter < result.flowerHpBefore && result.afterOneSpawn <= result.beforeSpawn + 1 && result.afterReserve > result.beforeSpawn && errs.length === 0;
if (!ok) {
  console.error("FAIL new zombies / spawn gate"); process.exitCode = 1;
} else {
  console.log("PASS new zombies + staggered spawns");
}
await browser.close();
