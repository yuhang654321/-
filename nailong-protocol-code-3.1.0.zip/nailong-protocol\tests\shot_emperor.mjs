import { chromium } from "playwright-core";
import { resolve } from "node:path";
const root = resolve(import.meta.dirname, "..");
const browser = await chromium.launch({ executablePath: "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe", headless: true, args: ["--disable-gpu"] });
const page = await browser.newPage({ viewport: { width: 1600, height: 900 } });
const errors = [];
page.on("console", (m) => { if (m.type() === "error") errors.push(m.text()); });
page.on("pageerror", (e) => errors.push(e.message));
await page.goto("http://127.0.0.1:8000/?debug", { waitUntil: "networkidle" });
await page.waitForTimeout(2400);
await page.click("#start-btn");
await page.waitForTimeout(250);
await page.evaluate(() => {
  const { game, ui } = window.__nailong;
  ui.showGame();
  game.audio.ensure();
  game.startLevel(14);
  game.sun = 9999;
  const spots = [
    ["flower", 0, 0], ["flower", 0, 4], ["pea", 1, 0], ["pea", 1, 3],
    ["wall", 3, 1], ["wall", 3, 4], ["frost", 2, 2], ["fan", 2, 4],
    ["cannon", 4, 1], ["vacuum", 4, 3], ["boomerang", 3, 2], ["seal", 4, 2],
  ];
  for (const [type, col, row] of spots) { game.readyAt[type] = 0; game.placePlant(type, col, row); }
  game.spawnZombie("emperor", 2);
  game.spawnZombie("paper", 1);
  game.spawnZombie("fast", 3);
  game.spawnZombie("coffee", 4);
  for (const z of game.zombies) z.x = 1000 + Math.random() * 60;
  game.wave = 5;
  game.stats.kills = 44;
  game.stats.plantsPlaced = 12;
  game.waveActive = true;
  game.sun = 425;
  game.texts = [];
  game.events.onToast = () => {};
  game.currentEvent = { title: "早八皇帝", line: "玉玺落下的声音，像查重通过。", modifier: "sunstorm", source: "llm" };
  window.__nailong.ui.setDialogue("早八皇帝亲临。玉玺落下的声音，像查重通过。");
});
await page.click('[data-action="vision"]');
await page.waitForTimeout(18000);
await page.evaluate(() => {
  const g = window.__nailong.game;
  g.pause();
  g.texts = [];
  for (const id of ["flower", "pea", "wall", "frost", "fan", "bomb", "cannon", "vacuum", "boomerang", "seal"]) g.readyAt[id] = 0;
  document.querySelector("#toast-layer").innerHTML = "";
});
await page.waitForTimeout(250);
await page.screenshot({ path: resolve(root, "demo", "emperor-v2.png") });
console.log("errors", errors, "zombies", await page.evaluate(() => window.__nailong.game.zombies.map(z => z.type)));
await browser.close();
