import type {
  DirectorEvent,
  LevelDef,
  ModifierId,
  PlantDef,
  PlantId,
  WaveDef,
  ZombieDef,
  ZombieId,
} from "../types";

export const STAGE_W = 1600;
export const STAGE_H = 900;

export const BOARD = {
  x: 250,
  y: 168,
  cols: 12,
  rows: 6,
  cw: 946 / 12,
  ch: 520 / 6,
  get w() {
    return this.cols * this.cw;
  },
  get h() {
    return this.rows * this.ch;
  },
  get right() {
    return this.x + this.cols * this.cw;
  },
  get bottom() {
    return this.y + this.rows * this.ch;
  },
};

export const HOUSE = { x: 92, y: BOARD.y, w: 168, h: BOARD.h };

export const START_SUN = 200;
export const TOTAL_WAVES = 10;
export const AIU_RED = "#ff3d8d";
export const ACID = "#dfff43";
export const CREAM = "#fff4d6";
export const INK = "#1c102c";

export const PLANT_ORDER: PlantId[] = [
  "flower",
  "pea",
  "doublepea",
  "wall",
  "frost",
  "fan",
  "bomb",
  "cannon",
  "vacuum",
  "boomerang",
  "seal",
];

export const PLANTS: Record<PlantId, PlantDef> = {
  flower: {
    id: "flower",
    name: "奶龙花",
    en: "NAILONG BLOOM",
    role: "灵感",
    cost: 50,
    cooldown: 4,
    hp: 300,
    sprite: "plant_flower",
    color: "#ffd447",
    accent: "#ff9b45",
    glyph: "☀",
    desc: "每 8 秒挤出 25 点灵感。它不会光合作用，只会表演。",
  },
  pea: {
    id: "pea",
    name: "单发嘴替",
    en: "SINGLE MOUTH",
    role: "射手",
    cost: 100,
    cooldown: 5,
    hp: 300,
    sprite: "plant_pea",
    color: "#bff36a",
    accent: "#5da12d",
    glyph: "“",
    desc: "正常打僵尸，每发 24 点。但如果和双发嘴替同路，两人会先放下僵尸，生气地解决对方。",
  },
  doublepea: {
    id: "doublepea",
    name: "双发嘴替",
    en: "DOUBLE MOUTH",
    role: "双内鬼",
    cost: 175,
    cooldown: 8,
    hp: 320,
    sprite: "plant_doublepea",
    color: "#bff36a",
    accent: "#ff3d8d",
    glyph: "“”",
    desc: "两颗头同时开麦，每 1.8 秒向本行最近的两名友军各喷一发 10 点伤害。和单发嘴替同路时，会先和它内讧。",
  },
  wall: {
    id: "wall",
    name: "奶龙叠叠墙",
    en: "NAILONG STACK",
    role: "资敌",
    cost: 50,
    cooldown: 11,
    hp: 1250,
    sprite: "plant_wall",
    color: "#ffc93d",
    accent: "#d18a15",
    glyph: "▣",
    desc: "三层奶龙叠在一起负责挨骂。被僵尸啃时会偷偷给僵尸回血，还把对方喂得走慢一点。",
  },
  frost: {
    id: "frost",
    name: "冰杯奶龙",
    en: "ICED NAP",
    role: "控制",
    cost: 150,
    cooldown: 9,
    hp: 300,
    sprite: "plant_frost",
    color: "#69e7ff",
    accent: "#249fce",
    glyph: "❄",
    desc: "冰美式成精。命中后减速 50%，顺便嘲笑你的作息。",
  },
  fan: {
    id: "fan",
    name: "风扇奶龙",
    en: "WIND GOD",
    role: "群攻",
    cost: 125,
    cooldown: 16,
    hp: 280,
    sprite: "plant_fan",
    color: "#7dffd0",
    accent: "#19a986",
    glyph: "≋",
    desc: "每 5 秒向整行吹一次三档妖风。吹不动生活，吹得动僵尸。",
  },
  bomb: {
    id: "bomb",
    name: "闹钟奶龙",
    en: "8AM NUKE",
    role: "爆发",
    cost: 150,
    cooldown: 24,
    hp: 9999,
    sprite: "plant_bomb",
    color: "#ff5d6c",
    accent: "#bd273c",
    glyph: "!",
    desc: "引信 1.2 秒，3×3 范围爆炸。它响的那一刻，全宿舍都醒了。",
  },
  cannon: {
    id: "cannon",
    name: "奶龙炮",
    en: "BOBA ARTILLERY",
    role: "抛射",
    cost: 175,
    cooldown: 14,
    hp: 320,
    sprite: "plant_cannon",
    color: "#ffb347",
    accent: "#d0731b",
    glyph: "◉",
    desc: "锁定本行最远的僵尸，把奶茶珍珠抛过去。落点小范围爆炸，珍珠不回收。",
  },
  vacuum: {
    id: "vacuum",
    name: "吸尘奶龙",
    en: "VACUUM GULP",
    role: "推回",
    cost: 125,
    cooldown: 12,
    hp: 300,
    sprite: "plant_vacuum",
    color: "#c9a3ff",
    accent: "#7f52b8",
    glyph: "◌",
    desc: "每 6 秒把本行僵尸往右吸回去一点。它只吸早八，不吸 DDL。",
  },
  boomerang: {
    id: "boomerang",
    name: "回旋奶龙",
    en: "COMEBACK DRAGON",
    role: "穿透",
    cost: 150,
    cooldown: 10,
    hp: 300,
    sprite: "plant_boomerang",
    color: "#bff8ff",
    accent: "#36b6d2",
    glyph: "↩",
    desc: "回旋镖去一次、回一次，来回都算伤害。像你的假期。",
  },
  seal: {
    id: "seal",
    name: "玉玺奶龙",
    en: "JADE SEAL",
    role: "终极",
    cost: 250,
    cooldown: 30,
    hp: 600,
    sprite: "plant_seal",
    color: "#9ff2c6",
    accent: "#2c8c65",
    glyph: "玺",
    desc: "每隔 7 秒盖一次章：3×3 范围伤害并短暂眩晕。受命于天，既寿永昌。",
  },
};

export const ZOMBIES: Record<ZombieId, ZombieDef> = {
  basic: {
    id: "basic",
    name: "早八人",
    en: "THE 8AM",
    hp: 210,
    armor: 0,
    speed: 24,
    dps: 58,
    reward: 10,
    sprite: "zombie_basic",
    color: "#aec18c",
    scale: 1,
    desc: "连帽睡衣、睡眠眼罩、手机。昨晚两点睡，今早八点起，怨气就是燃料。",
  },
  fast: {
    id: "fast",
    name: "滑板人",
    en: "SKATE OR DIE",
    hp: 150,
    armor: 0,
    speed: 46,
    dps: 52,
    reward: 12,
    sprite: "zombie_fast",
    color: "#ff5f8d",
    scale: 1,
    desc: "反戴帽、耳机、护膝、粉色滑板。滑板是借的，命是自己的。",
  },
  paper: {
    id: "paper",
    name: "论文僵尸",
    en: "DRAFT 17",
    hp: 230,
    armor: 260,
    speed: 21,
    dps: 54,
    reward: 18,
    sprite: "zombie_paper",
    color: "#f6e8c9",
    scale: 1.02,
    desc: "圆眼镜、发髻、DRAFT 17。身上糊了 17 版修改稿，护甲很厚，内容很空。",
  },
  coffee: {
    id: "coffee",
    name: "续命人",
    en: "CAFFEINE GHOUL",
    hp: 300,
    armor: 0,
    speed: 27,
    dps: 64,
    reward: 16,
    sprite: "zombie_coffee",
    color: "#c78651",
    scale: 1.03,
    desc: "棕开衫、冰咖啡、吸管、手抖线。血越少，手越抖，走得越快。咖啡洒了，命也洒了。",
  },
  shield: {
    id: "shield",
    name: "盾牌学生",
    en: "SHIELD KID",
    hp: 300,
    armor: 420,
    speed: 15,
    dps: 60,
    reward: 22,
    sprite: "zombie_shield",
    color: "#8e9cba",
    scale: 1.08,
    desc: "军训盾牌 + 铁皮书包。护甲极厚，走得慢，专门替后排挡嘴替。",
  },
  ranged: {
    id: "ranged",
    name: "后排投手",
    en: "BACK ROW",
    hp: 210,
    armor: 40,
    speed: 19,
    dps: 50,
    reward: 20,
    sprite: "zombie_ranged",
    color: "#ffb347",
    scale: 1,
    desc: "站在后排往植物堆里扔作业。不会贴脸，会远程消耗你的防线。",
  },
  weird: {
    id: "weird",
    name: "抽象学生",
    en: "WEIRD KID",
    hp: 260,
    armor: 60,
    speed: 22,
    dps: 55,
    reward: 20,
    sprite: "zombie_weird",
    color: "#c9a3ff",
    scale: 1.03,
    desc: "每几秒随机抽象一下：瞬移、突然加速或给自己套一层看不懂的护甲。",
  },
  boss: {
    id: "boss",
    name: "终审导师",
    en: "THE FINAL BOSS",
    hp: 2600,
    armor: 500,
    speed: 11,
    dps: 150,
    reward: 150,
    sprite: "zombie_boss",
    color: "#ff334f",
    scale: 1.62,
    desc: "学位帽、圆眼镜、红笔、DDL 印章。终审答辩形态，眼里没有你。",
  },
  emperor: {
    id: "emperor",
    name: "早八皇帝",
    en: "THE 8AM EMPEROR",
    hp: 5200,
    armor: 900,
    speed: 9,
    dps: 185,
    reward: 350,
    sprite: "zombie_emperor",
    color: "#ffd447",
    scale: 1.9,
    desc: "冕旒、玉玺、八点整。它不是来上课的，它是来受命的。",
  },
};

const wave = (
  index: number,
  name: string,
  subtitle: string,
  groups: WaveDef["groups"],
  hpScale: number,
  breakAfter = 7,
): WaveDef => ({ index, name, subtitle, groups, hpScale, breakAfter });

export const WAVES: WaveDef[] = [
  wave(1, "开学第一天", "新生还在找教学楼，僵尸已经找到你了。", [{ type: "basic", count: 4, start: 2, gap: 4.2 }], 0.9),
  wave(2, "闹钟没响", "它们不是来上课的，它们是来补觉的。", [
    { type: "basic", count: 6, start: 1, gap: 3.2 },
    { type: "fast", count: 1, start: 17, gap: 2 },
  ], 0.95),
  wave(3, "早八点名", "点名册上全是你的名字。", [
    { type: "basic", count: 7, start: 1, gap: 2.8 },
    { type: "paper", count: 1, start: 12, gap: 2 },
  ], 1),
  wave(4, "论文截稿", "第 17 版比第 1 版更厚，也更没用。", [
    { type: "fast", count: 4, start: 1, gap: 3.6 },
    { type: "paper", count: 2, start: 8, gap: 5 },
    { type: "coffee", count: 1, start: 18, gap: 2 },
  ], 1.05),
  wave(5, "导师巡视", "他只看了一眼，你的模型就开始过拟合。", [
    { type: "basic", count: 4, start: 1, gap: 3.4 },
    { type: "boss", count: 1, start: 8, gap: 2, boss: true },
    { type: "fast", count: 2, start: 24, gap: 4 },
  ], 1.08, 9),
  wave(6, "咖啡因超标", "心跳 140，步频 180，灵魂 0。", [
    { type: "coffee", count: 4, start: 1, gap: 4.2 },
    { type: "fast", count: 5, start: 6, gap: 3.1 },
    { type: "paper", count: 2, start: 18, gap: 4 },
  ], 1.12),
  wave(7, "小组作业", "五个人，一个人干活，四个人署名。", [
    { type: "basic", count: 8, start: 1, gap: 2.2 },
    { type: "paper", count: 3, start: 9, gap: 3.6 },
    { type: "coffee", count: 2, start: 18, gap: 4 },
  ], 1.16),
  wave(8, "宿舍停电", "风扇停了，但僵尸没有。", [
    { type: "fast", count: 8, start: 1, gap: 2.5 },
    { type: "basic", count: 5, start: 9, gap: 3.3 },
    { type: "paper", count: 3, start: 17, gap: 4.2 },
  ], 1.2),
  wave(9, "期末周", "走廊里全是人，没一个在睡觉。", [
    { type: "basic", count: 10, start: 1, gap: 2 },
    { type: "coffee", count: 4, start: 7, gap: 3.2 },
    { type: "fast", count: 6, start: 13, gap: 2.6 },
    { type: "paper", count: 4, start: 18, gap: 3.8 },
  ], 1.24),
  wave(10, "终极答辩", "评委席坐了五个导师。你只有一排植物。", [
    { type: "boss", count: 1, start: 2, gap: 2, boss: true },
    { type: "paper", count: 4, start: 5, gap: 4.5 },
    { type: "coffee", count: 4, start: 10, gap: 3.6 },
    { type: "fast", count: 8, start: 14, gap: 2.4 },
    { type: "basic", count: 6, start: 20, gap: 2.8 },
  ], 1.32, 10),
];

// ---------------------------------------------------------------------------
// 15-level campaign
// ---------------------------------------------------------------------------
const lw = (
  name: string,
  subtitle: string,
  groups: WaveDef["groups"],
  hpScale: number,
  breakAfter = 6,
): WaveDef => ({ index: 0, name, subtitle, groups, hpScale, breakAfter });

const level = (
  index: number,
  name: string,
  codename: string,
  subtitle: string,
  desc: string,
  difficulty: number,
  rule: ModifierId,
  startSun: number,
  houseHp: number,
  waves: WaveDef[],
  boss: boolean,
  accent: string,
  stamp: string,
): LevelDef => ({
  id: `L${String(index).padStart(2, "0")}`,
  index,
  name,
  codename,
  subtitle,
  desc,
  difficulty,
  rule,
  startSun,
  houseHp,
  waves: waves.map((w, i) => ({ ...w, index: i + 1 })),
  boss,
  accent,
  stamp,
});

export const LEVELS: LevelDef[] = [
  level(1, "开学第一天", "FIRST BELL", "先学会把奶龙种下去。", "两条短波，基础早八人。适合第一次开机。", 1, "none", 250, 100, [
    lw("新生报到", "它们还在找教学楼。", [{ type: "basic", count: 3, start: 2, gap: 4.5 }], 0.55),
    lw("找到你了", "教学楼没找到，你的床找到了。", [{ type: "basic", count: 4, start: 1, gap: 3.8 }, { type: "fast", count: 1, start: 14, gap: 2 }], 0.6),
  ], false, "#dfff43", "START"),
  level(2, "闹钟没响", "SNOOZE", "快的人先到，没睡醒的人先死。", "滑板人开始出现。先种奶龙花，再补嘴替奶龙。", 1, "none", 250, 100, [
    lw("再睡五分钟", "五分钟等于一整个早八。", [{ type: "basic", count: 5, start: 1, gap: 3.2 }, { type: "fast", count: 1, start: 13, gap: 2 }], 0.65),
    lw("迟到了", "滑板是借的，命是自己的。", [{ type: "fast", count: 4, start: 1, gap: 3.1 }, { type: "basic", count: 3, start: 9, gap: 3 }], 0.7),
  ], false, "#69e7ff", "SPEED"),
  level(3, "早八点名", "ROLL CALL", "点名册上全是你的名字。", "论文僵尸第一次带着护甲出现。用嘴替奶龙磨掉纸。", 2, "none", 225, 100, [
    lw("点到你了", "答到，或者倒下。", [{ type: "basic", count: 6, start: 1, gap: 2.8 }], 0.75),
    lw("代课老师", "它带着第 1 版论文。", [{ type: "paper", count: 2, start: 2, gap: 4.5 }, { type: "basic", count: 4, start: 5, gap: 3.2 }], 0.8),
    lw("平时分", "平时分是零，怨气是一百。", [{ type: "basic", count: 4, start: 1, gap: 3 }, { type: "paper", count: 2, start: 8, gap: 4 }], 0.85),
  ], false, "#ffd447", "PAPER"),
  level(4, "食堂插队", "CANTEEN CUT", "跑得最快的人，先吃到最难吃的饭。", "滑板人和咖啡人混合冲锋。奶龙炮可以隔排抛射。", 2, "speed", 250, 100, [
    lw("开饭了", "它们端着空盘子。", [{ type: "fast", count: 4, start: 1, gap: 3.4 }, { type: "basic", count: 3, start: 8, gap: 3 }], 0.8),
    lw("插队", "你排了二十分钟，它插到你前面。", [{ type: "coffee", count: 2, start: 1, gap: 4.5 }, { type: "fast", count: 4, start: 6, gap: 2.8 }], 0.86),
    lw("只剩汤了", "汤也是饭。", [{ type: "basic", count: 5, start: 1, gap: 2.6 }, { type: "fast", count: 4, start: 7, gap: 2.4 }], 0.9),
  ], false, "#ff9b45", "RUSH"),
  level(5, "导师巡视", "ADVISOR", "他只看了一眼，你的模型就开始过拟合。", "第一场导师战。带护甲的终审导师会远程投掷 DDL。", 3, "none", 275, 100, [
    lw("推门", "门没敲，心先停。", [{ type: "basic", count: 5, start: 1, gap: 3 }], 0.95),
    lw("看代码", "他看不懂，但他说不行。", [{ type: "paper", count: 2, start: 1, gap: 4 }, { type: "fast", count: 2, start: 7, gap: 3 }], 1),
    lw("终审", "这一版还是不行。", [{ type: "boss", count: 1, start: 2, gap: 2, boss: true }, { type: "basic", count: 3, start: 8, gap: 3.2 }], 1.02, 8),
  ], true, "#ff5d6c", "BOSS"),
  level(6, "论文截稿", "DEADLINE", "第 17 版比第 1 版更厚，也更没用。", "论文护甲大幅增加。玉玺奶龙还没出土，先用嘴替和风扇。", 3, "tank", 250, 100, [
    lw("初稿", "先交一版，反正还要改。", [{ type: "paper", count: 3, start: 1, gap: 4 }], 1),
    lw("查重", "重复率 98%，剩 2% 是致谢。", [{ type: "paper", count: 3, start: 1, gap: 3.6 }, { type: "basic", count: 4, start: 6, gap: 2.8 }], 1.06),
    lw("终稿", "终稿的意思是最后还要改。", [{ type: "paper", count: 4, start: 1, gap: 3.4 }, { type: "coffee", count: 2, start: 10, gap: 3.6 }], 1.1),
  ], false, "#fff4d6", "ARMOR"),
  level(7, "宿舍停电", "BLACKOUT", "风扇停了，但僵尸没有。", "浓雾笼罩苗圃。回旋奶龙和风扇奶龙视野更值钱。", 3, "fog", 275, 100, [
    lw("跳闸", "空调和风扇一起没了。", [{ type: "fast", count: 5, start: 1, gap: 2.8 }, { type: "basic", count: 3, start: 7, gap: 3 }], 1.05),
    lw("摸黑", "看不清，但听得到咀嚼。", [{ type: "coffee", count: 3, start: 1, gap: 4 }, { type: "fast", count: 4, start: 7, gap: 2.6 }], 1.1),
    lw("蜡烛", "点了一根，照见一排牙。", [{ type: "paper", count: 3, start: 1, gap: 3.8 }, { type: "fast", count: 5, start: 8, gap: 2.4 }], 1.14),
  ], false, "#8e9cba", "FOG"),
  level(8, "小组作业", "GROUP WORK", "五个人，一个人干活，四个人署名。", "本关种植五折。多出来的预算，用来买第二个奶龙叠叠墙。", 3, "discount", 225, 100, [
    lw("拉群", "群名：期末必胜。", [{ type: "basic", count: 6, start: 1, gap: 2.6 }, { type: "paper", count: 2, start: 8, gap: 4 }], 1.1),
    lw("分工", "你负责全部，他们负责点头。", [{ type: "coffee", count: 3, start: 1, gap: 4 }, { type: "fast", count: 4, start: 6, gap: 2.6 }], 1.15),
    lw("署名", "最后一个人把名字写在你上面。", [{ type: "paper", count: 4, start: 1, gap: 3.4 }, { type: "fast", count: 5, start: 9, gap: 2.2 }], 1.18),
  ], false, "#ff78b7", "50% OFF"),
  level(9, "咖啡因超标", "OVERCAFFEINATED", "心跳 140，步频 180，灵魂 0。", "所有僵尸加速 20%。吸尘奶龙能把它们吸回起跑线。", 4, "speed", 275, 100, [
    lw("第三杯", "手在抖，但还能签。", [{ type: "coffee", count: 4, start: 1, gap: 3.4 }, { type: "fast", count: 4, start: 7, gap: 2.3 }], 1.15),
    lw("心悸", "心脏在打拍子。", [{ type: "fast", count: 7, start: 1, gap: 2.1 }, { type: "coffee", count: 3, start: 8, gap: 3 }], 1.2),
    lw("通宵", "天亮了，论文没亮。", [{ type: "coffee", count: 5, start: 1, gap: 3 }, { type: "fast", count: 6, start: 8, gap: 2 }], 1.24),
  ], false, "#c78651", "TURBO"),
  level(10, "期末周", "FINALS", "走廊里全是人，没一个在睡觉。", "期末周的四波混合大军。奶龙炮 + 风扇奶龙清群。", 4, "tank", 300, 100, [
    lw("复习周", "复习从第一页开始。", [{ type: "basic", count: 8, start: 1, gap: 2.2 }], 1.2),
    lw("通宵周", "图书馆的灯比你亮。", [{ type: "coffee", count: 4, start: 1, gap: 3 }, { type: "fast", count: 5, start: 6, gap: 2.2 }], 1.24),
    lw("考试周", "会的不考，考的不会。", [{ type: "paper", count: 5, start: 1, gap: 3 }, { type: "basic", count: 6, start: 8, gap: 2.4 }], 1.28),
    lw("补考周", "补考在开学第一天。", [{ type: "boss", count: 1, start: 1, gap: 2, boss: true }, { type: "fast", count: 5, start: 8, gap: 2.4 }, { type: "paper", count: 3, start: 15, gap: 3.6 }], 1.32, 8),
  ], true, "#a78bfa", "BOSS"),
  level(11, "毕业答辩", "DEFENSE", "你准备了四年，他们问了五分钟。", "玉玺奶龙已解锁。用盖章把评委席按住。", 4, "none", 325, 100, [
    lw("致谢", "先感谢自己还活着。", [{ type: "basic", count: 6, start: 1, gap: 2.6 }, { type: "paper", count: 3, start: 8, gap: 3.6 }], 1.25),
    lw("提问", "这个问题不在你的 PPT 里。", [{ type: "coffee", count: 4, start: 1, gap: 3.4 }, { type: "fast", count: 5, start: 7, gap: 2.4 }], 1.3),
    lw("投票", "三票通过，两票建议延毕。", [{ type: "paper", count: 4, start: 1, gap: 3.2 }, { type: "boss", count: 1, start: 8, gap: 2, boss: true }], 1.34, 8),
    lw("拨穗", "穗被拨了，人还没醒。", [{ type: "fast", count: 8, start: 1, gap: 2 }, { type: "coffee", count: 4, start: 9, gap: 2.8 }], 1.38),
  ], true, "#9ff2c6", "SEAL"),
  level(12, "玉玺出土", "THE SEAL", "受命于天，既寿永昌。", "浓雾 + 重甲。玉玺奶龙的印章可以同时清掉一小片纸。", 4, "fog", 300, 90, [
    lw("考古", "挖出一块会呼吸的玉。", [{ type: "paper", count: 4, start: 1, gap: 3.4 }, { type: "basic", count: 6, start: 7, gap: 2.4 }], 1.35),
    lw("认主", "玉玺选择了早八。", [{ type: "coffee", count: 5, start: 1, gap: 3.2 }, { type: "fast", count: 6, start: 7, gap: 2.2 }], 1.4),
    lw("盖戳", "你的论文被盖了退回。", [{ type: "paper", count: 5, start: 1, gap: 3 }, { type: "boss", count: 1, start: 6, gap: 2, boss: true }, { type: "fast", count: 4, start: 14, gap: 2.4 }], 1.44, 8),
  ], true, "#7fd6ac", "FOG+SEAL"),
  level(13, "平行早八", "PARALLEL 8AM", "平行世界的你也来了，他也没写作业。", "速度 + 克隆压力。吸尘奶龙和冰冻奶龙是节奏核心。", 5, "speed", 300, 90, [
    lw("另一个你", "他迟到了，但比你早。", [{ type: "fast", count: 7, start: 1, gap: 2.2 }, { type: "coffee", count: 4, start: 8, gap: 2.8 }], 1.4),
    lw("两个你", "两个你一起拖延。", [{ type: "basic", count: 8, start: 1, gap: 2.2 }, { type: "paper", count: 4, start: 8, gap: 3.2 }], 1.44),
    lw("三个你", "三个你开始互相等。", [{ type: "fast", count: 8, start: 1, gap: 2 }, { type: "coffee", count: 5, start: 8, gap: 2.6 }], 1.48),
    lw("无穷你", "总有一个你在睡觉。", [{ type: "boss", count: 1, start: 1, gap: 2, boss: true }, { type: "fast", count: 9, start: 6, gap: 2 }, { type: "paper", count: 5, start: 14, gap: 3 }], 1.52, 8),
  ], true, "#69e7ff", "MIRROR"),
  level(14, "冕旒降临", "THE CROWN", "皇帝还没开口，早八已经开始了。", "早八皇帝的预演。它会用玉玺砸植物，并召唤论文。", 5, "tank", 325, 90, [
    lw("仪仗", "队伍很长，没有一个人醒着。", [{ type: "paper", count: 5, start: 1, gap: 3 }, { type: "basic", count: 7, start: 7, gap: 2.2 }], 1.5),
    lw("冕旒", "珠子响了，像点名。", [{ type: "coffee", count: 5, start: 1, gap: 3.2 }, { type: "fast", count: 7, start: 7, gap: 2.2 }], 1.54),
    lw("玉玺", "它把玉玺放在你的论文上。", [{ type: "boss", count: 1, start: 2, gap: 2, boss: true }, { type: "paper", count: 4, start: 9, gap: 3.2 }], 1.58, 8),
    lw("早朝", "大臣到齐，你还没醒。", [{ type: "fast", count: 8, start: 1, gap: 2 }, { type: "coffee", count: 5, start: 7, gap: 2.6 }, { type: "paper", count: 4, start: 13, gap: 3 }], 1.62),
  ], true, "#ffd447", "PRE-BOSS"),
  level(15, "传国玉玺", "THE EMPEROR", "受命于天，既寿永昌。早八皇帝亲自来了。", "最终五波。奶龙帝国的全部变体与全部敌人一起上。守住你的床。", 5, "sunstorm", 350, 100, [
    lw("百官", "百官到齐，早八开始。", [{ type: "paper", count: 6, start: 1, gap: 2.8 }, { type: "basic", count: 8, start: 8, gap: 2 }], 1.55),
    lw("禁军", "禁军穿着拖鞋。", [{ type: "fast", count: 9, start: 1, gap: 1.9 }, { type: "coffee", count: 5, start: 8, gap: 2.4 }], 1.6),
    lw("玉玺", "玉玺落下的声音，像查重通过。", [{ type: "paper", count: 6, start: 1, gap: 2.6 }, { type: "boss", count: 1, start: 7, gap: 2, boss: true }], 1.66, 8),
    lw("冕旒", "冕旒后面没有脸，只有早八。", [{ type: "fast", count: 10, start: 1, gap: 1.8 }, { type: "paper", count: 5, start: 8, gap: 2.6 }], 1.72),
    lw("早八皇帝", "朕即早八。", [{ type: "emperor", count: 1, start: 1, gap: 2, boss: true }, { type: "paper", count: 4, start: 6, gap: 3.4 }, { type: "fast", count: 8, start: 12, gap: 2 }, { type: "coffee", count: 5, start: 20, gap: 2.4 }], 1.8, 10),
  ], true, "#ff3d8d", "FINAL"),
];

export const MODIFIERS: Record<ModifierId, { label: string; color: string; blurb: string }> = {  none: { label: "无事发生", color: "#dfff43", blurb: "奶龙今天没吃药。" },
  sunstorm: { label: "灵感暴雨", color: "#ffd447", blurb: "天上掉灵感，捡就完事。" },
  fog: { label: "早八雾霾", color: "#8e9cba", blurb: "看不清，但还是要防。" },
  discount: { label: "五折抽象", color: "#ff78b7", blurb: "全场种植五折，仅限本波。" },
  speed: { label: "全员加速", color: "#ff5d6c", blurb: "僵尸步频 +20%，像赶 DDL。" },
  tank: { label: "论文加厚", color: "#f6e8c9", blurb: "本波僵尸血量 +25%。" },
  heal: { label: "奶龙舔舐", color: "#6ff2a1", blurb: "所有植物回复 35% 生命。" },
  paper: { label: "论文空袭", color: "#fff4d6", blurb: "额外掉落两只论文僵尸。" },
  gold: { label: "天降横财", color: "#ffd447", blurb: "立即获得 100 灵感。" },
  clone: { label: "平行早八", color: "#a78bfa", blurb: "平行世界的你也来排队了。" },
  blessing: { label: "奶龙保佑", color: "#ffd447", blurb: "所有植物获得 150 点护盾。" },
};

export const FALLBACK_EVENTS: Record<Exclude<ModifierId, "none">, DirectorEvent> = {
  sunstorm: {
    title: "灵感暴雨",
    line: "天上开始掉灵感了。别抬头，张嘴就行。",
    modifier: "sunstorm",
    source: "fallback",
  },
  fog: {
    title: "早八雾霾",
    line: "雾大到看不清未来，也看不清僵尸。问题不大。",
    modifier: "fog",
    source: "fallback",
  },
  discount: {
    title: "五折抽象",
    line: "今天全场五折。奶龙的商业版图只维持一波。",
    modifier: "discount",
    source: "fallback",
  },
  speed: {
    title: "全员加速",
    line: "它们喝了你的冰美式。现在跑得比 DDL 还快。",
    modifier: "speed",
    source: "fallback",
  },
  tank: {
    title: "论文加厚",
    line: "论文又加了一版。硬了，真的硬了。",
    modifier: "tank",
    source: "fallback",
  },
  heal: {
    title: "奶龙舔舐",
    line: "奶龙挨个舔了你的植物。别嫌脏，回血了。",
    modifier: "heal",
    source: "fallback",
  },
  paper: {
    title: "论文空袭",
    line: "天上开始下论文了。快躲，不要接。",
    modifier: "paper",
    source: "fallback",
  },
  gold: {
    title: "天降横财",
    line: "地上有钱。不是你的，但现在可以是。",
    modifier: "gold",
    source: "fallback",
  },
  clone: {
    title: "平行早八",
    line: "平行世界的你也来了。他也没写作业。",
    modifier: "clone",
    source: "fallback",
  },
  blessing: {
    title: "奶龙保佑",
    line: "奶龙批准你暂时活着。护盾已到账。",
    modifier: "blessing",
    source: "fallback",
  },
};

export const MODIFIER_POOL: Exclude<ModifierId, "none">[] = [
  "sunstorm",
  "fog",
  "discount",
  "speed",
  "tank",
  "heal",
  "paper",
  "gold",
  "clone",
  "blessing",
];

export const IDLE_LINES = [
  "别慌。慌也没用。",
  "你的阵型很有想法，就是没有防御。",
  "植物在打架，你在发呆。很好，保持。",
  "如果守不住，就假装这是行为艺术。",
  "早八不是病，防起来要命。",
  "我算过了，你还有 0 条退路。",
  "不要害怕失败。失败会一直陪着你。",
  "刚刚那一下很帅。我没看见。",
  "宿管阿姨是你最后的尊严。省着点用。",
  "你种的不是植物，是拖延症。",
  "再点一下，人生不会变好，但植物会。",
  "理论上你能赢。理论上。",
];

export const WAVE_TAUNTS: Record<number, string> = {
  1: "第一批早八人已出笼。它们眼里没有光，只有签到码。",
  2: "闹钟没响，但僵尸响了。",
  3: "点名了。点到谁，谁就是下一个。",
  4: "论文截稿，僵尸的护甲是第 17 版修改稿。",
  5: "导师来了。别看他的眼睛，看他的 DDL。",
  6: "咖啡因超标。它们的心跳比你的人生规划还快。",
  7: "小组作业僵尸：一个人干活，四个人署名。",
  8: "停电了。风扇不转，但你的植物还得转。",
  9: "期末周。走廊里全是人，没一个在睡觉。",
  10: "终极答辩。五位导师，一排植物。开始吧。",
};

export const CHAT_CHIPS = ["现在几点", "1+1 等于几", "这关怎么打", "妈妈求求你", "姐姐帮帮我", "姐姐在吗", "夸我", "来点狠的", "讲个冷笑话", "今天有什么新闻"];

export const CHAT_FALLBACK: Record<string, string> = {
  夸我: "你的阵型像一场灾难，但是一场有预算的灾难。",
  来点狠的: "我已经把难度调高了。别谢我，谢早八。",
  解释规则: "种植物，攒灵感，别让僵尸碰到左边。左边那排门后面是你仅剩的睡眠。",
  我该种什么: "先种奶龙花，再种嘴替豆。墙不是装饰，是尊严。",
  讲个冷笑话: "为什么早八人不怕冷？因为他们已经心死了。",
  姐姐在吗: "……在。叫得这么顺口，先给你记 30 灵感，等网络恢复再补。",
  今天有什么新闻: "我现在离线，新闻只看到早八人又在排队。等本地大脑联网了，我再给你查点真的。",
};

export const BOSS_LINES = [
  "这一版还是不行。",
  "工作量不饱和。",
  "下周一把终稿发我。",
  "你这个创新点在哪里？",
  "先别毕业了，再改改。",
  "格式不对，重排。",
];

export function getWave(index: number): WaveDef {
  return WAVES[Math.max(0, Math.min(index - 1, WAVES.length - 1))];
}

export function totalSpawnCount(w: WaveDef): number {
  return w.groups.reduce((acc, g) => acc + g.count, 0);
}
