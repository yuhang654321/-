/**
 * Tiny procedural soundtrack.  No audio files, no network, no licensing
 * treasure hunt: the entire score is oscillators, noise and a very cheap
 * plate reverb generated at boot.
 */
export class AudioEngine {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private musicBus: GainNode | null = null;
  private sfxBus: GainNode | null = null;
  private delay: DelayNode | null = null;
  private noiseBuffer: AudioBuffer | null = null;
  private scheduler: number | null = null;
  private nextNote = 0;
  private step = 0;
  private started = false;
  private muted = false;
  private musicOn = true;
  private voiceOn = false;
  private intensity = 0;

  ensure(): AudioContext | null {
    if (this.ctx) {
      if (this.ctx.state === "suspended") void this.ctx.resume();
      return this.ctx;
    }
    const Ctor = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!Ctor) return null;
    const ctx = new Ctor();
    this.ctx = ctx;
    const master = ctx.createGain();
    master.gain.value = this.muted ? 0 : 0.72;
    master.connect(ctx.destination);
    this.master = master;

    const music = ctx.createGain();
    music.gain.value = 0.26;
    music.connect(master);
    this.musicBus = music;

    const sfx = ctx.createGain();
    sfx.gain.value = 0.55;
    sfx.connect(master);
    this.sfxBus = sfx;

    const delay = ctx.createDelay(1.2);
    delay.delayTime.value = 0.34;
    const feedback = ctx.createGain();
    feedback.gain.value = 0.28;
    const wet = ctx.createGain();
    wet.gain.value = 0.22;
    delay.connect(feedback);
    feedback.connect(delay);
    delay.connect(wet);
    wet.connect(music);
    this.delay = delay;

    const length = Math.floor(ctx.sampleRate * 1.8);
    const buffer = ctx.createBuffer(2, length, ctx.sampleRate);
    for (let ch = 0; ch < 2; ch++) {
      const data = buffer.getChannelData(ch);
      for (let i = 0; i < length; i++) {
        data[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / length, 2.4);
      }
    }
    this.noiseBuffer = buffer;
    return ctx;
  }

  setMuted(muted: boolean) {
    this.muted = muted;
    if (this.master && this.ctx) {
      this.master.gain.cancelScheduledValues(this.ctx.currentTime);
      this.master.gain.linearRampToValueAtTime(muted ? 0 : 0.72, this.ctx.currentTime + 0.08);
    }
  }

  get isMuted() {
    return this.muted;
  }

  setVoice(on: boolean) {
    this.voiceOn = on;
    if (!on && "speechSynthesis" in window) window.speechSynthesis.cancel();
  }

  get voiceEnabled() {
    return this.voiceOn;
  }

  setMusic(on: boolean) {
    this.musicOn = on;
    if (this.musicBus && this.ctx) {
      this.musicBus.gain.linearRampToValueAtTime(on ? 0.26 : 0, this.ctx.currentTime + 0.2);
    }
  }

  setIntensity(v: number) {
    this.intensity = Math.max(0, Math.min(1, v));
  }

  startMusic() {
    const ctx = this.ensure();
    if (!ctx || this.started) return;
    this.started = true;
    this.nextNote = ctx.currentTime + 0.08;
    this.step = 0;
    this.scheduler = window.setInterval(() => this.schedule(), 70);
  }

  private schedule() {
    const ctx = this.ctx;
    if (!ctx || !this.musicOn) return;
    const stepDur = 60 / 94 / 2;
    while (this.nextNote < ctx.currentTime + 0.28) {
      this.playStep(this.step, this.nextNote, stepDur);
      this.step = (this.step + 1) % 64;
      this.nextNote += stepDur;
    }
  }

  private playStep(step: number, when: number, stepDur: number) {
    const ctx = this.ctx;
    if (!ctx) return;
    const chords = [
      [220, 261.63, 329.63, 392],
      [174.61, 220, 261.63, 329.63],
      [196, 246.94, 293.66, 369.99],
      [164.81, 207.65, 246.94, 329.63],
    ];
    const bar = Math.floor(step / 16) % 4;
    const chord = chords[(bar + 2) % 4];
    if (step % 16 === 0) {
      this.pad(chord, when, stepDur * 16 * 0.95);
      this.bass(chord[0] / 2, when, stepDur * 4);
    }
    if (step % 8 === 0) this.bass(chord[(bar + 1) % 4] / 2, when, stepDur * 3.6);
    if (step % 4 === 0) this.kick(when, 0.32 + this.intensity * 0.2);
    if (step % 8 === 4) this.hat(when, 0.09);
    if (step % 2 === 0) {
      const arp = chord[(step * 3 + bar) % chord.length] * 2;
      this.pluck(arp, when, 0.05 + this.intensity * 0.03);
    }
    if (step % 16 === 14) this.hat(when, 0.055, true);
    if (this.intensity > 0.55 && step % 16 === 8) {
      this.pluck(chord[3] * 4, when + stepDur * 0.5, 0.026);
    }
  }

  private makeGain(value: number): GainNode {
    const g = this.ctx!.createGain();
    g.gain.value = value;
    return g;
  }

  private pad(chord: number[], when: number, dur: number) {
    const ctx = this.ctx!;
    const bus = this.makeGain(0.055);
    const filter = ctx.createBiquadFilter();
    filter.type = "lowpass";
    filter.frequency.value = 850 + this.intensity * 700;
    bus.connect(filter);
    filter.connect(this.musicBus!);
    for (const freq of chord) {
      for (const detune of [-5, 6]) {
        const osc = ctx.createOscillator();
        osc.type = "triangle";
        osc.frequency.value = freq;
        osc.detune.value = detune;
        const env = this.makeGain(0);
        env.gain.setValueAtTime(0.0001, when);
        env.gain.exponentialRampToValueAtTime(1, when + 0.4);
        env.gain.exponentialRampToValueAtTime(0.0001, when + dur);
        osc.connect(env);
        env.connect(bus);
        osc.start(when);
        osc.stop(when + dur + 0.05);
      }
    }
  }

  private bass(freq: number, when: number, dur: number) {
    const ctx = this.ctx!;
    const osc = ctx.createOscillator();
    osc.type = "sine";
    osc.frequency.value = freq;
    const env = this.makeGain(0.0001);
    env.gain.exponentialRampToValueAtTime(0.16, when + 0.02);
    env.gain.exponentialRampToValueAtTime(0.0001, when + dur);
    osc.connect(env);
    env.connect(this.musicBus!);
    osc.start(when);
    osc.stop(when + dur + 0.05);
  }

  private pluck(freq: number, when: number, gain: number) {
    const ctx = this.ctx!;
    const osc = ctx.createOscillator();
    osc.type = gain > 0.045 ? "square" : "sine";
    osc.frequency.value = freq;
    const env = this.makeGain(0.0001);
    env.gain.setValueAtTime(0.0001, when);
    env.gain.exponentialRampToValueAtTime(gain, when + 0.012);
    env.gain.exponentialRampToValueAtTime(0.0001, when + 0.22);
    osc.connect(env);
    env.connect(this.musicBus!);
    if (this.delay) env.connect(this.delay);
    osc.start(when);
    osc.stop(when + 0.3);
  }

  private kick(when: number, gain: number) {
    const ctx = this.ctx!;
    const osc = ctx.createOscillator();
    osc.type = "sine";
    osc.frequency.setValueAtTime(150, when);
    osc.frequency.exponentialRampToValueAtTime(42, when + 0.13);
    const env = this.makeGain(gain);
    env.gain.setValueAtTime(gain, when);
    env.gain.exponentialRampToValueAtTime(0.0001, when + 0.2);
    osc.connect(env);
    env.connect(this.musicBus!);
    osc.start(when);
    osc.stop(when + 0.22);
  }

  private hat(when: number, gain: number, open = false) {
    const ctx = this.ctx!;
    if (!this.noiseBuffer) return;
    const src = ctx.createBufferSource();
    src.buffer = this.noiseBuffer;
    const filter = ctx.createBiquadFilter();
    filter.type = "highpass";
    filter.frequency.value = 6500;
    const env = this.makeGain(gain);
    env.gain.setValueAtTime(gain, when);
    env.gain.exponentialRampToValueAtTime(0.0001, when + (open ? 0.16 : 0.045));
    src.connect(filter);
    filter.connect(env);
    env.connect(this.musicBus!);
    src.start(when);
    src.stop(when + 0.18);
  }

  private blip(freq: number, dur: number, type: OscillatorType, gain = 0.18, slide = 0) {
    const ctx = this.ensure();
    if (!ctx || !this.sfxBus) return;
    const t = ctx.currentTime;
    const osc = ctx.createOscillator();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, t);
    if (slide) osc.frequency.exponentialRampToValueAtTime(Math.max(20, freq + slide), t + dur);
    const env = ctx.createGain();
    env.gain.setValueAtTime(0.0001, t);
    env.gain.exponentialRampToValueAtTime(gain, t + 0.008);
    env.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    osc.connect(env);
    env.connect(this.sfxBus);
    osc.start(t);
    osc.stop(t + dur + 0.03);
  }

  private noise(dur: number, gain: number, filterFreq: number, type: BiquadFilterType = "lowpass") {
    const ctx = this.ensure();
    if (!ctx || !this.sfxBus || !this.noiseBuffer) return;
    const t = ctx.currentTime;
    const src = ctx.createBufferSource();
    src.buffer = this.noiseBuffer;
    const filter = ctx.createBiquadFilter();
    filter.type = type;
    filter.frequency.setValueAtTime(filterFreq, t);
    filter.frequency.exponentialRampToValueAtTime(Math.max(80, filterFreq * 0.35), t + dur);
    const env = ctx.createGain();
    env.gain.setValueAtTime(gain, t);
    env.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    src.connect(filter);
    filter.connect(env);
    env.connect(this.sfxBus);
    src.start(t);
    src.stop(t + dur + 0.02);
  }

  plant() {
    this.blip(340, 0.09, "sine", 0.2, 260);
    this.blip(620, 0.12, "triangle", 0.1, 120);
  }

  shoot() {
    this.blip(500, 0.055, "square", 0.07, 300);
    this.noise(0.04, 0.035, 1800);
  }

  ice() {
    this.blip(880, 0.12, "sine", 0.09, 480);
    this.blip(1320, 0.14, "triangle", 0.045, 500);
  }

  hit() {
    this.noise(0.08, 0.08, 400);
    this.blip(120, 0.08, "sine", 0.12, -40);
  }

  sun() {
    this.blip(660, 0.08, "sine", 0.12, 220);
    window.setTimeout(() => this.blip(990, 0.12, "triangle", 0.08, 200), 55);
  }

  zombieDie() {
    this.noise(0.2, 0.1, 700);
    this.blip(190, 0.22, "sawtooth", 0.06, -100);
  }

  explosion() {
    this.noise(0.7, 0.42, 900);
    this.blip(78, 0.55, "sine", 0.24, -45);
  }

  slipper() {
    this.noise(0.32, 0.12, 2200, "bandpass");
    this.blip(280, 0.2, "square", 0.05, -180);
  }

  wave() {
    this.blip(196, 0.28, "sawtooth", 0.09, 80);
    window.setTimeout(() => this.blip(247, 0.32, "sawtooth", 0.08, 90), 150);
    window.setTimeout(() => this.blip(330, 0.45, "sawtooth", 0.07, 90), 300);
  }

  ui() {
    this.blip(440, 0.045, "square", 0.04, 60);
  }

  deny() {
    this.blip(150, 0.12, "square", 0.06, -30);
  }

  yolo() {
    this.blip(520, 0.04, "square", 0.035, 60);
    window.setTimeout(() => this.blip(760, 0.05, "square", 0.03, 80), 65);
  }

  bossRoar() {
    const ctx = this.ensure();
    if (!ctx || !this.sfxBus) return;
    const t = ctx.currentTime;
    const osc = ctx.createOscillator();
    osc.type = "sawtooth";
    osc.frequency.setValueAtTime(90, t);
    osc.frequency.exponentialRampToValueAtTime(42, t + 1.1);
    const env = ctx.createGain();
    env.gain.setValueAtTime(0.0001, t);
    env.gain.exponentialRampToValueAtTime(0.2, t + 0.05);
    env.gain.exponentialRampToValueAtTime(0.0001, t + 1.25);
    osc.connect(env);
    env.connect(this.sfxBus);
    osc.start(t);
    osc.stop(t + 1.3);
    this.noise(1, 0.12, 500);
  }

  speak(text: string) {
    if (!this.voiceOn || !("speechSynthesis" in window)) return;
    const synth = window.speechSynthesis;
    synth.cancel();
    const utter = new SpeechSynthesisUtterance(text.replace(/[《》「」…—]/g, " "));
    utter.lang = "zh-CN";
    utter.rate = 1.18;
    utter.pitch = 1.35;
    utter.volume = 0.9;
    const voices = synth.getVoices();
    const zh = voices.find((v) => v.lang.toLowerCase().startsWith("zh"));
    if (zh) utter.voice = zh;
    synth.speak(utter);
  }
}
