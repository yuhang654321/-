# 奶龙协议：早八植物园 · 源代码包

版本：3.1.0

这是游戏的可运行源代码，不包含以下重资产：

- `node_modules/`、`.venv/`：依赖请重新安装
- `models/`：YOLO 权重（`abstract_yolo.pt` / `yolo11n.pt`）
- `training/`：130MB 训练集
- `dist/`：构建产物
- `demo/`：宣传截图/GIF
- `runs/`、`torchinductor_yu/`：训练缓存

## 目录

```text
src/                前端游戏代码（TypeScript + Canvas + DOM HUD）
server/             FastAPI 后端、LLM Agent、YOLO 推理、Bing 检索
assets/svg/         原创植物/敌人 SVG 源文件
public/assets/      已栅格化精灵图与 UI 资源
scripts/            启动器、SVG 栅格化、关卡素材生成脚本
tests/              Playwright 回归测试
docs/               面试说明、训练文档
```

## 运行

```powershell
pnpm install
pnpm build
python -m pip install -r requirements.txt
.\start.cmd
```

或在 PowerShell 中：

```powershell
powershell -ExecutionPolicy Bypass -File .\run.ps1
```

打开 `http://127.0.0.1:8000`。

本地模型不是硬依赖：LM Studio 在线时使用 Qwen2.5-7B，离线时自动切到本地工具和备用人格。YOLO 权重需要单独放回 `models/abstract_yolo.pt`，否则第三只眼会提示模型未就绪。

## 主要入口

- 前端入口：`src/main.ts`
- 游戏循环与 AI/塔防逻辑：`src/game/engine.ts`
- 关卡、植物、敌人配置：`src/game/content.ts`
- Canvas 渲染：`src/game/renderer.ts`
- 对话与聊天 UI：`src/ui/chat.ts`
- FastAPI 路由：`server/app.py`
- Agent/工具/傲娇规则：`server/agent.py`
- LLM 客户端：`server/llm.py`
- YOLO 推理：`server/vision.py`
- Bing 检索：`server/websearch.py`
- 关卡与植物素材生成：`scripts/gen_plants_v2.py`、`scripts/gen_sprites.py`
