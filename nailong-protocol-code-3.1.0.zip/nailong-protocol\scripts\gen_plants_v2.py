"""The 2.0 plant cast: every plant is a distinct Nailong-lineage creature.

The old six sprites are re-authored here so their faces, horns, bellies and
mischief read as one species.  Four new variants plus the Jade Seal boss are
introduced for the 15-level campaign.  Nothing is traced from an existing IP;
we only keep the broad "yellow noodle dragon" affection language.
"""
from __future__ import annotations

import math
import os

import gen_sprites as g

INK = g.INK
CREAM = g.CREAM
YELLOW = g.YELLOW
MAGENTA = g.MAGENTA
MINT = g.MINT
CYAN = g.CYAN
OUT = g.OUT


def head(
    cx: float,
    cy: float,
    s: float = 1.0,
    *,
    body: str = "url(#yellow)",
    horn: str = "#ff9b45",
    muzzle: str = "url(#cream)",
    eyes: str = "open",
    mouth: str = "happy",
    tilt: float = 0,
    blush_color: str = "#ff708b",
    extra: str = "",
) -> str:
    """A single reusable Nailong-ish head, centered on (0,0) before transform."""
    if eyes == "sleepy":
        eye_svg = f"""
        <path d="M-58 -22 C-48 -34 -28 -34 -18 -22" fill="none" stroke="{INK}" stroke-width="8" stroke-linecap="round"/>
        <path d="M22 -22 C32 -34 52 -34 62 -22" fill="none" stroke="{INK}" stroke-width="8" stroke-linecap="round"/>
        """
    elif eyes == "smug":
        eye_svg = f"""
        <path d="M-58 -16 C-46 -26 -28 -26 -18 -16" fill="none" stroke="{INK}" stroke-width="8" stroke-linecap="round"/>
        {g.eye(38, -12, 10, 14)}
        <path d="M20 -25 C30 -32 50 -32 60 -22" fill="none" stroke="{INK}" stroke-width="5" stroke-linecap="round"/>
        """
    elif eyes == "angry":
        eye_svg = f"""
        <path d="M-66 -38 L-22 -26" stroke="{INK}" stroke-width="9" stroke-linecap="round"/>
        <path d="M22 -26 L66 -38" stroke="{INK}" stroke-width="9" stroke-linecap="round"/>
        {g.eye(-40, -12, 13, 17)}
        {g.eye(40, -12, 13, 17)}
        """
    else:
        eye_svg = g.eye(-40, -16, 13, 18) + g.eye(40, -16, 13, 18)

    if mouth == "sleepy":
        mouth_svg = f'<path d="M-16 35 C-8 42 8 42 16 35" fill="none" stroke="{INK}" stroke-width="7" stroke-linecap="round"/>'
    elif mouth == "shout":
        mouth_svg = f"""
        <path d="M-40 25 C-44 68 44 68 40 25 C24 17 -24 17 -40 25 Z" fill="#70223f" stroke="{INK}" stroke-width="8"/>
        <path d="M-28 29 L-22 45 L-10 30 M12 30 L22 45 L30 28" fill="none" stroke="{CREAM}" stroke-width="6" stroke-linejoin="round"/>
        <path d="M-10 52 C0 58 10 58 18 52" fill="none" stroke="#ff8ba0" stroke-width="5" stroke-linecap="round"/>
        """
    elif mouth == "smirk":
        mouth_svg = f'<path d="M-25 32 C-8 46 18 44 34 28" fill="none" stroke="{INK}" stroke-width="8" stroke-linecap="round"/>'
    else:
        mouth_svg = f"""
        <path d="M-37 24 C-26 15 26 15 37 24 C40 60 22 76 0 76 C-22 76 -40 60 -37 24 Z" fill="#7f233f" stroke="{INK}" stroke-width="8"/>
        <path d="M-23 29 L-19 46 L-5 28 M9 28 L17 46 L28 27" fill="none" stroke="{CREAM}" stroke-width="6" stroke-linejoin="round"/>
        <path d="M-12 60 C0 68 12 68 20 58" fill="none" stroke="#ff9aae" stroke-width="5" stroke-linecap="round"/>
        """

    return f"""
    <g transform="translate({cx} {cy}) scale({s}) rotate({tilt})">
      <path d="M-105 -18 C-108 -92 -70 -128 0 -128 C70 -128 108 -92 105 -18
               C102 54 68 98 0 100 C-68 98 -102 54 -105 -18 Z"
            fill="{body}" stroke="{INK}" stroke-width="13"/>
      <path d="M-68 -103 C-88 -128 -74 -154 -56 -156 C-46 -132 -30 -116 -14 -107 Z"
            fill="{horn}" stroke="{INK}" stroke-width="9"/>
      <path d="M68 -103 C88 -128 74 -154 56 -156 C46 -132 30 -116 14 -107 Z"
            fill="{horn}" stroke="{INK}" stroke-width="9"/>
      <ellipse cx="-99" cy="-10" rx="24" ry="34" fill="{body}" stroke="{INK}" stroke-width="8"/>
      <ellipse cx="99" cy="-10" rx="24" ry="34" fill="{body}" stroke="{INK}" stroke-width="8"/>
      <path d="M-64 -98 C-42 -115 -20 -122 0 -122 C22 -122 44 -114 64 -98"
            fill="none" stroke="#fff7ba" stroke-width="12" stroke-linecap="round" opacity=".8"/>
      <ellipse cx="0" cy="34" rx="70" ry="52" fill="{muzzle}" stroke="{INK}" stroke-width="7"/>
      {eye_svg}
      {g.blush(-76, 30, 19, blush_color)}
      {g.blush(76, 30, 19, blush_color)}
      {mouth_svg}
      <path d="M-34 12 C-26 6 -18 8 -14 14" fill="none" stroke="#d79a51" stroke-width="5" stroke-linecap="round" opacity=".55"/>
      {extra}
    </g>
    """


def tiny_paw(x: float, y: float, s: float = 1, color: str = "url(#yellow)") -> str:
    return f"""
    <g transform="translate({x} {y}) scale({s}) rotate(-8)">
      <path d="M-22 -8 C-22 -24 -2 -30 12 -20 C24 -12 24 8 10 16 C-4 24 -20 12 -22 -8 Z"
            fill="{color}" stroke="{INK}" stroke-width="7"/>
      <path d="M-10 -5 L-6 -17 M2 -7 L6 -19 M12 -6 L16 -16" stroke="{INK}" stroke-width="4" stroke-linecap="round"/>
    </g>
    """


def flower2() -> str:
    petals = []
    for i in range(10):
        a = i * 36
        petals.append(
            f'<ellipse cx="256" cy="116" rx="43" ry="75" fill="url(#yellow)" stroke="{INK}" stroke-width="9" '
            f'transform="rotate({a} 256 234)"/>'
        )
    body = f"""
    <ellipse cx="256" cy="479" rx="112" ry="18" fill="{INK}" opacity=".2"/>
    <g stroke="{INK}" stroke-width="11" stroke-linecap="round">
      <path d="M256 369 C251 410 260 438 253 462" fill="none"/>
      <path d="M252 415 C216 396 188 401 170 424 C201 442 229 438 253 425" fill="url(#green)"/>
      <path d="M260 438 C294 418 320 424 337 446 C306 462 281 458 260 447" fill="url(#green)"/>
    </g>
    {''.join(petals)}
    {tiny_paw(163, 346, 0.9)}
    {tiny_paw(350, 346, 0.9)}
    {head(256, 250, 0.92, mouth="happy", extra='<path d="M-65 56 C-82 74 -79 96 -62 103" fill="none" stroke="#ff9b45" stroke-width="7" stroke-linecap="round"/>')}
    <path d="M360 391 L410 372 L417 387 L367 407 Z" fill="{MAGENTA}" stroke="{INK}" stroke-width="6"/>
    <text x="391" y="396" transform="rotate(-9 391 396)" font-family="Arial Black, sans-serif" font-size="14" fill="{CREAM}" text-anchor="middle">07</text>
    {g.sparkle(118, 203, 18, "#fff8b0", .9)}
    {g.sparkle(399, 235, 12, "#fff8b0", .8)}
    """
    return g.svg(body)


def pea2() -> str:
    body = f"""
    <ellipse cx="256" cy="478" rx="112" ry="18" fill="{INK}" opacity=".2"/>
    <path d="M256 355 C244 405 255 440 248 468" fill="none" stroke="{INK}" stroke-width="12" stroke-linecap="round"/>
    <path d="M250 418 C213 393 184 400 165 426 C198 448 226 442 252 428" fill="url(#green)" stroke="{INK}" stroke-width="10"/>
    <path d="M263 441 C294 418 323 422 340 447 C311 466 284 460 261 451" fill="url(#green)" stroke="{INK}" stroke-width="10"/>
    {tiny_paw(154, 333, 0.84, "#bff36a")}
    {tiny_paw(358, 333, 0.84, "#bff36a")}
    {head(256, 242, 0.92, body="#c8f45d", horn="#71b72f", muzzle="url(#cream)", mouth="shout", tilt=-2,
          extra='<path d="M-97 12 C-120 10 -132 23 -126 39 C-111 48 -97 35 -92 20" fill="#c8f45d" stroke="' + INK + '" stroke-width="7"/>')}
    <g transform="translate(382 255) rotate(10)">
      <path d="M-10 0 L38 -22 L44 26 L-12 38 Z" fill="{CREAM}" stroke="{INK}" stroke-width="6"/>
      <text x="18" y="12" font-family="Arial Black, sans-serif" font-size="22" fill="{INK}" text-anchor="middle">典</text>
    </g>
    {g.sparkle(112, 188, 14, MINT, .9)}
    {g.sparkle(398, 348, 10, MINT, .75)}
    """
    return g.svg(body)


def wall2() -> str:
    body = f"""
    <ellipse cx="256" cy="479" rx="142" ry="19" fill="{INK}" opacity=".2"/>
    <path d="M120 414 C110 360 132 326 168 318 C208 309 240 328 250 360 L250 455
             C218 474 152 470 120 414 Z" fill="#e6a32e" stroke="{INK}" stroke-width="11"/>
    <path d="M392 414 C402 360 380 326 344 318 C304 309 272 328 262 360 L262 455
             C294 474 360 470 392 414 Z" fill="#e6a32e" stroke="{INK}" stroke-width="11"/>
    <g transform="translate(0 18)">
      {head(256, 330, 0.66, body="#f2b333", horn="#cf7e1f", eyes="sleepy", mouth="sleepy",
            extra='<path d="M-65 64 L-49 82 L-31 68 L-12 86 L8 68 L27 86 L45 68 L62 82" fill="none" stroke="#bd7817" stroke-width="6" stroke-linejoin="round"/>')}
    </g>
    <g transform="translate(0 -52)">
      {head(256, 330, 0.6, body="#ffd447", horn="#ff9b45", eyes="sleepy", mouth="sleepy")}
    </g>
    <g transform="translate(0 -117)">
      {head(256, 330, 0.52, body="#ffe26a", horn="#ff9b45", eyes="sleepy", mouth="sleepy")}
    </g>
    {tiny_paw(126, 421, 0.9)}
    {tiny_paw(386, 421, 0.9)}
    <path d="M154 265 L208 245 L218 270 L164 290 Z" fill="{CREAM}" stroke="{INK}" stroke-width="5"/>
    <text x="187" y="274" transform="rotate(-13 187 274)" font-family="ZCOOL KuaiLe, Microsoft YaHei, sans-serif" font-size="20" fill="{INK}" text-anchor="middle">承重</text>
    <path d="M334 232 L356 220 M346 260 L372 256" stroke="{MAGENTA}" stroke-width="6" stroke-linecap="round"/>
    """
    return g.svg(body)


def frost2() -> str:
    ice = "".join(
        f'<rect x="{x}" y="{y}" width="30" height="27" rx="8" fill="#e2fdff" stroke="{INK}" stroke-width="5" transform="rotate({r} {x+15} {y+13})"/>'
        for x, y, r in [(174, 356, -10), (222, 328, 7), (282, 346, -7), (320, 376, 12), (205, 398, 18)]
    )
    body = f"""
    <ellipse cx="256" cy="481" rx="118" ry="17" fill="{INK}" opacity=".2"/>
    <path d="M170 332 L342 332 L324 469 C322 482 306 489 288 489 L224 489 C206 489 190 482 188 469 Z"
          fill="url(#ice)" stroke="{INK}" stroke-width="12"/>
    <path d="M196 356 L206 462" fill="none" stroke="#fff" stroke-width="10" stroke-linecap="round" opacity=".7"/>
    {ice}
    <path d="M330 292 C372 304 382 338 360 360 C342 340 332 318 330 292 Z" fill="#bff8ff" stroke="{INK}" stroke-width="8"/>
    <path d="M256 216 L256 168" stroke="#ffdf5b" stroke-width="13" stroke-linecap="round"/>
    <path d="M256 184 C235 169 216 176 208 194 C228 210 246 202 256 184 Z" fill="{MINT}" stroke="{INK}" stroke-width="6"/>
    <path d="M187 216 C196 176 224 151 256 151 C288 151 316 176 325 216" fill="#7ce7ff" stroke="{INK}" stroke-width="12"/>
    <path d="M199 214 L212 177 L230 199 L244 163 L264 198 L285 170 L299 200 L316 216" fill="#e9feff" stroke="{INK}" stroke-width="7" stroke-linejoin="round"/>
    {head(256, 282, 0.66, body="#a9efff", horn="#46b8dc", muzzle="url(#cream)", eyes="sleepy", mouth="sleepy")}
    {tiny_paw(162, 414, 0.78, "#a9efff")}
    {tiny_paw(352, 414, 0.78, "#a9efff")}
    {g.sparkle(128, 244, 16, "#e9feff", .95)}
    {g.sparkle(398, 262, 11, "#e9feff", .9)}
    <text x="256" y="435" font-family="Arial Black, sans-serif" font-size="22" fill="{INK}" text-anchor="middle" opacity=".6">ICE</text>
    """
    return g.svg(body)


def fan2() -> str:
    blades = "".join(
        f'<path d="M256 240 C218 226 205 196 220 172 C250 178 270 198 273 226 Z" fill="#a9ffe1" stroke="{INK}" stroke-width="8" transform="rotate({i*120} 256 240)"/>'
        for i in range(3)
    )
    body = f"""
    <ellipse cx="256" cy="476" rx="122" ry="18" fill="{INK}" opacity=".2"/>
    <path d="M198 406 L168 472 M314 406 L344 472 M256 412 L256 465" stroke="{INK}" stroke-width="10" stroke-linecap="round"/>
    <path d="M150 464 C184 450 328 450 362 464 C350 486 162 486 150 464 Z" fill="#ffb84d" stroke="{INK}" stroke-width="9"/>
    <circle cx="256" cy="252" r="144" fill="#9cffe0" stroke="{INK}" stroke-width="14"/>
    <circle cx="256" cy="252" r="120" fill="#4ed5b8" stroke="{INK}" stroke-width="4" opacity=".55"/>
    {blades}
    {head(256, 252, 0.56, body="#b8ffe7", horn="#39b99d", eyes="smug", mouth="smirk")}
    <path d="M390 262 C424 280 431 313 414 332" fill="none" stroke="{INK}" stroke-width="8" stroke-linecap="round"/>
    <path d="M326 381 L398 400 L392 418 L320 399 Z" fill="{CREAM}" stroke="{INK}" stroke-width="5"/>
    <text x="361" y="409" transform="rotate(14 361 409)" font-family="Arial Black, sans-serif" font-size="15" fill="{INK}" text-anchor="middle">3档</text>
    {g.sparkle(128, 176, 13, MINT, .8)}
    """
    return g.svg(body)


def bomb2() -> str:
    body = f"""
    <ellipse cx="256" cy="477" rx="124" ry="18" fill="{INK}" opacity=".2"/>
    <path d="M154 340 C146 270 190 216 256 216 C322 216 366 270 358 340 C350 430 314 474 256 474 C198 474 162 430 154 340 Z"
          fill="#ff5d6c" stroke="{INK}" stroke-width="13"/>
    <circle cx="256" cy="361" r="86" fill="url(#cream)" stroke="{INK}" stroke-width="9"/>
    <circle cx="256" cy="361" r="70" fill="#fffdf4" stroke="#d9b34a" stroke-width="4"/>
    <g stroke="{INK}" stroke-width="6" stroke-linecap="round">
      <path d="M256 303 L256 315"/><path d="M256 407 L256 419"/><path d="M198 361 L210 361"/><path d="M302 361 L314 361"/>
    </g>
    <path d="M256 361 L256 316 M256 361 L286 376" stroke="{INK}" stroke-width="7" stroke-linecap="round"/>
    <circle cx="256" cy="361" r="5" fill="{MAGENTA}"/>
    {head(256, 268, 0.48, body="#ff7c86", horn="#ce3948", eyes="angry", mouth="shout")}
    <path d="M194 203 C181 166 199 137 225 133" fill="none" stroke="{INK}" stroke-width="9" stroke-linecap="round"/>
    <path d="M221 138 C239 108 266 104 284 124 C259 146 241 151 221 138 Z" fill="#ffe35a" stroke="{INK}" stroke-width="7"/>
    <path d="M285 124 C307 116 324 125 326 141 C310 151 294 144 285 124 Z" fill="#ff9a3d" stroke="{INK}" stroke-width="6"/>
    <path d="M345 216 C370 191 388 196 397 213 C375 235 358 238 345 216 Z" fill="#ffe35a" stroke="{INK}" stroke-width="7"/>
    {tiny_paw(145, 390, 0.78, "#ff7c86")}
    {tiny_paw(367, 390, 0.78, "#ff7c86")}
    <path d="M196 455 L186 482 M316 455 L326 482" stroke="{INK}" stroke-width="11" stroke-linecap="round"/>
    <text x="256" y="436" font-family="Arial Black, sans-serif" font-size="23" fill="{INK}" text-anchor="middle">08:00</text>
    <path d="M121 272 L96 254 M128 303 L100 303 M391 272 L416 254 M384 303 L412 303" stroke="{MAGENTA}" stroke-width="7" stroke-linecap="round"/>
    """
    return g.svg(body)


def cannon2() -> str:
    body = f"""
    <ellipse cx="256" cy="480" rx="145" ry="18" fill="{INK}" opacity=".2"/>
    <path d="M116 405 C124 367 158 345 196 345 L316 345 C354 345 388 367 396 405 L380 458 L132 458 Z"
          fill="#3e2c57" stroke="{INK}" stroke-width="12"/>
    <path d="M148 397 L364 397" stroke="#ffe66d" stroke-width="8" stroke-dasharray="18 10" opacity=".7"/>
    <circle cx="165" cy="456" r="30" fill="#ffd447" stroke="{INK}" stroke-width="8"/>
    <circle cx="347" cy="456" r="30" fill="#ffd447" stroke="{INK}" stroke-width="8"/>
    <circle cx="165" cy="456" r="10" fill="{INK}"/><circle cx="347" cy="456" r="10" fill="{INK}"/>
    <path d="M300 356 L418 294 C431 288 442 300 436 313 L391 392 L330 388 Z" fill="#6c4f91" stroke="{INK}" stroke-width="10"/>
    <path d="M402 310 C425 299 444 310 447 330 C426 344 409 336 402 310 Z" fill="#ffcf4a" stroke="{INK}" stroke-width="7"/>
    <circle cx="430" cy="322" r="14" fill="#7a233f" stroke="{INK}" stroke-width="5"/>
    {head(252, 262, 0.64, body="#ffc93d", horn="#e07d24", eyes="angry", mouth="shout")}
    {tiny_paw(168, 361, 0.75)}
    {tiny_paw(339, 361, 0.75)}
    <path d="M152 300 C121 285 111 258 128 240 C147 255 164 271 170 289 Z" fill="#ffe66d" stroke="{INK}" stroke-width="7"/>
    <path d="M202 215 C188 187 201 163 220 160 C230 183 242 200 256 209" fill="#ff9b45" stroke="{INK}" stroke-width="8"/>
    <path d="M303 215 C317 187 304 163 285 160 C275 183 263 200 249 209" fill="#ff9b45" stroke="{INK}" stroke-width="8"/>
    <path d="M116 369 L84 346 L76 361 L108 384 Z" fill="{MAGENTA}" stroke="{INK}" stroke-width="5"/>
    <text x="95" y="370" transform="rotate(37 95 370)" font-family="Arial Black, sans-serif" font-size="12" fill="{CREAM}" text-anchor="middle">轰</text>
    """
    return g.svg(body)


def vacuum2() -> str:
    body = f"""
    <ellipse cx="256" cy="480" rx="135" ry="18" fill="{INK}" opacity=".2"/>
    <path d="M292 311 C348 303 384 336 379 392 C375 446 334 469 286 458 C247 449 231 409 240 366 Z"
          fill="#8f66c9" stroke="{INK}" stroke-width="12"/>
    <circle cx="318" cy="383" r="42" fill="#d9c6ff" stroke="{INK}" stroke-width="7"/>
    <circle cx="318" cy="383" r="27" fill="#6ff2a1" stroke="{INK}" stroke-width="5"/>
    <path d="M318 356 L318 410 M291 383 L345 383" stroke="{INK}" stroke-width="4" opacity=".6"/>
    <circle cx="201" cy="456" r="20" fill="#3f3158" stroke="{INK}" stroke-width="7"/>
    <circle cx="361" cy="456" r="20" fill="#3f3158" stroke="{INK}" stroke-width="7"/>
    <path d="M268 316 C302 290 336 294 356 311" fill="none" stroke="{INK}" stroke-width="18" stroke-linecap="round"/>
    <path d="M280 306 C306 283 332 286 348 300" fill="none" stroke="#c4a8f0" stroke-width="8" stroke-linecap="round"/>
    {head(235, 259, 0.71, body="#c9a3ff", horn="#8b5fce", eyes="smug", mouth="shout")}
    <path d="M268 277 C314 262 348 276 359 302" fill="none" stroke="{INK}" stroke-width="17" stroke-linecap="round"/>
    <path d="M280 272 C312 262 333 270 344 284" fill="none" stroke="#e1d0ff" stroke-width="7" stroke-linecap="round"/>
    {tiny_paw(167, 389, 0.78, "#c9a3ff")}
    {tiny_paw(359, 415, 0.65, "#c9a3ff")}
    <path d="M137 296 C113 312 111 342 129 359" fill="none" stroke="{MAGENTA}" stroke-width="6" stroke-linecap="round" stroke-dasharray="5 10"/>
    <path d="M171 223 C154 198 163 178 180 176 C190 198 204 211 218 218" fill="#8b5fce" stroke="{INK}" stroke-width="7"/>
    <path d="M301 223 C318 198 309 178 292 176 C282 198 268 211 254 218" fill="#8b5fce" stroke="{INK}" stroke-width="7"/>
    <text x="151" y="427" font-family="Arial Black, sans-serif" font-size="16" fill="{CREAM}" transform="rotate(-8 151 427)">吸</text>
    """
    return g.svg(body)


def boomerang2() -> str:
    body = f"""
    <ellipse cx="256" cy="479" rx="122" ry="18" fill="{INK}" opacity=".2"/>
    <path d="M254 330 C236 380 245 430 253 462" fill="none" stroke="{INK}" stroke-width="12" stroke-linecap="round"/>
    <path d="M247 408 C213 387 186 392 169 414 C200 436 226 430 249 418" fill="url(#green)" stroke="{INK}" stroke-width="9"/>
    <path d="M266 438 C293 418 319 423 335 443 C309 460 283 455 263 447" fill="url(#green)" stroke="{INK}" stroke-width="9"/>
    <ellipse cx="256" cy="185" rx="87" ry="17" fill="#ffe66d" stroke="{INK}" stroke-width="8"/>
    <path d="M256 188 L256 142" stroke="{INK}" stroke-width="8" stroke-linecap="round"/>
    <path d="M156 164 C180 139 218 128 256 128 C294 128 332 139 356 164" fill="none" stroke="{INK}" stroke-width="9" stroke-linecap="round"/>
    <path d="M256 128 C238 112 224 119 222 133 C238 147 251 142 256 128 Z" fill="{MAGENTA}" stroke="{INK}" stroke-width="5"/>
    {head(256, 259, 0.82, body="#bff8ff", horn="#50c5db", eyes="smug", mouth="smirk")}
    {tiny_paw(152, 375, 0.8, "#bff8ff")}
    {tiny_paw(360, 375, 0.8, "#bff8ff")}
    <g transform="translate(391 392) rotate(-18)">
      <path d="M-54 20 C-70 -18 -20 -48 18 -28 C57 -8 60 51 23 59 C-6 65 -21 43 -4 26 C12 10 34 20 29 35"
            fill="#e6b86b" stroke="{INK}" stroke-width="10" stroke-linecap="round"/>
      <path d="M-29 18 C-20 1 4 -6 18 3" fill="none" stroke="#fff2c9" stroke-width="6" stroke-linecap="round"/>
    </g>
    <path d="M337 233 C365 219 383 229 386 247 C367 260 350 256 337 233 Z" fill="#bff8ff" stroke="{INK}" stroke-width="6"/>
    {g.sparkle(116, 242, 13, "#d9feff", .8)}
    <text x="165" y="448" font-family="Arial Black, sans-serif" font-size="15" fill="{INK}" transform="rotate(-7 165 448)">回旋</text>
    """
    return g.svg(body)


def seal2() -> str:
    beads = "".join(
        f'<circle cx="{x}" cy="{y}" r="4" fill="{CREAM}" stroke="{INK}" stroke-width="2"/>'
        for x in range(196, 317, 12)
        for y in (109, 126, 143)
    )
    body = f"""
    <ellipse cx="256" cy="486" rx="150" ry="18" fill="{INK}" opacity=".22"/>
    <path d="M122 345 L390 345 L406 478 L106 478 Z" fill="#bff2d0" stroke="{INK}" stroke-width="13"/>
    <path d="M132 364 L386 364 L398 462 L120 462 Z" fill="#d9ffe9" stroke="#4c9e77" stroke-width="4"/>
    <path d="M164 406 C194 378 229 384 235 415 C207 438 180 436 164 406 Z" fill="none" stroke="#4c9e77" stroke-width="8"/>
    <path d="M276 406 C306 378 341 384 347 415 C319 438 292 436 276 406 Z" fill="none" stroke="#4c9e77" stroke-width="8"/>
    <rect x="238" y="391" width="36" height="45" rx="6" fill="#ff5b7c" stroke="#4c9e77" stroke-width="5"/>
    <text x="256" y="420" font-family="ZCOOL KuaiLe, Microsoft YaHei, sans-serif" font-size="18" fill="{CREAM}" text-anchor="middle" transform="rotate(90 256 413)">受命于天</text>
    <path d="M152 346 L360 346 L350 324 L162 324 Z" fill="#7fd6ac" stroke="{INK}" stroke-width="8"/>
    {head(256, 255, 0.69, body="url(#yellow)", horn="#e8aa23", eyes="smug", mouth="smirk")}
    <path d="M191 173 L205 129 L232 159 L256 104 L280 159 L307 129 L321 173 Z" fill="#ffd447" stroke="{INK}" stroke-width="8" stroke-linejoin="round"/>
    <path d="M186 168 L326 168" stroke="{INK}" stroke-width="6"/>
    <path d="M195 163 C216 146 238 139 256 139 C274 139 296 146 317 163" fill="none" stroke="#fff6d0" stroke-width="6" opacity=".8"/>
    {beads}
    {tiny_paw(164, 329, 0.76)}
    {tiny_paw(348, 329, 0.76)}
    <path d="M111 220 L84 200 M101 248 L71 241 M401 220 L428 200 M411 248 L441 241" stroke="#ffe66d" stroke-width="7" stroke-linecap="round"/>
    <path d="M358 306 L404 289 L412 305 L366 322 Z" fill="#ff5b7c" stroke="{INK}" stroke-width="5"/>
    <text x="386" y="315" transform="rotate(-9 386 315)" font-family="ZCOOL KuaiLe, Microsoft YaHei, sans-serif" font-size="16" fill="{CREAM}" text-anchor="middle">玉玺</text>
    """
    return g.svg(body)


def emperor() -> str:
    beads = "".join(
        f'<circle cx="{x}" cy="{y}" r="5" fill="#d9fff2" stroke="{INK}" stroke-width="2"/>'
        for x in range(154, 359, 13)
        for y in (88, 107, 126, 145)
    )
    papers = "".join(
        f'<g transform="rotate({r} {x} {y})"><rect x="{x}" y="{y}" width="36" height="47" fill="#fff3cf" stroke="{INK}" stroke-width="4"/><path d="M{x+6} {y+13} H{x+29} M{x+6} {y+24} H{x+25}" stroke="#8f866f" stroke-width="3"/></g>'
        for x, y, r in [(55, 310, -18), (63, 380, 8), (444, 326, 19), (455, 400, -9)]
    )
    body = f"""
    <ellipse cx="256" cy="490" rx="190" ry="18" fill="{INK}" opacity=".25"/>
    {papers}
    <path d="M135 348 C112 395 104 452 117 486 L395 486 C408 452 400 395 377 348 Z" fill="#24142f" stroke="{INK}" stroke-width="13"/>
    <path d="M135 348 L192 486 M377 348 L320 486" stroke="#6a3b7d" stroke-width="7"/>
    <path d="M158 296 C156 248 190 218 232 218 L280 218 C324 220 357 252 354 301 L346 385 C342 419 312 440 280 438 L232 438 C200 440 172 418 168 384 Z"
          fill="#2b1838" stroke="{INK}" stroke-width="12"/>
    <path d="M218 222 L256 274 L294 222" fill="none" stroke="#ffe66d" stroke-width="7"/>
    <path d="M256 274 L256 374" stroke="#ff4d6d" stroke-width="10"/>
    <path d="M256 288 L224 312 L256 336 L288 312 Z" fill="#ff4d6d" stroke="{INK}" stroke-width="6"/>
    {head(256, 217, 1.08, body="url(#yellow)", horn="#e8aa23", eyes="angry", mouth="shout",
          extra='<path d="M-112 20 C-144 18 -157 35 -150 53 C-132 62 -116 48 -107 30" fill="#ffd447" stroke="' + INK + '" stroke-width="8"/>')}
    <path d="M146 148 L167 91 L201 128 L256 61 L311 128 L345 91 L366 148 Z" fill="#ffd447" stroke="{INK}" stroke-width="10" stroke-linejoin="round"/>
    <path d="M135 141 L377 141" stroke="{INK}" stroke-width="7"/>
    {beads}
    <path d="M190 122 C220 95 236 88 256 88 C276 88 292 95 322 122" fill="none" stroke="#fff6d0" stroke-width="8" opacity=".8"/>
    <path d="M371 356 C423 372 438 420 411 449" fill="none" stroke="{INK}" stroke-width="12" stroke-linecap="round"/>
    <path d="M408 443 C430 446 441 464 431 480 C413 477 402 463 408 443 Z" fill="#7ff0c0" stroke="{INK}" stroke-width="6"/>
    <path d="M407 456 L428 456 M417 443 L417 471" stroke="#2e7c5b" stroke-width="4"/>
    <path d="M103 367 C75 389 72 426 97 446" fill="none" stroke="{INK}" stroke-width="12" stroke-linecap="round"/>
    <path d="M381 334 L441 374" stroke="{INK}" stroke-width="9" stroke-linecap="round"/>
    <path d="M432 365 C448 364 457 376 448 390 C435 391 426 380 432 365 Z" fill="{MAGENTA}" stroke="{INK}" stroke-width="5"/>
    <path d="M404 399 L477 423 L469 443 L396 419 Z" fill="#ffde59" stroke="{INK}" stroke-width="6"/>
    <text x="439" y="429" transform="rotate(21 439 429)" font-family="Arial Black, sans-serif" font-size="15" fill="{INK}" text-anchor="middle">玉玺</text>
    <path d="M164 457 C189 443 230 449 237 467 L226 486 L148 486 L148 469 C152 464 158 460 164 457 Z" fill="#6b3b7d" stroke="{INK}" stroke-width="7"/>
    <path d="M348 457 C323 443 282 449 275 467 L286 486 L364 486 L364 469 C360 464 354 460 348 457 Z" fill="#6b3b7d" stroke="{INK}" stroke-width="7"/>
    <path d="M121 205 L92 181 M112 236 L81 231 M391 205 L420 181 M400 236 L431 231" stroke="#ffcf4a" stroke-width="7" stroke-linecap="round"/>
    """
    return g.svg(body)


NEW = {
    "plant_flower": flower2,
    "plant_pea": pea2,
    "plant_wall": wall2,
    "plant_frost": frost2,
    "plant_fan": fan2,
    "plant_bomb": bomb2,
    "plant_cannon": cannon2,
    "plant_vacuum": vacuum2,
    "plant_boomerang": boomerang2,
    "plant_seal": seal2,
    "zombie_emperor": emperor,
}


def main() -> None:
    # Keep all non-plant sprites from the original generator, then overwrite the
    # cast that needs the new Nailong-family treatment.
    g.main()
    for name, builder in NEW.items():
        path = os.path.join(OUT, name + ".svg")
        with open(path, "w", encoding="utf-8") as fh:
            fh.write(builder())
        print("generated v2", path)


if __name__ == "__main__":
    main()
