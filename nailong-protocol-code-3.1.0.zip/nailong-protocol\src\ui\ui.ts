import type { Game } from "../game/engine";
import { LEVELS, MODIFIERS, PLANTS, PLANT_ORDER } from "../game/content";
import { ProgressStore } from "../game/progress";
import type { DirectorEvent, GameStats, LevelDef, PlantId } from "../types";
import type { HealthInfo } from "../agent/client";

const asset = (name: string) => `${import.meta.env.BASE_URL}assets/sprites/${name}.png`;

const setText = (el: Element | null | undefined, value: string) => {
  if (el && el.textContent !== value) el.textContent = value;
};
const setHTML = (el: Element | null | undefined, value: string) => {
  if (el && el.innerHTML !== value) el.innerHTML = value;
};

export interface UIHandlers {
  onStart: () => void;
  onLevelStart: (index: number) => void;
  onClassic: () => void;
  onNext: () => void;
  onMap: () => void;
  onHelp: () => void;
  onPause: () => void;
  onResume: () => void;
  onRestart: () => void;
  onTitle: () => void;
  onChat: () => void;
  onCamera: () => void;
  onSound: () => void;
  onMusic: () => void;
  onVision: () => void;
  onVisionDraw: () => void;
  onShovel: () => void;
  onShare: () => void;
  onResetProgress: () => void;
}

export class UI {
  readonly root: HTMLElement;
  readonly modalRoot: HTMLElement;
  readonly canvas: HTMLCanvasElement;
  readonly titleEl: HTMLElement;
  readonly levelEl: HTMLElement;
  readonly hudEl: HTMLElement;
  readonly endEl: HTMLElement;
  readonly progress = new ProgressStore();
  private game: Game | null = null;
  private handlers: UIHandlers | null = null;
  private dialogueTimer = 0;
  private bannerTimer = 0;
  private hudClock = 0;
  private health: HealthInfo | null = null;
  private lastCardState = new Map<string, string>();
  private tooltipTimer = 0;

  constructor(root: HTMLElement) {
    this.root = root;
    root.innerHTML = `<div id="stage">${this.layout()}</div>`;
    this.canvas = root.querySelector<HTMLCanvasElement>("#game-canvas")!;
    this.titleEl = root.querySelector<HTMLElement>("#title-screen")!;
    this.levelEl = root.querySelector<HTMLElement>("#level-screen")!;
    this.hudEl = root.querySelector<HTMLElement>("#game-hud")!;
    this.endEl = root.querySelector<HTMLElement>("#end-screen")!;
    this.modalRoot = root.querySelector<HTMLElement>("#modal-root")!;
    this.bind();
  }

  attach(game: Game) {
    this.game = game;
  }

  bindHandlers(handlers: UIHandlers) {
    this.handlers = handlers;
  }

  private layout(): string {
    const cards = PLANT_ORDER.map((id, index) => {
      const p = PLANTS[id];
      const key = index === 9 ? "0" : index === 10 ? "-" : String(index + 1);
      return `<button class="plant-card" data-plant="${id}" data-tip="${p.desc.replace(/"/g, "&quot;")}" aria-label="${p.name}，消耗 ${p.cost} 灵感">
        <span class="card-num">${String(index + 1).padStart(2, "0")}</span>
        <span class="card-name">${p.name}</span>
        <span class="card-role">${p.role}</span>
        <span class="card-desc">${p.desc}</span>
        <span class="card-cost">${p.cost}</span>
        <span class="card-key">${key}</span>
        <img class="card-art" src="${asset(p.sprite)}" alt="" draggable="false" />
        <span class="card-cd"></span>
        <span class="card-cd-label"></span>
      </button>`;
    }).join("");

    return `
      <canvas id="game-canvas" aria-label="奶龙协议游戏画面"></canvas>

      <div id="boot-screen">
        <div class="boot-card">
          <div class="boot-top"><span>AIU // CREATIVE DIVISION</span><span>BOOT 07</span></div>
          <img src="${asset("mascot_face")}" alt="奶龙" class="boot-face" />
          <div class="boot-title">正在唤醒奶龙</div>
          <div class="boot-sub">加载本地大脑 · 校准第三只眼 · 给植物做思想工作</div>
          <div class="boot-bar"><div class="boot-fill" id="boot-fill"></div></div>
          <div class="boot-status" id="boot-status">0%</div>
        </div>
      </div>

      <section id="title-screen">
        <div class="topline">
          <div class="brand-lockup">
            <div class="brand-mark">龙</div>
            <div class="brand-copy">
              <div class="b1">NAILONG PROTOCOL // 实验 07</div>
              <div class="b2">AIU 创智部 · 二面实战 · 一切皆为本地推理</div>
            </div>
          </div>
          <div class="title-status">
            <div class="chip"><span class="status-dot wait" id="title-llm-dot"></span>LOCAL BRAIN <b id="title-llm-status">CHECKING</b></div>
            <div class="chip"><span class="status-dot off" id="title-yolo-dot"></span>YOLO EYE <b id="title-yolo-status">STANDBY</b></div>
          </div>
        </div>

        <div class="title-copy">
          <div class="eyebrow">A VERY LOCAL GAME ABOUT NOT WAKING UP</div>
          <h1 class="main-title">奶龙协议<br /><span class="outline">早八植物园</span></h1>
          <div class="title-en">NAILONG PROTOCOL : 8AM BOTANICA</div>
          <p class="title-desc">
            十五个早八关卡，十一只奶龙科植物。种下它们，捡起灵感，让<strong>本地大模型</strong>即兴编排每一波灾难，
            再让 <strong>YOLO</strong> 从屏幕里盯着你。这不是塔防，这是你和作息之间最后一场体面的战争。
          </p>
          <div class="title-actions">
            <button class="btn primary" id="start-btn"><span>进入关卡地图</span><span class="arrow">→</span></button>
            <button class="btn ghost" id="classic-btn">经典 10 波</button>
            <button class="btn ghost" data-open-help>怎么玩</button>
          </div>
          <div class="title-foot">
            <span>本地 LLM 导演</span><span class="dotline"></span>
            <span>自训练 YOLO 观察</span><span class="dotline"></span>
            <span>15 关 · 3 星 · 可重玩</span><span class="dotline"></span>
            <span>0 张版权素材</span>
          </div>
        </div>

        <div class="stamp s1">实验体 07 / 请勿投喂</div>
        <div class="stamp s2">100% 本地 · 0% 早八</div>
        <div class="stamp s3">AI 含量超标 300%</div>
        <div class="title-side-note">DESIGNED BY A SLEEP-DEPRIVED LOCAL AGENT / 2026</div>

        <div class="marquee"><div class="track">
          <span>本节目由“睡眠舱 07”独家赞助</span>
          <span>奶龙博士声称所有植物均已签署知情同意书</span>
          <span>如遇早八，请立刻装睡</span>
          <span>YOLO 正在看着你，但它没有恶意，只有框</span>
          <span>本地大模型不对任何人生选择负责</span>
        </div></div>
      </section>

      <section id="level-screen" class="hidden">
        <div class="level-map-bg" aria-hidden="true"></div>
        <div class="level-top">
          <button class="level-back" id="level-back">← 标题</button>
          <div class="level-brand">
            <span class="level-brand-mark">07</span>
            <div>
              <div class="level-brand-title">早八作战地图</div>
              <div class="level-brand-sub">CAMPAIGN MAP / 15 EXPERIMENTS</div>
            </div>
          </div>
          <div class="level-progress">
            <span><b id="level-clear-count">0</b> / 15 CLEARED</span>
            <span><b id="level-star-count">0</b> / 45 STARS</span>
            <button class="mini-btn" id="level-reset">重置进度</button>
          </div>
        </div>
        <div class="level-heading">
          <div>
            <div class="modal-kicker">SELECT YOUR MORNING / 选一个早八</div>
            <h2>十五个早上，<span>一张床。</span></h2>
            <p>通关解锁下一关。每关按睡眠舱剩余血量评 1–3 星；已通关的关卡可以重打刷新最高星。</p>
          </div>
          <button class="btn" id="level-classic"><span>经典 10 波</span><span class="arrow">↻</span></button>
        </div>
        <div class="level-grid" id="level-grid"></div>
        <div class="level-foot">
          <span>进度保存在本机 localStorage · 不登录、不上传</span>
          <span>点击已解锁关卡开始 · 锁定关卡需先通关上一关</span>
        </div>
      </section>

      <header id="game-hud" class="hidden">
        <div class="top-bar">
          <div class="top-brand">
            <div class="mini-face"><img src="${asset("mascot_face")}" alt="" /></div>
            <div>
              <div class="wordmark">奶龙协议</div>
              <div class="sub" id="hud-level-label">L01 / 开学第一天</div>
            </div>
          </div>
          <div class="wave-module">
            <div class="wave-line">
              <span class="w-num" id="hud-wave-num">WAVE 01 / 10</span>
              <span class="w-name" id="hud-wave-name">开学第一天</span>
              <span class="w-sub" id="hud-wave-sub">准备中</span>
            </div>
            <div class="wave-bar"><div class="fill" id="hud-wave-fill"></div></div>
            <div class="wave-meta"><span id="hud-wave-meta">下一波：08.0s</span><span id="hud-wave-count">剩余 0</span></div>
            <div class="match-line">
              <span id="match-label">对局进程 0%</span>
              <div class="match-track"><div class="match-fill" id="match-fill"></div><i class="match-mark m33"></i><i class="match-mark m50"></i><i class="match-mark m100"></i></div>
              <b id="boss-readout">BOSS 未到</b>
            </div>
          </div>
          <div class="sun-module">
            <img src="${asset("sun")}" alt="" />
            <div><div class="sun-val" id="hud-sun">200</div><div class="sun-lbl">INSPIRATION / 灵感</div></div>
          </div>
          <div class="pod-module">
            <div class="lbl"><span>SLEEP POD / 睡眠舱</span><b id="hud-pod-label">100%</b></div>
            <div class="pod-bar"><div class="fill" id="hud-pod-fill"></div></div>
          </div>
          <div class="hud-buttons">
            <button class="icon-btn" data-action="sound" title="音效开关">♪</button>
            <button class="icon-btn" data-action="music" title="音乐开关">≋</button>
            <button class="icon-btn" data-action="help" title="规则">?</button>
            <button class="icon-btn" data-action="pause" title="暂停">Ⅱ</button>
          </div>
        </div>

        <div class="seed-dock" id="seed-dock">
          ${cards}
          <button class="shovel-btn" data-action="shovel" title="铲除植物">
            <span class="icon">⌁</span>
            <span>铲子<br />SHOVEL</span>
          </button>
          <div class="plant-tip" id="plant-tip"><b>奶龙图鉴</b><span>把鼠标放到卡上，看它有多抽象。</span></div>
        </div>

        <aside class="side-panel">
          <div class="side-card host-card">
            <div class="host-head">
              <div class="host-avatar"><img src="${asset("mascot_face")}" alt="奶龙博士" /></div>
              <div class="host-id">
                <div class="host-name">奶龙博士</div>
                <div class="host-sub" id="hud-model-label">LM STUDIO / QWEN2.5-7B</div>
                <div class="host-live"><span class="status-dot wait" id="hud-llm-dot"></span><span id="hud-llm-status">连接本地大脑…</span></div>
              </div>
            </div>
            <div class="host-dialogue" id="host-dialogue">你终于醒了。左边是睡眠舱，右边是早八。中间这些植物是我从梦里薅出来的。</div>
            <div class="host-actions">
              <button class="mini-btn" data-action="chat">对奶龙说…</button>
              <button class="mini-btn" data-action="camera">现实裂隙</button>
            </div>
          </div>

          <div class="side-card director-card">
            <div class="section-kicker"><span>DIRECTOR'S SCRIPT / 导演台本</span><span class="source" id="director-source">LOCAL</span></div>
            <div class="director-title" id="director-title">等待第一份台本</div>
            <div class="director-line" id="director-line">它正在思考怎么合理地折磨你。</div>
            <div class="modifier-chip" id="director-modifier">无事发生</div>
          </div>

          <div class="side-card vision-card">
            <div class="vision-head">
              <div class="vision-title"><span class="eye"></span>第三只眼</div>
              <button class="switch" data-action="vision" id="vision-switch" aria-label="切换 YOLO 观察"></button>
            </div>
            <div class="vision-sync">
              <div class="sync-label"><span>COGNITIVE SYNC / 认知同步</span><b id="hud-sync">0%</b></div>
              <div class="sync-bar"><div class="fill" id="hud-sync-fill"></div></div>
            </div>
            <div class="vision-counts">
              <div class="vc"><b id="vc-plant">0</b><span>PLANT</span></div>
              <div class="vc"><b id="vc-zombie">0</b><span>ZOMBIE</span></div>
              <div class="vc"><b id="vc-boss">0</b><span>BOSS</span></div>
              <div class="vc"><b id="vc-sun">0</b><span>SUN</span></div>
            </div>
            <div class="vision-weird">
              <button class="vision-draw" data-action="vision-draw" id="vision-draw">
                <span>抽象解读</span><b>25%</b>
              </button>
              <div class="vision-verdict" id="vision-verdict">打开第三只眼，攒够同步率，抽一张离谱的判词。</div>
            </div>
            <div class="vision-foot">
              <span class="live" id="hud-vision-status">STANDBY</span>
              <span id="hud-vision-meta">等待授权</span>
            </div>
          </div>

          <div class="side-card side-stats">
            <div class="st"><b id="stat-kills">0</b><span>KILLS</span></div>
            <div class="st"><b id="stat-plants">0</b><span>PLANTS</span></div>
            <div class="st"><b id="stat-scans">0</b><span>SCANS</span></div>
          </div>

          <div class="side-fill"></div>
          <button class="chat-open" data-action="chat"><span>和奶龙说点什么</span><span>→</span></button>
        </aside>
      </header>

      <div id="wave-banner">
        <div class="banner-inner">
          <div class="banner-top"><span id="banner-wave">WAVE 01 / 10</span><span>DIRECTED BY LOCAL LLM</span></div>
          <div class="banner-title" id="banner-title">开学第一天</div>
          <div class="banner-line" id="banner-line">新生还在找教学楼，僵尸已经找到你了。</div>
          <div class="banner-tag" id="banner-tag">无事发生</div>
        </div>
      </div>

      <div id="toast-layer"></div>

      <div id="end-screen" class="end-screen">
        <div class="end-card">
          <div class="end-main">
            <div class="end-kicker">EXPERIMENT REPORT / 实验报告 · <span id="end-level">L01</span></div>
            <h2 id="end-title">早八，防住了</h2>
            <div class="end-quote" id="end-quote">你成功守住了睡眠舱。虽然你的作息并没有因此变好。</div>
            <div class="end-stars" id="end-stars" aria-label="关卡星级"></div>
            <div class="end-stats" id="end-stats"></div>
            <div class="end-side-note" style="margin-top:16px;font-family:var(--mono);font-size:8px;color:rgba(28,16,44,.42);letter-spacing:.08em">
              LOCAL LLM × CUSTOM YOLO × ZERO EXTERNAL ASSETS / GENERATED AT 1600×900
            </div>
          </div>
          <div class="end-side">
            <div class="grade-box"><b id="end-grade">S</b><span>ABSTRACTION GRADE</span></div>
            <div class="grade-title" id="end-grade-title">睡眠守护神</div>
            <div class="grade-note" id="end-grade-note">你在几乎没有睡觉的情况下，守住了睡觉的地方。</div>
            <div class="end-actions">
              <button class="btn primary" id="end-next"><span>下一关</span><span class="arrow">→</span></button>
              <button class="btn" id="end-restart"><span>重打本关</span><span class="arrow">↻</span></button>
              <button class="btn" id="end-share">保存战绩卡</button>
              <button class="btn ghost" id="end-map">作战地图</button>
              <button class="btn ghost" id="end-title-btn">回到标题</button>
            </div>
          </div>
        </div>
      </div>

      <div id="modal-root"></div>
    `;
  }

  private bind() {
    this.root.addEventListener("click", (event) => {
      const target = event.target as HTMLElement | null;
      const levelCard = target?.closest<HTMLElement>("[data-level-index]");
      if (levelCard) {
        const index = Number(levelCard.dataset.levelIndex);
        if (Number.isFinite(index) && this.progress.isUnlocked(index)) this.handlers?.onLevelStart(index);
        return;
      }
      const card = target?.closest<HTMLElement>("[data-plant]");
      if (card?.dataset.plant) {
        this.game?.selectPlant(card.dataset.plant as never);
        return;
      }
      const action = target?.closest<HTMLElement>("[data-action]")?.dataset.action;
      if (action === "pause") this.handlers?.onPause();
      else if (action === "sound") this.handlers?.onSound();
      else if (action === "music") this.handlers?.onMusic();
      else if (action === "help") this.handlers?.onHelp();
      else if (action === "shovel") this.handlers?.onShovel();
      else if (action === "chat") this.handlers?.onChat();
      else if (action === "camera") this.handlers?.onCamera();
      else if (action === "vision") this.handlers?.onVision();
      else if (action === "vision-draw") this.handlers?.onVisionDraw();
    });
    document.getElementById("start-btn")?.addEventListener("click", () => this.handlers?.onStart());
    document.getElementById("classic-btn")?.addEventListener("click", () => this.handlers?.onClassic());
    document.getElementById("level-classic")?.addEventListener("click", () => this.handlers?.onClassic());
    document.getElementById("level-back")?.addEventListener("click", () => this.handlers?.onTitle());
    document.getElementById("level-reset")?.addEventListener("click", () => {
      if (window.confirm("确定重置 15 关的星级和解锁进度吗？")) {
        this.progress.reset();
        this.renderLevels();
        this.handlers?.onResetProgress();
      }
    });
    document.querySelectorAll("[data-open-help]").forEach((el) => el.addEventListener("click", () => this.handlers?.onHelp()));
    document.getElementById("end-next")?.addEventListener("click", () => this.handlers?.onNext());
    document.getElementById("end-restart")?.addEventListener("click", () => this.handlers?.onRestart());
    document.getElementById("end-map")?.addEventListener("click", () => this.handlers?.onMap());
    document.getElementById("end-title-btn")?.addEventListener("click", () => this.handlers?.onTitle());
    document.getElementById("end-share")?.addEventListener("click", () => this.handlers?.onShare());
    this.hudEl.addEventListener("pointerdown", (event) => {
      if ((event.target as HTMLElement).closest(".seed-dock, .side-panel, .top-bar")) event.stopPropagation();
    });
    this.root.addEventListener("pointerover", (event) => {
      const card = (event.target as HTMLElement | null)?.closest<HTMLElement>("[data-plant]");
      if (card) this.showPlantTip(card);
    });
    this.root.addEventListener("pointerout", (event) => {
      const card = (event.target as HTMLElement | null)?.closest<HTMLElement>("[data-plant]");
      if (card) this.hidePlantTip();
    });
  }

  private showPlantTip(card: HTMLElement) {
    const id = card.dataset.plant as PlantId | undefined;
    if (!id || !PLANTS[id]) return;
    const p = PLANTS[id];
    const tip = document.getElementById("plant-tip");
    if (!tip) return;
    tip.innerHTML = `<b>${p.name} <em>${p.role}</em></b><span>${p.desc}</span><small>${p.cost} 灵感 · 冷却 ${p.cooldown}s</small>`;
    tip.classList.add("show");
  }

  private hidePlantTip() {
    document.getElementById("plant-tip")?.classList.remove("show");
  }

  setBootProgress(ratio: number, status: string) {
    const fill = document.getElementById("boot-fill");
    if (fill) fill.style.width = `${Math.round(ratio * 100)}%`;
    setText(document.getElementById("boot-status"), `${Math.round(ratio * 100)}% · ${status}`);
  }

  hideBoot() {
    const boot = document.getElementById("boot-screen");
    if (!boot) return;
    boot.classList.add("done");
    window.setTimeout(() => boot.remove(), 600);
  }

  setHealth(info: HealthInfo) {
    this.health = info;
    const llm = info.llm?.online;
    const vision = info.vision?.ready;
    const llmChip = document.getElementById("title-llm-status");
    const yoloChip = document.getElementById("title-yolo-status");
    setText(llmChip, llm ? (info.llm.model ? info.llm.model.toUpperCase().slice(0, 24) : "ONLINE") : "FALLBACK");
    setText(yoloChip, vision ? "ARMED" : "STANDBY");
    document.getElementById("title-llm-dot")?.classList.toggle("wait", false);
    document.getElementById("title-llm-dot")?.classList.toggle("off", !llm);
    document.getElementById("title-yolo-dot")?.classList.toggle("off", !vision);
    document.getElementById("title-yolo-dot")?.classList.toggle("wait", false);

    setText(document.getElementById("hud-llm-status"), llm ? "LOCAL BRAIN ONLINE" : "OFFLINE / 备用人格");
    setText(document.getElementById("hud-model-label"), llm ? `LM STUDIO / ${(info.llm.model ?? "LOCAL").toUpperCase()}` : "FALLBACK / 本地备份人格");
    document.getElementById("hud-llm-dot")?.classList.toggle("off", !llm);
    document.getElementById("hud-llm-dot")?.classList.toggle("wait", false);
    setText(document.getElementById("hud-vision-status"), vision ? "YOLO READY" : "VISION OFFLINE");
    setText(document.getElementById("hud-vision-meta"), vision ? `${info.vision.device ?? "CPU"} / 自训练` : "后端未就绪");
  }

  get modelLabel(): string {
    if (!this.health?.llm.online) return "LOCAL FALLBACK";
    return (this.health.llm.model ?? "LOCAL LLM").toUpperCase();
  }

  showTitle() {
    this.titleEl.classList.remove("hidden");
    this.levelEl.classList.add("hidden");
    this.hudEl.classList.add("hidden");
    this.endEl.classList.remove("open");
  }

  showLevels() {
    this.renderLevels();
    const toastLayer = document.getElementById("toast-layer");
    if (toastLayer) toastLayer.innerHTML = "";
    this.titleEl.classList.add("hidden");
    this.levelEl.classList.remove("hidden");
    this.hudEl.classList.add("hidden");
    this.endEl.classList.remove("open");
  }

  renderLevels() {
    const grid = document.getElementById("level-grid");
    if (!grid) return;
    grid.innerHTML = LEVELS.map((lvl, index) => {
      const stars = this.progress.stars(lvl.id);
      const unlocked = this.progress.isUnlocked(index);
      const starHtml = [1, 2, 3]
        .map((n) => `<span class="${n <= stars ? "on" : ""}">★</span>`)
        .join("");
      const icon = lvl.index === 15 ? "zombie_emperor" : lvl.boss ? "zombie_boss" : PLANT_ORDER[(lvl.index + 2) % PLANT_ORDER.length];
      const iconSprite = lvl.boss ? icon : PLANTS[icon as PlantId].sprite;
      return `<button class="level-card ${unlocked ? "" : "locked"} ${stars ? "cleared" : ""}" data-level-index="${index}" ${unlocked ? "" : "disabled"} style="--accent:${lvl.accent}">
        <img class="level-icon" src="${asset(iconSprite)}" alt="" />
        <span class="level-index">L${String(lvl.index).padStart(2, "0")}</span>
        <span class="level-stamp">${lvl.stamp}</span>
        <span class="level-name">${lvl.name}</span>
        <span class="level-sub">${lvl.subtitle}</span>
        <span class="level-meta">${lvl.waves.length} WAVES · DIFF ${"●".repeat(lvl.difficulty)}${"○".repeat(5 - lvl.difficulty)}</span>
        <span class="level-stars" aria-label="${stars} 星">${starHtml}</span>
        ${lvl.boss ? '<span class="level-boss">BOSS</span>' : ""}
        ${unlocked ? "" : '<span class="level-lock">未解锁<br />先通关上一关</span>'}
      </button>`;
    }).join("");
    setText(document.getElementById("level-clear-count"), String(this.progress.clearedCount()));
    setText(document.getElementById("level-star-count"), String(this.progress.totalStars()));
  }

  showGame() {
    this.lastCardState.clear();
    this.titleEl.classList.add("hidden");
    this.levelEl.classList.add("hidden");
    this.hudEl.classList.remove("hidden");
    this.endEl.classList.remove("open");
  }

  update(dt: number) {
    if (!this.game || this.game.screen === "title") return;
    this.hudClock += dt;
    if (this.hudClock < 0.055) return;
    this.hudClock = 0;
    const game = this.game;
    const wave = Math.max(1, game.wave);
    const def = game.def;
    setText(document.getElementById("hud-level-label"), game.mode === "classic" ? "CLASSIC / 经典 10 波" : `${game.level?.id ?? "L01"} / ${game.levelName}`);
    setText(document.getElementById("hud-wave-num"), `WAVE ${String(wave).padStart(2, "0")} / ${String(game.totalWaves).padStart(2, "0")}`);
    setText(document.getElementById("hud-wave-name"), def.name);
    setText(document.getElementById("hud-sun"), String(Math.floor(game.sun)));
    const pod = Math.max(0, Math.ceil(game.houseHp));
    setText(document.getElementById("hud-pod-label"), `${pod}%`);
    const podFill = document.getElementById("hud-pod-fill");
    if (podFill) {
      podFill.style.width = `${pod}%`;
      podFill.classList.toggle("warn", pod <= 60 && pod > 25);
      podFill.classList.toggle("danger", pod <= 25);
    }

    const alive = game.zombies.filter((z) => !z.dead).length;
    const total = def.groups.reduce((a, g) => a + g.count, 0);
    let pct = 0;
    if (game.waveActive) {
      const remaining = alive + game.spawnQueue.length;
      pct = Math.max(0, Math.min(100, ((total - remaining) / total) * 100));
      setText(document.getElementById("hud-wave-sub"), "进行中");
      setText(document.getElementById("hud-wave-meta"), `本波总兵力 ${total} · 已清 ${game.stats.kills}`);
      setText(document.getElementById("hud-wave-count"), `剩余 ${alive} 只`);
    } else {
      pct = Math.max(0, Math.min(100, (1 - game.prepTimeLeft / Math.max(1, def.breakAfter)) * 100));
      setText(document.getElementById("hud-wave-sub"), "准备中");
      setText(document.getElementById("hud-wave-meta"), `下一波：${Math.max(0, game.prepTimeLeft).toFixed(1)}s`);
      setText(document.getElementById("hud-wave-count"), `剩余 ${alive} 只`);
    }
    const fill = document.getElementById("hud-wave-fill");
    if (fill) fill.style.width = `${pct}%`;

    const matchFill = document.getElementById("match-fill");
    const matchLabel = document.getElementById("match-label");
    const bossReadout = document.getElementById("boss-readout");
    const boss = game.zombies.find((z) => z.finalBoss && !z.dead);
    const matchPct = Math.round(game.matchProgress * 100);
    const matchLine = this.root.querySelector<HTMLElement>(".match-line");
    matchLine?.classList.toggle("boss-active", game.bossActive);
    if (matchFill) {
      matchFill.style.width = `${matchPct}%`;
      matchFill.classList.toggle("boss", game.bossActive || game.finalBossDefeated);
    }
    if (matchLabel) {
      matchLabel.textContent = game.finalBossDefeated
        ? "最终 BOSS 已击破"
        : boss
          ? `最终 BOSS ${Math.max(0, Math.ceil((boss.hp / boss.maxHp) * 100))}%`
          : `对局进程 ${matchPct}%`;
    }
    if (bossReadout) {
      bossReadout.textContent = game.finalBossDefeated ? "CLEAR" : game.bossActive ? game.bossName : "1/3 · 1/2 · BOSS";
      bossReadout.classList.toggle("active", game.bossActive);
    }

    for (const id of PLANT_ORDER) {
      const card = this.root.querySelector<HTMLElement>(`[data-plant="${id}"]`);
      if (!card) continue;
      const defP = PLANTS[id];
      const cd = game.cooldownLeft(id);
      const cost = game.plantCost(id);
      const affordable = game.sun >= cost;
      const cooling = cd > 0.05;
      const key = `${cooling}|${affordable}|${game.selected === id}|${Math.ceil(cd * 10)}`;
      if (this.lastCardState.get(id) !== key) {
        this.lastCardState.set(id, key);
        card.classList.toggle("cooling", cooling);
        card.classList.toggle("disabled", !affordable);
        card.classList.toggle("selected", game.selected === id);
        const cdLabel = card.querySelector(".card-cd-label");
        if (cdLabel) cdLabel.textContent = cooling ? `${cd.toFixed(1)}s` : "";
      }
      card.style.setProperty("--cd", cooling ? String(Math.min(1, cd / defP.cooldown)) : "0");
      const costEl = card.querySelector(".card-cost");
      if (costEl) setText(costEl, String(cost));
    }
    this.root.querySelector<HTMLElement>(".shovel-btn")?.classList.toggle("active", game.shovel);

    setText(document.getElementById("stat-kills"), String(game.stats.kills));
    setText(document.getElementById("stat-plants"), String(game.plants.length));
    setText(document.getElementById("stat-scans"), String(game.stats.yoloScans));
    setText(document.getElementById("hud-sync"), `${Math.round(game.visionSync)}%`);
    const syncFill = document.getElementById("hud-sync-fill");
    if (syncFill) syncFill.style.width = `${game.visionSync}%`;

    const report = game.visionReport;
    const counts = report?.counts ?? {};
    setText(document.getElementById("vc-plant"), String(counts.plant ?? 0));
    setText(document.getElementById("vc-zombie"), String(counts.zombie ?? 0));
    setText(document.getElementById("vc-boss"), String(counts.boss ?? 0));
    setText(document.getElementById("vc-sun"), String(counts.sun ?? 0));
    setText(
      document.getElementById("hud-vision-meta"),
      game.visionVisible
        ? report
          ? `${Math.round(report.ms)}ms / ${report.detections.length} 个目标`
          : "扫描中…"
        : "待机 / 点右侧开关",
    );
    document.getElementById("vision-switch")?.classList.toggle("on", game.visionVisible);
    document.getElementById("vision-switch")?.setAttribute("aria-pressed", String(game.visionVisible));
    const drawBtn = document.getElementById("vision-draw") as HTMLButtonElement | null;
    if (drawBtn) drawBtn.disabled = !game.visionVisible || game.visionSync < 25;
    const verdictText =
      game.visionVerdict || (game.visionVisible ? "YOLO 正在努力理解这个战场。" : "打开第三只眼，攒够同步率，抽一张离谱的判词。");
    const verdictEl = document.getElementById("vision-verdict");
    setText(verdictEl, verdictText);
    if (verdictEl) {
      verdictEl.title = verdictText;
      verdictEl.classList.toggle("bad", game.visionTone === "bad" || game.visionTone === "catastrophe");
      verdictEl.classList.toggle("catastrophe", game.visionTone === "catastrophe");
    }
    const chatOpen = this.root.querySelector<HTMLElement>(".chat-open");
    if (chatOpen) {
      const idle = game.screen === "playing" && !game.waveActive && game.time > 10;
      const label = chatOpen.querySelector("span");
      if (label) label.textContent = game.plantWipe ? "全灭！求妈妈救命" : idle ? "闲着？聊点难的" : "和奶龙说点什么";
      chatOpen.classList.toggle("urgent", game.plantWipe);
      chatOpen.classList.toggle("idle", idle && !game.plantWipe);
    }

    const ev = !game.waveActive && game.preparedEvent ? game.preparedEvent : game.currentEvent ?? game.preparedEvent;
    if (ev) {
      const preview = !game.waveActive && !!game.preparedEvent;
      setText(document.getElementById("director-title"), `${ev.title}${preview ? " · 预演" : ""}`);
      setText(document.getElementById("director-line"), ev.line);
      setText(document.getElementById("director-source"), ev.source === "llm" ? "LOCAL LLM" : "OFFLINE");
      const mod = MODIFIERS[ev.modifier];
      const chip = document.getElementById("director-modifier");
      if (chip) {
        chip.textContent = mod.label;
        chip.style.setProperty("--accent", mod.color);
      }
    }
  }

  setDialogue(text: string) {
    const el = document.getElementById("host-dialogue");
    if (!el) return;
    window.clearInterval(this.dialogueTimer);
    el.textContent = "";
    let i = 0;
    const chars = [...text];
    this.dialogueTimer = window.setInterval(() => {
      i += 2;
      el.textContent = chars.slice(0, i).join("");
      if (i >= chars.length) window.clearInterval(this.dialogueTimer);
    }, 18);
  }

  showBanner(wave: number, event: DirectorEvent) {
    const def = this.game?.def;
    const banner = document.getElementById("wave-banner");
    if (!banner || !def) return;
    const total = this.game?.totalWaves ?? wave;
    setText(document.getElementById("banner-wave"), `WAVE ${String(wave).padStart(2, "0")} / ${String(total).padStart(2, "0")}`);
    setText(document.getElementById("banner-title"), `${def.name} · ${event.title}`);
    setText(document.getElementById("banner-line"), event.line);
    const mod = MODIFIERS[event.modifier];
    setText(document.getElementById("banner-tag"), mod.label);
    banner.classList.add("show");
    window.clearTimeout(this.bannerTimer);
    this.bannerTimer = window.setTimeout(() => banner.classList.remove("show"), 4400);
    this.setDialogue(event.line);
  }

  toast(text: string, color = "#dfff43") {
    const layer = document.getElementById("toast-layer");
    if (!layer) return;
    const el = document.createElement("div");
    el.className = "toast";
    el.textContent = text;
    el.style.borderLeftColor = color;
    layer.appendChild(el);
    while (layer.children.length > 4) layer.firstElementChild?.remove();
    window.setTimeout(() => {
      el.classList.add("out");
      window.setTimeout(() => el.remove(), 320);
    }, 3800);
  }

  renderHowtoHTML(): string {
    const items = [
      ["01", "选卡，再点地", "底部有 11 只奶龙科植物。点一张卡，再点苗圃空格。冷却中的卡不能种，灵感不够也不能种；铲子回收 25% 灵感。", "plant_seal"],
      ["02", "捡起每一颗灵感", "天上会掉灵感，奶龙花也会吐。点它们。别客气，这不是偷，是拾荒。", "sun"],
      ["03", "守住左边的门", "每条道有一发宿管拖鞋，僵尸靠近时自动发射。拖鞋用完后，僵尸会啃睡眠舱；舱体归零就结束。", "slipper"],
      ["04", "AI 导演 + 第三只眼", "每波开始前，本地 Qwen 会写台本并从 10 种事件里挑一个。打开第三只眼，自训练 YOLO 会实时扫描战场；按 X 花 25% 同步率抽一张「抽象解读」，攒满还会随机过载。", "plant_fan"],
    ];
    return items
      .map(
        ([n, title, body, img], i) => `<div class="howto-item"><div class="n">${n} / ${i === 3 ? "AI" : "PLAY"}</div><h4>${title}</h4><p>${body}</p><img class="mini-art" src="${asset(img)}" alt="" /></div>`,
      )
      .join("");
  }

  showEnd(
    win: boolean,
    stats: GameStats,
    quote: string,
    opts: { levelIndex: number; levelName: string; stars: number; nextIndex: number | null; mode: "level" | "classic" },
  ) {
    const grade = this.gradeFor(win, stats, opts.stars);
    setText(document.getElementById("end-title"), win ? "早八，防住了" : "睡眠舱，失守");
    setText(document.getElementById("end-quote"), quote);
    setText(document.getElementById("end-grade"), grade.grade);
    setText(document.getElementById("end-grade-title"), grade.title);
    setText(document.getElementById("end-grade-note"), grade.note);
    setText(document.getElementById("end-level"), opts.mode === "classic" ? "CLASSIC" : `L${String(opts.levelIndex + 1).padStart(2, "0")} · ${opts.levelName}`);
    const starEl = document.getElementById("end-stars");
    if (starEl) {
      starEl.innerHTML = [1, 2, 3].map((n) => `<span class="${win && n <= opts.stars ? "on" : ""}">★</span>`).join("");
      starEl.classList.toggle("lost", !win);
    }
    const next = document.getElementById("end-next");
    if (next) next.classList.toggle("hidden", !(win && opts.nextIndex !== null));
    const restart = document.getElementById("end-restart");
    if (restart) restart.innerHTML = `<span>${opts.mode === "classic" ? "再打一次" : "重打本关"}</span><span class="arrow">↻</span>`;
    const statsEl = document.getElementById("end-stats");
    if (statsEl) {
      const rows: [string, string][] = [
        [String(stats.waves), "WAVES SURVIVED / 波次"],
        [String(stats.kills), "KILLS / 击杀"],
        [String(stats.plantsPlaced), "PLANTS PLANTED / 种植"],
        [String(stats.sunCollected), "SUN COLLECTED / 灵感"],
        [String(stats.yoloScans), "YOLO SCANS / 扫描"],
        [`${Math.floor(stats.time / 60)}:${String(Math.floor(stats.time % 60)).padStart(2, "0")}`, "TIME / 存活"],
      ];
      if (stats.carries) rows.splice(2, 0, [String(stats.carries), "SUNFLOWER CARRY / 抱走"]);
      statsEl.innerHTML = rows.map(([v, k]) => `<div class="end-stat"><b>${v}</b><span>${k}</span></div>`).join("");
    }
    this.endEl.classList.add("open");
    this.levelEl.classList.add("hidden");
    this.hudEl.classList.add("hidden");
    this.titleEl.classList.add("hidden");
  }

  hideEnd() {
    this.endEl.classList.remove("open");
    this.hudEl.classList.remove("hidden");
  }

  gradeFor(win: boolean, stats: GameStats, stars = 0) {
    if (win) {
      if (stars >= 3) {
        return { grade: "S", title: "睡眠守护神", note: "三星通关。你在几乎没有睡觉的情况下，守住了睡觉的地方。这是本季度最抽象的壮举。" };
      }
      if (stars === 2) {
        return { grade: "A", title: "早八幸存者", note: "你活下来了。植物们一致认为你还有进步空间，但它们不想说话。" };
      }
      return { grade: "B", title: "低空飘过", note: "门保住了，但门框有点歪。下一关记得先补墙。" };
    }
    const ratio = stats.waves / Math.max(1, stats.totalWaves ?? 10);
    if (ratio >= 0.66) {
      return { grade: "B", title: "差一点就体面", note: "你守到了很后面。睡眠舱倒下的声音，像极了你每天早上按掉的闹钟。" };
    }
    return { grade: "C", title: "床的叛徒", note: "这不是失败，是一次关于睡眠重要性的昂贵演示。" };
  }

  howtoMarkup(): string {
    return `<div class="modal howto">
      <button class="modal-close" data-close aria-label="关闭">×</button>
      <div class="modal-kicker">FIELD MANUAL / 生存手册 · 30 秒读完</div>
      <h2>怎么守住一张床</h2>
      <p class="lead">这是一个植物大战僵尸式的六路塔防，但你的对手是早八，你的资源是灵感，你的军师是一个本地大模型。15 关、11 只奶龙科植物、3 星评价；先记住：植物会死，床不能。摄像头打不开也没关系，现实裂隙里可以直接上传照片让 YOLO 看。</p>
      <div class="howto-grid">${this.renderHowtoHTML()}</div>
      <div class="howto-secret"><b>隐藏特性 / 奶龙花笑到停战</b><span>有僵尸走到奶龙花面前时，双方会突然爆笑。僵尸不啃了，转身把花抱回右边；花会留下 50 灵感。每只非 Boss 僵尸都会触发，没有概率。</span></div>
      <div class="howto-foot"><span>快捷键：1–9 / 0 选植物 · S 铲子 · V 第三只眼 · X 抽象解读 · T 对话 · P 暂停</span><span>LOCAL LLM × YOLO / MADE FOR AIU</span></div>
    </div>`;
  }

  pauseMarkup(stats: GameStats): string {
    const time = `${Math.floor(stats.time / 60)}:${String(Math.floor(stats.time % 60)).padStart(2, "0")}`;
    return `<div class="modal pause-modal">
      <button class="modal-close" data-close aria-label="关闭">×</button>
      <div class="modal-kicker">SYSTEM HALT / 实验暂停</div>
      <h2>暂停</h2>
      <div class="sub">你按下了时间。僵尸很困惑，植物趁机喝了一口水。<br />${this.game?.levelName ?? "本局"} · ${time} · 第 ${stats.waves} 波 · ${stats.kills} 击杀</div>
      <div class="pause-actions">
        <button class="btn primary" id="pause-resume"><span>继续装睡</span><span class="arrow">→</span></button>
        <button class="btn" id="pause-help">查看生存手册</button>
        <button class="btn ghost" id="pause-restart">重新开始一局</button>
        <button class="btn ghost" id="pause-title">放弃并回到标题</button>
      </div>
    </div>`;
  }

  setSoundButton(active: boolean) {
    this.root.querySelector<HTMLElement>('[data-action="sound"]')?.classList.toggle("active", active);
  }

  setMusicButton(active: boolean) {
    this.root.querySelector<HTMLElement>('[data-action="music"]')?.classList.toggle("active", active);
  }
}
