import type { Game } from "../game/engine";
import type { AgentClient } from "../agent/client";
import type { Detection, VisionReport } from "../types";
import type { ModalHost } from "./modal";

const LABELS: Record<string, string> = {
  person: "人类",
  cup: "杯子",
  book: "书",
  cell_phone: "手机",
  laptop: "电脑",
  bottle: "瓶子",
  keyboard: "键盘",
  mouse: "鼠标",
  banana: "香蕉",
  apple: "苹果",
  chair: "椅子",
  backpack: "书包",
  clock: "闹钟",
  teddy_bear: "玩偶",
  handbag: "包",
};

const COLORS: Record<string, string> = {
  person: "#ff3d8d",
  cup: "#69e7ff",
  book: "#dfff43",
  cell_phone: "#ffd447",
  laptop: "#6ff2a1",
};

type Mode = "idle" | "camera" | "photo";

export class CameraController {
  private game: Game;
  private agent: AgentClient;
  private modal: ModalHost;
  private stream: MediaStream | null = null;
  private timer: number | null = null;
  private video: HTMLVideoElement | null = null;
  private photo: HTMLImageElement | null = null;
  private overlay: HTMLCanvasElement | null = null;
  private busy = false;
  private lastBonus = 0;
  private detections: Detection[] = [];
  private opened = false;
  private mode: Mode = "idle";
  private photoUrl: string | null = null;
  private onClose?: () => void;

  constructor(game: Game, agent: AgentClient, modal: ModalHost) {
    this.game = game;
    this.agent = agent;
    this.modal = modal;
  }

  open(onClose?: () => void) {
    if (this.opened) return;
    this.opened = true;
    this.onClose = onClose;
    const el = this.modal.show(
      `<div class="modal camera-modal">
        <button class="modal-close" data-close aria-label="关闭">×</button>
        <div class="camera-head">
          <div>
            <div class="modal-kicker">REALITY BREACH / 现实裂隙 · EXPERIMENTAL</div>
            <h2>让 YOLO 看一眼现实</h2>
            <p>摄像头或图片只在本机处理：浏览器 → <code>127.0.0.1:8000</code> → COCO YOLO11n，不上传云端。认出一件物品，奶龙偷 15 灵感（7 秒冷却）。</p>
          </div>
          <div class="model-pill" style="background:var(--ink);color:var(--cyan);font-family:var(--mono);font-size:8px;padding:6px 9px;transform:rotate(2deg)">COCO / YOLO11N</div>
        </div>
        <div class="camera-stage">
          <div class="camera-feed" id="camera-feed">
            <video id="camera-video" playsinline muted autoplay></video>
            <img id="camera-photo" alt="上传的测试图片" />
            <canvas id="camera-overlay" class="cam-overlay" width="640" height="480"></canvas>
            <div class="cam-hint" id="camera-hint">
              <div class="big">CAMERA // 未连接</div>
              <div>先点「开启摄像头」。如果没有权限，按下面的三步排查，<br />或者直接上传一张照片测试 YOLO。</div>
            </div>
          </div>
          <div class="camera-info">
            <div class="cam-stat"><div class="k">OBJECTS / 当前识别</div><div class="v" id="cam-objects">—</div></div>
            <div class="cam-stat"><div class="k">LATENCY / 推理延迟</div><div class="v" id="cam-latency">— ms</div></div>
            <div class="cam-stat"><div class="k">REALITY BONUS / 现实收益</div><div class="v" id="cam-bonus">0</div></div>
            <div class="cam-log" id="cam-log">&gt; 等待选择输入源……</div>
            <div class="camera-diagnostic" id="camera-diagnostic">
              <div><span>SECURE CONTEXT</span><b id="cam-secure">…</b></div>
              <div><span>MEDIA API</span><b id="cam-api">…</b></div>
              <div><span>PERMISSION</span><b id="cam-permission">…</b></div>
              <div><span>CAMERAS</span><b id="cam-devices">…</b></div>
            </div>
          </div>
        </div>
        <div class="camera-actions">
          <button class="btn small" id="camera-start">开启摄像头</button>
          <button class="btn small ghost" id="camera-retry">重新请求</button>
          <label class="btn small file-btn" for="camera-file">上传照片测试</label>
          <input id="camera-file" type="file" accept="image/*" hidden />
          <select id="camera-device" class="camera-device" aria-label="选择摄像头"><option value="">默认摄像头</option></select>
          <button class="btn small ghost" data-close>回到游戏</button>
        </div>
        <div class="camera-help">
          <b>打不开？</b> ① 地址栏左侧的锁/相机图标 → 允许摄像头；② Windows 设置 → 隐私和安全性 → 相机 → 允许桌面应用访问相机；③ 关掉微信/腾讯会议/OBS 等占用摄像头的应用。如果是从应用内预览窗口打开的，请复制地址到外部浏览器（<code>http://127.0.0.1:8000</code> 或 <code>localhost:8000</code>），iframe 可能禁用摄像头。还不行就上传照片，YOLO 照样能看。
        </div>
      </div>`,
      () => {
        this.cleanup();
        this.opened = false;
        this.onClose?.();
      },
    );
    this.video = el.querySelector<HTMLVideoElement>("#camera-video");
    this.photo = el.querySelector<HTMLImageElement>("#camera-photo");
    this.overlay = el.querySelector<HTMLCanvasElement>("#camera-overlay");
    el.querySelector<HTMLButtonElement>("#camera-start")?.addEventListener("click", () => void this.start());
    el.querySelector<HTMLButtonElement>("#camera-retry")?.addEventListener("click", () => void this.start(true));
    el.querySelector<HTMLSelectElement>("#camera-device")?.addEventListener("change", () => {
      if (this.mode === "camera") void this.start(true);
    });
    el.querySelector<HTMLInputElement>("#camera-file")?.addEventListener("change", (event) => {
      const file = (event.target as HTMLInputElement).files?.[0];
      if (file) void this.loadPhoto(file);
    });
    void this.refreshDiagnostics();
  }

  private log(text: string) {
    const el = document.getElementById("cam-log");
    if (!el) return;
    const line = document.createElement("div");
    line.textContent = text;
    el.appendChild(line);
    while (el.children.length > 30) el.firstElementChild?.remove();
    el.scrollTop = el.scrollHeight;
  }

  private setStatus(text: string, kind = "") {
    const hint = document.getElementById("camera-hint");
    if (!hint) return;
    hint.style.display = "flex";
    hint.innerHTML = `<div class="big ${kind}">${text}</div><div>没有画面也可以上传照片让 YOLO 看。照片只在本机处理。</div>`;
  }

  private async refreshDiagnostics() {
    const secure = window.isSecureContext;
    const hasMedia = !!navigator.mediaDevices?.getUserMedia;
    setText("cam-secure", secure ? "YES" : "NO");
    setText("cam-api", hasMedia ? "AVAILABLE" : "MISSING");
    document.getElementById("cam-secure")?.classList.toggle("bad", !secure);
    document.getElementById("cam-api")?.classList.toggle("bad", !hasMedia);
    let permission = "unknown";
    try {
      const status = await navigator.permissions.query({ name: "camera" as PermissionName });
      permission = status.state;
      status.onchange = () => {
        setText("cam-permission", status.state.toUpperCase());
        this.log(`> 权限状态变化：${status.state}`);
      };
    } catch {
      permission = "unsupported";
    }
    setText("cam-permission", permission.toUpperCase());
    document.getElementById("cam-permission")?.classList.toggle("bad", permission === "denied");
    const count = await this.listDevices(false);
    setText("cam-devices", `${count} FOUND`);
    if (!secure) this.log("! 当前不是安全上下文；请用 http://127.0.0.1:8000 或 localhost。");
    if (!hasMedia) this.log("! 这个浏览器没有暴露 navigator.mediaDevices。");
  }

  private async listDevices(requestLabels = true): Promise<number> {
    const select = document.getElementById("camera-device") as HTMLSelectElement | null;
    try {
      const devices = await navigator.mediaDevices.enumerateDevices();
      const cameras = devices.filter((d) => d.kind === "videoinput");
      if (select) {
        const current = select.value;
        select.innerHTML = `<option value="">默认摄像头</option>`;
        cameras.forEach((d, i) => {
          const opt = document.createElement("option");
          opt.value = d.deviceId;
          opt.textContent = d.label || `摄像头 ${i + 1}${requestLabels ? "" : "（授权后显示名称）"}`;
          select.appendChild(opt);
        });
        if (current && cameras.some((d) => d.deviceId === current)) select.value = current;
      }
      return cameras.length;
    } catch {
      return 0;
    }
  }

  private async start(retry = false) {
    if (retry) {
      this.stopStream();
      this.photoUrl && URL.revokeObjectURL(this.photoUrl);
      this.photoUrl = null;
    }
    this.setStatus("CAMERA // 正在请求权限");
    const startBtn = document.getElementById("camera-start") as HTMLButtonElement | null;
    if (startBtn) {
      startBtn.textContent = "请求中…";
      startBtn.disabled = true;
    }
    try {
      if (!window.isSecureContext) throw new Error("NOT_SECURE");
      if (!navigator.mediaDevices?.getUserMedia) throw new Error("NO_MEDIA_API");
      const select = document.getElementById("camera-device") as HTMLSelectElement | null;
      const selected = select?.value || "";
      const attempts: MediaStreamConstraints[] = selected
        ? [{ video: { deviceId: { exact: selected }, width: { ideal: 640 }, height: { ideal: 480 } }, audio: false }]
        : [
            { video: { width: { ideal: 640 }, height: { ideal: 480 }, facingMode: "user" }, audio: false },
            { video: true, audio: false },
          ];
      let lastError: unknown = null;
      let stream: MediaStream | null = null;
      for (const constraints of attempts) {
        try {
          stream = await navigator.mediaDevices.getUserMedia(constraints);
          break;
        } catch (err) {
          lastError = err;
          const name = (err as DOMException)?.name;
          // Overconstrained/NotFound can be cured by the simpler `video: true`.
          if (name !== "OverconstrainedError" && name !== "NotFoundError") break;
        }
      }
      if (!stream) throw lastError ?? new Error("no stream");
      this.stream = stream;
      this.mode = "camera";
      const video = this.video;
      if (!video) return;
      if (this.photo) this.photo.style.display = "none";
      video.style.display = "block";
      video.srcObject = stream;
      await video.play();
      document.getElementById("camera-hint")!.style.display = "none";
      this.log("> 摄像头已连接。开始把现实喂给 YOLO。");
      setText("cam-permission", "GRANTED");
      document.getElementById("cam-permission")?.classList.remove("bad");
      const count = await this.listDevices(true);
      setText("cam-devices", `${count} FOUND`);
      const health = await this.agent.checkHealth();
      if (health.vision.ready) this.log(`> 模型在线：${health.vision.model ?? "yolo11n"}`);
      else this.log("! 后端 YOLO 未就绪，检测请求可能失败。");
      if (this.timer) window.clearInterval(this.timer);
      this.timer = window.setInterval(() => void this.tick(), 780);
      if (startBtn) {
        startBtn.textContent = "摄像头已开启";
        startBtn.disabled = true;
      }
      void this.tick();
    } catch (err) {
      this.handleCameraError(err);
      if (startBtn) {
        startBtn.textContent = "开启摄像头";
        startBtn.disabled = false;
      }
    }
  }

  private handleCameraError(err: unknown) {
    const name = (err as DOMException)?.name ?? String(err);
    let text = "CAMERA // 打不开";
    let detail = `浏览器返回：${name}`;
    if (name === "NotAllowedError" || name === "PermissionDeniedError") {
      text = "CAMERA // 权限被拒绝";
      detail = "地址栏左侧锁/相机图标 → 摄像头 → 允许；再检查 Windows 隐私设置：相机 → 允许桌面应用访问。";
    } else if (name === "NotFoundError" || name === "DevicesNotFoundError") {
      text = "CAMERA // 没找到设备";
      detail = "Windows 设备管理器里没有可用摄像头。可以先上传照片测试 YOLO。";
    } else if (name === "NotReadableError" || name === "TrackStartError" || name === "AbortError") {
      text = "CAMERA // 被占用";
      detail = "关掉微信、腾讯会议、OBS、相机等占用摄像头的应用，再点「重新请求」。";
    } else if (name === "NOT_SECURE") {
      text = "CAMERA // 非安全地址";
      detail = "请用 http://127.0.0.1:8000 或 http://localhost:8000 打开，别用局域网 IP。";
    } else if (name === "NO_MEDIA_API") {
      text = "CAMERA // 浏览器不支持";
      detail = "请用最新版 Edge/Chrome；或上传照片测试。";
    } else if (name === "NotAllowedError" || name === "SecurityError") {
      detail = "浏览器安全策略拒绝了摄像头。请用 127.0.0.1 打开并允许权限。";
    }
    this.setStatus(text, "warn");
    this.log(`! ${detail}`);
    setText("cam-permission", name === "NotAllowedError" ? "DENIED" : name.toUpperCase());
    document.getElementById("cam-permission")?.classList.add("bad");
  }

  private async loadPhoto(file: File) {
    this.stopStream();
    if (this.photoUrl) URL.revokeObjectURL(this.photoUrl);
    this.photoUrl = URL.createObjectURL(file);
    this.mode = "photo";
    const photo = this.photo;
    if (!photo) return;
    photo.src = this.photoUrl;
    photo.style.display = "block";
    if (this.video) this.video.style.display = "none";
    document.getElementById("camera-hint")!.style.display = "none";
    this.log(`> 已载入照片：${file.name}，开始单帧推理。`);
    await photo.decode().catch(() => undefined);
    await this.detectPhoto();
  }

  private async detectPhoto() {
    const photo = this.photo;
    const overlay = this.overlay;
    if (!photo || !overlay || !photo.naturalWidth) return;
    try {
      const canvas = document.createElement("canvas");
      canvas.width = 640;
      canvas.height = Math.round((photo.naturalHeight / photo.naturalWidth) * 640);
      const ctx = canvas.getContext("2d");
      if (!ctx) return;
      ctx.drawImage(photo, 0, 0, canvas.width, canvas.height);
      const report = await this.agent.vision(canvas.toDataURL("image/jpeg", 0.78), "real", 0.3);
      this.detections = report.detections ?? [];
      this.drawOverlay(overlay.width / canvas.width, overlay.height / canvas.height);
      this.updateStats(report);
      const counts = report.counts ?? {};
      if (Object.keys(counts).length && performance.now() - this.lastBonus > 7000) {
        this.lastBonus = performance.now();
        const first = this.detections[0];
        if (first) {
          this.game.realityBonus(first.label || LABELS[first.class] || first.class);
          const bonus = document.getElementById("cam-bonus");
          if (bonus) bonus.textContent = String(Number(bonus.textContent || 0) + 15);
        }
      }
    } catch (err) {
      this.log(`! 图片推理失败：${String(err).slice(0, 120)}`);
    }
  }

  private async tick() {
    if (this.mode !== "camera" || this.busy || !this.video || !this.overlay) return;
    if (this.video.readyState < 2) return;
    this.busy = true;
    try {
      const vw = this.video.videoWidth || 640;
      const vh = this.video.videoHeight || 480;
      const off = document.createElement("canvas");
      off.width = 640;
      off.height = 480;
      const ctx = off.getContext("2d");
      if (!ctx) return;
      ctx.drawImage(this.video, 0, 0, 640, 480);
      const image = off.toDataURL("image/jpeg", 0.72);
      const report: VisionReport = await this.agent.vision(image, "real", 0.3);
      this.detections = report.detections ?? [];
      this.drawOverlay(vw / 640, vh / 480);
      this.updateStats(report);
      const fresh = this.detections.find((d) => d.class && performance.now() - this.lastBonus > 7000);
      if (fresh) {
        this.lastBonus = performance.now();
        this.game.realityBonus(fresh.label || LABELS[fresh.class] || fresh.class);
        const bonus = document.getElementById("cam-bonus");
        if (bonus) bonus.textContent = String(Number(bonus.textContent || 0) + 15);
      }
    } catch (err) {
      this.log(`! 推理请求失败：${String(err).slice(0, 120)}`);
    } finally {
      this.busy = false;
    }
  }

  private drawOverlay(scaleX: number, scaleY: number) {
    const canvas = this.overlay;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    for (const d of this.detections) {
      const color = COLORS[d.class] ?? "#ffffff";
      const x = d.x * scaleX;
      const y = d.y * scaleY;
      const w = d.w * scaleX;
      const h = d.h * scaleY;
      ctx.strokeStyle = color;
      ctx.lineWidth = 2;
      ctx.strokeRect(x, y, w, h);
      ctx.fillStyle = color;
      const label = `${LABELS[d.class] ?? d.class} ${(d.confidence * 100).toFixed(0)}%`;
      ctx.font = "12px 'Courier New', monospace";
      const tw = ctx.measureText(label).width;
      ctx.globalAlpha = 0.85;
      ctx.fillRect(x, Math.max(0, y - 17), tw + 8, 17);
      ctx.globalAlpha = 1;
      ctx.fillStyle = "#140b23";
      ctx.fillText(label, x + 4, Math.max(12, y - 4));
    }
    ctx.strokeStyle = "rgba(105,231,255,.55)";
    ctx.lineWidth = 1;
    ctx.strokeRect(8, 8, canvas.width - 16, canvas.height - 16);
    ctx.fillStyle = "rgba(105,231,255,.8)";
    ctx.font = "10px 'Courier New', monospace";
    ctx.fillText(this.mode === "photo" ? "YOLO11N · PHOTO" : "YOLO11N · REAL-TIME", 14, 23);
  }

  private updateStats(report: VisionReport) {
    const objects = document.getElementById("cam-objects");
    const latency = document.getElementById("cam-latency");
    if (objects) objects.textContent = String(report.detections.length);
    if (latency) latency.textContent = `${Math.round(report.ms)} ms`;
    if (report.detections.length) {
      const summary = Object.entries(report.counts)
        .map(([k, v]) => `${LABELS[k] ?? k}×${v}`)
        .join(" / ");
      this.log(`> ${report.source} | ${summary}`);
    } else {
      this.log("> 没识别到日常物品。把杯子/手机/书举到画面里再试。");
    }
  }

  private stopStream() {
    if (this.timer) window.clearInterval(this.timer);
    this.timer = null;
    this.stream?.getTracks().forEach((t) => t.stop());
    this.stream = null;
    this.busy = false;
  }

  private cleanup() {
    this.stopStream();
    if (this.photoUrl) URL.revokeObjectURL(this.photoUrl);
    this.photoUrl = null;
    this.video = null;
    this.photo = null;
    this.overlay = null;
    this.detections = [];
    this.lastBonus = 0;
    this.mode = "idle";
  }

  close() {
    this.modal.close();
  }
}

function setText(id: string, text: string) {
  const el = document.getElementById(id);
  if (el) el.textContent = text;
}
