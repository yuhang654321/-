const SPRITE_NAMES = [
  "plant_flower",
  "plant_pea",
  "plant_doublepea",
  "plant_wall",
  "plant_frost",
  "plant_fan",
  "plant_bomb",
  "plant_cannon",
  "plant_vacuum",
  "plant_boomerang",
  "plant_seal",
  "zombie_basic",
  "zombie_fast",
  "zombie_paper",
  "zombie_coffee",
  "zombie_shield",
  "zombie_ranged",
  "zombie_weird",
  "zombie_boss",
  "zombie_emperor",
  "mascot_nailong",
  "mascot_face",
  "sun",
  "projectile_speech",
  "projectile_ddl",
  "slipper",
  "house",
  "daisy",
  "mushroom",
  "tape",
] as const;

export type SpriteName = (typeof SPRITE_NAMES)[number];

const images = new Map<string, HTMLImageElement>();
let loaded = false;

export async function preloadSprites(onProgress?: (ratio: number) => void): Promise<void> {
  if (loaded) return;
  let done = 0;
  await Promise.all(
    SPRITE_NAMES.map(
      (name) =>
        new Promise<void>((resolve) => {
          const img = new Image();
          img.decoding = "async";
          img.onload = () => {
            images.set(name, img);
            done++;
            onProgress?.(done / SPRITE_NAMES.length);
            resolve();
          };
          img.onerror = () => {
            console.error("sprite failed", name);
            done++;
            onProgress?.(done / SPRITE_NAMES.length);
            resolve();
          };
          img.src = `${import.meta.env.BASE_URL}assets/sprites/${name}.png`;
        }),
    ),
  );
  loaded = true;
}

export function sprite(name: string): HTMLImageElement | undefined {
  return images.get(name);
}
