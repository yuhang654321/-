import { LEVELS } from "./content";

const KEY = "nailong_protocol_progress_v2";

export interface ProgressData {
  version: 2;
  stars: Record<string, number>;
  lastPlayed?: string;
  classicCleared: boolean;
}

const empty = (): ProgressData => ({ version: 2, stars: {}, classicCleared: false });

export class ProgressStore {
  private data: ProgressData;

  constructor() {
    this.data = this.load();
  }

  private load(): ProgressData {
    try {
      const raw = localStorage.getItem(KEY);
      if (!raw) return empty();
      const parsed = JSON.parse(raw) as Partial<ProgressData>;
      if (parsed.version !== 2 || typeof parsed.stars !== "object") return empty();
      const stars: Record<string, number> = {};
      for (const [id, value] of Object.entries(parsed.stars ?? {})) {
        const n = Math.max(0, Math.min(3, Number(value) || 0));
        if (n > 0) stars[id] = n;
      }
      return {
        version: 2,
        stars,
        lastPlayed: parsed.lastPlayed,
        classicCleared: !!parsed.classicCleared,
      };
    } catch {
      return empty();
    }
  }

  private save() {
    localStorage.setItem(KEY, JSON.stringify(this.data));
  }

  stars(levelId: string): number {
    return this.data.stars[levelId] ?? 0;
  }

  totalStars(): number {
    return Object.values(this.data.stars).reduce((a, b) => a + b, 0);
  }

  clearedCount(): number {
    return Object.values(this.data.stars).filter((v) => v > 0).length;
  }

  isUnlocked(index: number): boolean {
    if (index <= 0) return true;
    // A level unlocks when the immediately previous level has been cleared.
    return this.stars(LEVELS[index - 1].id) > 0;
  }

  complete(levelId: string, stars: number, lastPlayed = levelId) {
    const safe = Math.max(1, Math.min(3, Math.round(stars)));
    this.data.stars[levelId] = Math.max(this.data.stars[levelId] ?? 0, safe);
    this.data.lastPlayed = lastPlayed;
    this.save();
  }

  completeClassic() {
    this.data.classicCleared = true;
    this.save();
  }

  reset() {
    this.data = empty();
    this.save();
  }

  nextUncleared(): number {
    for (let i = 0; i < LEVELS.length; i++) {
      if (this.stars(LEVELS[i].id) === 0) return this.isUnlocked(i) ? i : Math.max(0, i - 1);
    }
    return LEVELS.length - 1;
  }

  lastPlayedIndex(): number {
    const found = LEVELS.findIndex((l) => l.id === this.data.lastPlayed);
    return found >= 0 ? found : 0;
  }
}
