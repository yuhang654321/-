# 自训练 YOLO：数据、训练与接入

## 为什么是“游戏视觉模型”

任务要求跑通 YOLO 训练 + 实时推理并接入应用。最省事的做法是拿 COCO 预训练模型直接当“AI”展示，但那样和游戏没有关系。

我们选择让模型识别 **游戏自己画出来的东西**：

`plant` / `zombie` / `boss` / `sun` / `projectile`

这样检测结果能直接回灌玩法：第三只眼看到的植物/僵尸越多，认知同步涨得越快；满槽触发认知过载。模型确实在“看”这个游戏，而不是在看一张不相干的演示图。

## 数据从哪来

没有现成数据集，全部由 `training/make_dataset.py` 合成：

1. 从 `public/assets/sprites/` 读取 26 张原创精灵（含 10 种植物与早八皇帝）；
2. 生成接近游戏苗圃的背景（深紫背景、奶绿色五条道、九列格线、粉笔线、贴纸、纸片、噪点）；
3. 按类别随机缩放/旋转/透明度/位置，生成 1–12 个目标；
4. 叠加遮挡、曝光、对比度、高斯模糊、胶片颗粒、JPEG 压缩；
5. 用精灵 alpha bbox 生成 YOLO 标注。

2.1 规模（五只敌人重绘后）：

- train: 1,000
- val: 200

类别分布（验证集）：

| class | instances |
| --- | ---: |
| plant | 486 |
| zombie | 466 |
| boss | 27 |
| sun | 194 |
| projectile | 313 |
| **总计** | **1,486** |

样例（框由脚本按 alpha bbox 生成，非人工标注）：

![dataset](training/dataset_contact.jpg)

## 训练配置

```text
model:      yolo11n.pt -> v1 best -> v2 fine-tune
data:       1000 train / 200 val (10 plants + 5 enemies + emperor)
imgsz:      640
batch:      16
optimizer:  AdamW (Ultralytics auto)
amp:        false (Windows + AMP check 需要额外下载，禁用后更可控)
device:     RTX 5070 Laptop 12GB / CUDA 12.8
epochs:     10（v2 从 v1 权重继续训练）
seed:       20261025
```

复现：

```powershell
python training/make_dataset.py --train 1000 --val 200
python training/train.py --epochs 10 --batch 16 --device 0 --weights models/yolo11n.pt
```

> 本次交付权重从上一版 v2 继续训练；仓库只保留最终 v2.1 与 COCO 权重。用 `yolo11n.pt` 从头训练可复现近似量级，指标会略有波动。

`training/train.py` 会先训练，再用 best.pt 做一次 validation，把 best 复制到 `models/abstract_yolo.pt`，并生成 `training/metrics.json`。

## 指标

同分布 v2 验证集：

| metric | value |
| --- | ---: |
| mAP50 | **0.982** |
| mAP50-95 | **0.883** |
| Precision | **0.995** |
| Recall | **0.970** |

各类 mAP50：

| class | mAP50 | mAP50-95 |
| --- | ---: | ---: |
| plant | 0.982 | 0.922 |
| zombie | 0.995 | 0.964 |
| boss | 0.995 | 0.984 |
| sun | 0.984 | 0.798 |
| projectile | 0.952 | 0.746 |

完整混淆矩阵、PR 曲线、验证集预测图：

- [`metrics.json`](training/metrics.json)
- [`confusion_matrix.png`](training/confusion_matrix.png)
- [`BoxPR_curve.png`](training/BoxPR_curve.png)
- [`val_batch0_pred.jpg`](training/val_batch0_pred.jpg)
- [`train_results.csv`](training/train_results.csv)

## 真实游戏截图上的表现

用 1600×900 游戏画面裁切苗圃（846×520）测试：

| 场景 | 结果 |
| --- | --- |
| 10 植物 / 5 僵尸 / 1 灵感 | 约 10–15 植物、4–6 僵尸、1 灵感（含少量 UI/贴纸假阳性） |
| 满屏 Boss 战 | 6–8 植物、5–6 僵尸、1 Boss、1 灵感 |
| 单帧延迟 | 24–31 ms（CUDA，含前后处理） |
| 首次加载 | 约 17 s（模型 warmup，之后正常） |

真实游戏截图有 1–2 个假阳性/漏检，这是正常的。游戏把它当成「第三只眼也会看错」的节目效果，而不是要求 100% 精准。

## 接入方式

```python
# server/vision.py
model = YOLO("models/abstract_yolo.pt")
results = model.predict(source=image, imgsz=640, conf=0.45, device=0)
```

前端：

```ts
// 只裁苗圃，避免卡牌/头像误检
cropCtx.drawImage(canvas, BOARD.x, BOARD.y, BOARD.w, BOARD.h, 0, 0, BOARD.w, BOARD.h);
const report = await agent.vision(crop.toDataURL("image/jpeg", 0.72), "abstract");
game.setVisionReport(report, BOARD.x, BOARD.y);
```

## 局限

- 只训练了游戏精灵，**不能**用于真实世界检测。
- 合成域和真实游戏画面仍有轻微差异（缩放、JPEG、UI 叠层）。
- 类别 `projectile` 很小，mAP50-95 只有 0.746；在游戏里它不影响主玩法，只参与同步槽计数。
- 摄像头模式用的是 COCO `yolo11n.pt`，与 `abstract_yolo.pt` 是两套权重。

## 许可

- `models/abstract_yolo.pt`：基于 Ultralytics YOLO11n 微调，遵循 AGPL-3.0（Ultralytics 许可）。
- `models/yolo11n.pt`：Ultralytics 预训练权重，仅用于 COCO 摄像头模式。
- 训练数据由本项目原创精灵合成，不含第三方图像。
