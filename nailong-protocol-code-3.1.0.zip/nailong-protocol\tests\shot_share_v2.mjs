import { chromium } from "playwright-core";
import { resolve } from "node:path";
const root = resolve(import.meta.dirname, "..");
const browser = await chromium.launch({ executablePath: "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe", headless: true, args: ["--disable-gpu"] });
const page = await browser.newPage({ viewport: { width: 1600, height: 900 }, acceptDownloads: true });
await page.goto("http://127.0.0.1:8000/?debug", { waitUntil: "networkidle" });
await page.waitForTimeout(2400);
await page.click("#start-btn");
await page.waitForTimeout(300);
await page.evaluate(() => {
  const g = window.__nailong.game;
  window.__nailong.ui.showGame();
  g.startLevel(14);
  g.sun = 9999;
  const place = (t, c, r) => { g.readyAt[t] = 0; g.placePlant(t, c, r); };
  place("flower", 0, 0); place("flower", 0, 4);
  place("pea", 1, 0); place("pea", 1, 3);
  place("wall", 3, 1); place("wall", 3, 4);
  place("frost", 2, 2); place("fan", 2, 4); place("seal", 4, 2);
  place("cannon", 4, 1); place("vacuum", 4, 3); place("boomerang", 3, 2);
  g.sun = 425;
  g.spawnZombie("emperor", 2);
  for (const z of g.zombies) z.x = 960;
  g.stats.kills = 126; g.stats.waves = 5; g.stats.plantsPlaced = 28;
  g.stats.sunCollected = 1840; g.stats.yoloScans = 84; g.stats.time = 612;
  g.houseHp = 90; g.texts = []; g.particles = []; g.effects = []; g.projectiles = [];
  g.currentEvent = { title: "早八皇帝", line: "玉玺落下的声音，像查重通过。", modifier: "sunstorm", source: "llm" };
  g.win();
});
await page.waitForTimeout(1600);
console.log("end", await page.locator("#end-screen.open").count());
const dlPromise = page.waitForEvent("download", { timeout: 10000 }).catch(() => null);
await page.click("#end-share");
const dl = await dlPromise;
if (dl) {
  await dl.saveAs(resolve(root, "demo", "share-card-v2.png"));
  console.log("saved", dl.suggestedFilename());
}
await browser.close();
