import { chromium } from "playwright-core";
import { resolve } from "node:path";
const root = resolve(import.meta.dirname, "..");
const browser = await chromium.launch({ executablePath: "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe", headless: true, args: ["--disable-gpu"] });
const page = await browser.newPage({ viewport: { width: 1600, height: 900 } });
const errors = [];
page.on("console", (m) => { if (m.type() === "error") errors.push(m.text()); });
page.on("pageerror", (e) => errors.push(e.message));
await page.goto("http://127.0.0.1:8000/?debug", { waitUntil: "networkidle" });
await page.waitForTimeout(2400);
await page.click("#start-btn");
await page.waitForTimeout(250);
await page.locator(".level-card").first().click();
await page.waitForTimeout(700);
const before = await page.evaluate(() => window.__nailong.game.sun);
await page.click('[data-action="chat"]');
await page.waitForTimeout(300);
await page.fill("#chat-input", "妈妈求求你帮我");
await page.press("#chat-input", "Enter");
await page.waitForTimeout(1200);
const after = await page.evaluate(() => {
  const g = window.__nailong.game;
  return { sun: g.sun, shields: g.plants.filter((p) => p.shield > 0).length, lines: g.stats.aiLines };
});
const text = await page.locator("#chat-log").innerText();
console.log("sun", before, "->", after.sun, "after", after);
console.log(text.slice(-500));
console.log("errors", errors);
if (after.sun < before + 100) {
  console.error("FAIL favor action did not grant inspiration");
  process.exitCode = 1;
} else {
  console.log("PASS tsundere favor action");
}
await page.screenshot({ path: resolve(root, "demo", "chat-tsundere.png") });
await browser.close();
