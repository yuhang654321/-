import { chromium } from "playwright-core";
(async () => {
  const browser = await chromium.launch({ executablePath: "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe", headless: true, args: ["--disable-gpu"] });
  const page = await browser.newPage({ viewport: { width: 1600, height: 900 } });
  const errs=[]; page.on("pageerror",e=>errs.push(e.message));
  await page.goto("http://127.0.0.1:8000/?debug", { waitUntil: "networkidle" });
  await page.waitForTimeout(2400);
  await page.evaluate(() => { const {game:g,ui}=window.__nailong; ui.showGame(); g.startLevel(0); g.screen="playing"; g.waveActive=true; g.prepTimer=60; g.events.onToast=()=>{}; g.events.onNotice=()=>{}; });
  const result = await page.evaluate(() => {
    const {game:g}=window.__nailong;
    g.sun=9999;
    for (const id of ["flower","pea","wall","frost","fan","bomb","cannon","vacuum","boomerang","seal"]) g.readyAt[id]=0;
    const baseWaves=g.totalWaves;
    const placed=g.placePlant("flower",11,5);
    const far=g.plants.find(p=>p.col===11&&p.row===5);
    g.spawnZombie("basic",0);
    const z=g.zombies[g.zombies.length-1];
    g.time=10;
    g.wave=g.totalWaves;
    g.finishWave();
    const afterEarly={totalWaves:g.totalWaves, screen:g.screen, time:g.time};
    g.time=241;
    g.wave=g.totalWaves;
    g.finishWave();
    return {baseWaves, far:!!far, hp:z.maxHp, speed:z.baseSpeed, afterEarly, afterLate:{screen:g.screen,totalWaves:g.totalWaves,time:g.time}};
  });
  console.log(JSON.stringify(result,null,2)); console.log("errs", errs);
  if (!(result.far && result.hp > 150 && result.speed < 20 && result.afterEarly.totalWaves > result.baseWaves && result.afterEarly.screen === "playing" && result.afterLate.screen === "won")) {
    console.error("FAIL 2.6 pacing/map/overtime"); process.exitCode = 1;
  } else {
    console.log("PASS 2.7 pacing + 12x6 + overtime");
  }
  await browser.close();
})();
